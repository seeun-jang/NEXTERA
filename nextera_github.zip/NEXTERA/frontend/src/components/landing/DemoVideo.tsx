import { useEffect, useRef } from "react";
import { Icon } from "@/components/common";

// 랜딩의 "시연 영상 보기 (2분)" — 미리 녹화한 2분 시연 영상을 화면 위에 띄워 재생한다.
// 영상 파일은 public/media/ 에 있고 빌드하면 dist/media/ 로 그대로 복사된다(백엔드가 같은 서버에서 서빙).
// 실제 화면을 직접 따라가는 자동 시연은 주소에 ?tour=1 (발표용) · ?tour=full (제출용)로 그대로 쓸 수 있다.
const SRC = "/media/nextera-demo-2min.mp4";
const POSTER = "/media/nextera-demo-2min.jpg";

export function DemoVideo({ open, onClose }: { open: boolean; onClose: () => void }) {
  const closeRef = useRef<HTMLButtonElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (!open) return;
    closeRef.current?.focus();
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
      videoRef.current?.pause();
    };
  }, [open, onClose]);

  if (!open) return null;
  return (
    <div className="lp-video" role="dialog" aria-modal="true" aria-label="NEXTERA 시연 영상 (2분)" onClick={onClose}>
      <div className="lp-video-box" onClick={(e) => e.stopPropagation()}>
        <div className="lp-video-head">
          <strong>NEXTERA 시연 영상 · 2분</strong>
          <button ref={closeRef} type="button" className="lp-video-close" onClick={onClose} aria-label="영상 닫기">
            <Icon name="x" size={18} />
          </button>
        </div>
        <video ref={videoRef} className="lp-video-player" src={SRC} poster={POSTER} controls autoPlay playsInline preload="metadata" />
        <p className="lp-video-note">상황 설정부터 결정 영수증까지 · 판단은 Zoro-1 · 모든 수치는 시뮬레이션 · ESC로 닫기</p>
      </div>
    </div>
  );
}

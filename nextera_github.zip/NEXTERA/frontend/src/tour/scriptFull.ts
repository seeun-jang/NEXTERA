// 자동 시연 대본 · 제출용 긴 버전 (약 8분) — 기능을 빠짐없이, 흐름을 따라가며, 발표에서 다 못 한 설명까지.
// 본편("사건이 동시에 터진 날")을 끝까지 따라간 뒤, 변수를 바꾼 두 상황을 더 돌린다.
//   ① 직접 만든 상황: 기본 상황에서 팬 고장 · 냉각 레벨을 바꿔 사건과 계획이 바뀌는 것을 보고, 그 상황으로 서버 판단까지
//   ② 손쓸 수 없는 문제가 섞인 날: 회차 반복 → 사람에게 넘김 → 기록 · 분석(성공 · 실패)
// LIVE(실제 Zoro-1)로 찍는다. 고른 계획 · 필요 승인 · 판단 주체는 화면에서 읽어 자막과 클릭을 맞춘다.
// 시작: 주소에 ?tour=full
import { approveAll, BTN, ch, funnelNums, judge, neededRoles, rolesText, WAIT_DECIDE, type TourApi } from "./script";

const READ = 4400; // 자막 한 장면 기본 시간
const LONG = 5400; // 설명이 긴 장면
const MOVE = { moveMs: 800, afterMs: 900 };
const FAST = { moveMs: 500, afterMs: 600 };

/** 상황 설정 화면의 입력칸(select · number)에 값을 넣는다. 커서를 그 칸으로 옮긴 뒤 React가 알아듣는 방식으로 바꾼다. */
async function setField(t: TourApi, label: string, value: number | string) {
  const sel = `[aria-label="${label}"]`;
  await t.click(sel, undefined, { moveMs: 700, afterMs: 200 });
  const el = (await t.waitFor(sel)) as HTMLInputElement | HTMLSelectElement;
  const proto = el instanceof HTMLSelectElement ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
  Object.getOwnPropertyDescriptor(proto, "value")!.set!.call(el, String(value));
  el.dispatchEvent(new Event("input", { bubbles: true }));
  el.dispatchEvent(new Event("change", { bubbles: true }));
  (el as HTMLElement).blur();
  await t.sleep(500);
}

/** 상황 설정 미리보기의 사건 목록 · 미리 계산한 계획 */
function preview() {
  const items = Array.from(document.querySelectorAll(".nx-sb-incidents li"));
  const names = items.map((li) => (li.querySelector("strong")?.textContent ?? li.textContent ?? "").trim()).filter(Boolean);
  const pick = (document.querySelector(".nx-scn-pick strong")?.textContent ?? "").trim();
  return { n: items.length, names, pick };
}

export async function runScriptFull(t: TourApi) {
  // ---------- 오프닝 ----------
  await t.go("/");
  window.scrollTo(0, 0);
  await t.chapter({ no: "", title: "NEXTERA", sub: "AI 인프라 운영팀을 위한 의사결정 에이전트", kind: "title" }, 2600);
  await t.chapter(
    {
      no: "",
      title: "AI 인프라는 멈추면 안 됩니다",
      kind: "pitch",
      items: [
        { title: "과열 노드, 마감이 임박한 일, 줄 서 있는 일이 동시에 생긴다", sub: "실제 운영에서 사건이 하나뿐인 날은 드물다" },
        { title: "식히면 에너지, 옮기면 재시작 지연, 미루면 고객 약속 위반", sub: "어느 쪽도 공짜가 아니다" },
        { title: "사내 규정과 승인 권한까지 함께 봐야 한다", sub: "모니터링만으로는 결정할 수 없다" },
      ],
    },
    6200,
  );
  await t.chapter(
    {
      no: "",
      title: "기존 모니터링 위에 얹는 의사결정 · 검증 계층",
      sub: "계획은 규칙 코드가 만들고 검증합니다 · 고르기는 Zoro-1 · 실행은 사람의 승인 뒤 가상 환경에서",
      kind: "flow",
      flow: { steps: ["상황 설정", "사건 정렬", "계획 생성 · 검증", "Zoro-1 선택", "안전 검사", "역할별 승인", "가상 실행", "회차 · 영수증"], animate: true },
    },
    6200,
  );
  await t.click(BTN, "지금 체험하기", MOVE);

  // ---------- 1 상황 설정 ----------
  await t.waitFor(".nx-scn-presets");
  t.hideCursor();
  await t.chapter(ch(0, "처음에 상황을 정한다"), 2400);
  t.stage(0);
  await t.spot(".nx-scn-presets", { tag: "상황 설정", title: "준비된 상황을 고르거나, 값을 바꿔 직접 만듭니다", sub: "정해진 한 장면이 아니라 여러 날의 상황을 바로 바꿔 볼 수 있습니다" }, READ);
  await t.spot(".nx-sb-zones", { tag: "상황 설정", title: "노드 1~6개 · 온도 · 팬 이상 · 구역별 냉각 레벨과 상한", sub: "냉각 구역 하나가 노드 2개를 맡습니다 (N1·N2=Z1, N3·N4=Z2, N5·N6=Z3) · 냉각은 구역 단위로만 바뀝니다" }, LONG);
  await t.spot(".nx-sb-jobs", { tag: "상황 설정", title: "일 1~10개 · GPU · 우선순위 · 마감 · 남은 작업 · 배치 노드", sub: "노드마다 GPU 8장 · 합이 8장 이하면 동시에 실행, 넘으면 그 노드에서 순서대로 대기" }, LONG);
  t.unspot();
  await t.click(".nx-scn-preset", "사건이 동시에 터진 날", MOVE);
  t.hideCursor();
  await t.spot(".nx-scn-result", { tag: "상황 설정", title: "과열 두 곳 + 앞의 일 때문에 마감을 놓칠 일 하나", sub: "오른쪽 계획은 화면에서 바로 계산한 미리보기입니다 · 시작하면 서버가 다시 계산하고 Zoro-1이 고릅니다" }, LONG);
  t.caption({ tag: "상황 설정", title: "이번 시연은 이 상황으로 끝까지 따라갑니다", sub: "이후 화면은 모두 이 설정에서 계산한 결과입니다" });
  await t.sleep(2400);
  await t.click(BTN, "이 상황으로 시작", MOVE);

  // ---------- 2 상황 파악 ----------
  await t.waitFor(".nx-inc-list", undefined, WAIT_DECIDE);
  t.hideCursor();
  await t.chapter(ch(1, "무엇이 급한가"), 2400);
  t.stage(1);
  await t.spot(".nx-inc-list", { tag: "운영 현황", title: "사건을 중요도 순으로 줄 세웁니다", sub: "사건 = 조치 없이 두면 88°C를 넘는 노드, 마감을 놓치는 일 · 한계까지 짧을수록, 우선순위가 높을수록 위" }, LONG);
  await t.spot(".nx-board", { tag: "운영 현황", title: "노드마다 실행 중인 일과 줄 서 있는 일", sub: "GPU 8장 한도 때문에 앞의 일이 끝나야 시작하는 일이 생깁니다 · 이것도 마감 위험의 원인" }, LONG);
  t.unspot();
  await t.click(BTN, "사건 상세 보기", MOVE);
  await t.waitFor(".nx-callout");
  t.hideCursor();
  const forecast = await t.text(".nx-callout");
  await t.spot(".nx-split-main .nx-card", { tag: "사건 상세", title: "아무것도 하지 않으면?", sub: forecast }, READ);
  await t.spot(".nx-reasons", { tag: "사건 상세", title: "단순 임계값 규칙으로는 풀 수 없습니다", sub: "팬 이상 · 재시작 지연 · 구역 단위 냉각 · 역할별 승인이 함께 걸려 있습니다" }, READ);
  t.unspot();
  await t.click(BTN, "회사 운영 정책 확인", MOVE);

  // ---------- 3 판단 ----------
  await t.waitFor(".nx-funnel");
  t.hideCursor();
  await t.chapter(ch(2, "규칙 코드가 만들고 거르고, Zoro-1이 고른다"), 2400);
  t.stage(2);
  await t.spot(".nx-split-main .nx-table", { tag: "운영 정책", title: "회사가 먼저 규칙을 정합니다", sub: "P0 보호 · 열 한계 · 냉각 상한 같은 필수 제약은 어떤 승인으로도 풀리지 않습니다" }, READ);
  const f = funnelNums();
  await t.spot(
    ".nx-funnel",
    {
      tag: "운영 정책",
      title: f.length >= 6 ? `전략 ${f[0]} → 연쇄 계획 ${f[1]} → 정리 ${f[2]} → Safety Gate ${f[3]} → 열위 제거 ${f[4]} → Zoro-1 ${f[5]}` : "전략 → 연쇄 계획 → 정리 → Safety Gate → 열위 제거 → Zoro-1",
      sub: "전략마다 '가장 급한 문제 → 행동 1개 → 시뮬레이션'을 문제가 없어질 때까지 반복해 계획을 만듭니다",
    },
    LONG + 600,
  );
  await t.spot(".nx-funnel", { tag: "운영 정책", title: "새 문제를 만들거나 하나도 못 푸는 계획은 Safety Gate에서 탈락", sub: "다른 계획보다 모든 면에서 못한 계획도 빼고, 규칙 순위 상위만 Zoro-1에 보냅니다 · 후보가 많으면 모델의 선택이 제시 순서에 흔들리기 때문" }, LONG + 600);
  if (t.exists(".nx-excluded")) {
    await t.spot(".nx-excluded", { tag: "운영 정책", title: "제외된 전략과 이유도 화면에 남깁니다", sub: "왜 그 계획이 후보에 없었는지 설명할 수 있어야 합니다" }, READ);
  }
  await t.spot(".nx-rulelist", { tag: "운영 정책", title: "멈추기 규칙", sub: "더 급한 일만 멈출 수 있고, P0는 멈추지 않으며, 멈춘 일이 마감을 놓치는 계획은 제외" }, READ);
  t.unspot();
  await t.click(BTN, "정책 적용 후 AI 판단", { moveMs: 800, afterMs: 1000 });
  await t.waitFor(".nx-verdict", undefined, WAIT_DECIDE);
  t.hideCursor();
  const j = await judge(t);
  await t.spot(
    ".nx-modelbar",
    j.zoro
      ? { tag: "의사결정 센터", title: "Zoro-1이 고릅니다", sub: "같은 후보를 보여 주는 순서만 바꿔 여러 번 묻고, 가장 많이 1위였던 계획을 택합니다 · 한 번의 순서에 기대지 않기 위한 장치" }
      : { tag: "의사결정 센터", title: "Zoro-1 응답이 없어 규칙 순위로 골랐습니다", sub: "모델이 실패해도 검증된 후보 안에서만 고르고, 그 사실을 화면과 기록에 남깁니다" },
    LONG + 400,
  );
  await t.spot(".nx-cands", { tag: "의사결정 센터", title: "후보 하나 = 행동 여러 개로 된 계획", sub: j.zoro ? "떠맡기기 · 새치기 · 임시 대피 · 연기 · 냉각 변경을 이어 붙입니다 · 후보마다 Zoro-1이 준 확률이 함께 보입니다" : "떠맡기기 · 새치기 · 임시 대피 · 연기 · 냉각 변경을 이어 붙입니다" }, LONG);
  if (t.exists(".nx-section-title", "전달하지 않은 후보")) {
    await t.spot(".nx-section", { tag: "의사결정 센터", title: "검증은 통과했지만 Zoro-1에 보내지 않은 후보", sub: "숨기지 않고 따로 보여 줍니다 · 어떤 후보가 있었는지 사람이 확인할 수 있습니다" }, READ, { text: "전달하지 않은 후보" });
  }
  const pick = await t.text(".nx-verdict-main strong");
  await t.spot(".nx-verdict", { tag: "의사결정 센터", title: `${j.zoro ? "Zoro-1" : "규칙"}의 선택: ${pick}`, sub: "선택 이유와 단계별 필요 승인이 함께 나옵니다 · 아직 실행 전" }, LONG);
  t.unspot();
  await t.click(BTN, "대안별 결과 보기", MOVE);
  await t.waitFor(".nx-ftable");
  t.hideCursor();
  await t.spot(".nx-futures", { tag: "대안별 결과", title: "과열 노드의 온도를 계획별로 비교합니다", sub: "같은 상황 · 같은 발열 모델에서 계획만 다르게" }, READ);
  await t.spot(".nx-ftable", { tag: "대안별 결과", title: "최고 온도 · 에너지 · 일별 완료 · 풀리는/남는 문제", sub: "전수 탐색이 아니라 '검증된 전략안 중 선택'입니다" }, LONG);
  t.unspot();

  // ---------- 4 통제된 실행 ----------
  await t.chapter(ch(3, "AI가 골라도, 바로 실행되지 않는다"), 2400);
  t.stage(3);
  await t.click(BTN, "실행 전 안전 검사", MOVE);
  await t.waitFor(".nx-banner--conditional, .nx-banner--allowed", undefined, WAIT_DECIDE);
  t.hideCursor();
  await t.spot(".nx-split-main .nx-card", { tag: "안전 검사", title: "모델과 분리된 코드가 단계마다 다시 검사합니다", sub: "P0 보호 · 대상 노드 자리 · 멈추기 규칙 · 냉각 상한 · 열 한계 · 승인 권한" }, LONG);
  t.unspot();
  await t.click(BTN, "강제 입력 검사 실행", MOVE);
  t.hideCursor();
  await t.spot(".nx-testpanel", { tag: "안전 검사", title: "누군가 P0 일을 옮기라고 넣는다면?", sub: "AI가 고르지 않은 행동도 같은 검사를 거쳐 실행 큐에서 빠지고, 시도는 기록에 남습니다" }, LONG);
  t.unspot();
  await t.click(BTN, "담당자 승인 요청", MOVE);

  await t.waitFor(".nx-decide");
  t.hideCursor();
  const roles = neededRoles();
  await t.spot(".nx-split-main .nx-table", { tag: "협업 · 승인", title: `이 계획은 ${rolesText(roles)} 필요합니다`, sub: "냉각 단계는 냉각 담당자(A), 일 이동 · 멈추기 단계는 GPU 담당자(B)가 승인합니다" }, LONG);
  t.unspot();
  await t.click(".nx-decide .nx-seg button", "관제 운영자", { moveMs: 800, afterMs: 400 });
  t.hideCursor();
  await t.spot(".nx-decide", { tag: "협업 · 승인", title: "관제 운영자에게는 승인 권한이 없습니다", sub: "승인 버튼이 잠겨 있습니다" }, 3800);
  await t.click(BTN, "그래도 서버에 승인 요청 보내 보기", MOVE);
  t.hideCursor();
  await t.spot(".nx-decide .nx-block-danger", { tag: "협업 · 승인", title: "화면을 우회해도 거부됩니다", sub: "권한 검사는 버튼 + 서버 두 겹 · 거부된 시도도 영수증에 남습니다" }, 4200);
  t.unspot();
  await t.click(".nx-decide .nx-seg button", "A · 냉각 운영", { moveMs: 800, afterMs: 400 });
  t.hideCursor();
  await t.spot(".nx-card:has(.nx-comment-input)", { tag: "협업 · 승인", title: "냉각 담당자가 의견을 남깁니다", sub: "어느 역할이든 의견은 남길 수 있고, 의견도 기록됩니다", top: true }, 1400);
  await t.type("input[aria-label='의견 입력']", "Z2 냉각은 한 단계만 올리겠습니다. N4 팬은 오늘 교체합니다.");
  await t.click(BTN, "의견 등록", { moveMs: 600, afterMs: 900 });
  t.unspot();
  await approveAll(t, { move: { moveMs: 800, afterMs: 500 }, read: 2600 });

  await t.waitFor(".nx-exec-banner", undefined, WAIT_DECIDE);
  t.hideCursor();
  await t.spot(".nx-kpis--3", { tag: "실행 및 결과", title: "가상 환경에서만 실행합니다", sub: "실제 설비 제어 없음 · 모든 수치는 시뮬레이션" }, READ);
  await t.spot(".nx-split-main .nx-card", { tag: "실행 및 결과", title: "일별 예상 완료가 실행 전후로 어떻게 바뀌었는지", sub: "옮기거나 멈춘 일은 재시작 지연(1분)만큼 늦게 끝납니다" }, READ);
  t.unspot();
  await t.click(BTN, "회차 결과 보기", MOVE);
  await t.waitFor(".nx-rounds");
  t.hideCursor();
  await t.spot(".nx-banner", { tag: "회차 요약", title: "실행 뒤 상태로 남은 문제를 다시 계산합니다", sub: "남은 문제 없음 · 안전한 후보 없음 · 직전과 같음 · 최대 회차 중 하나면 멈춥니다" }, LONG);
  t.unspot();

  // ---------- 5 결정 영수증 ----------
  await t.chapter(ch(4, "상황부터 결과까지, 하나의 기록으로"), 2400);
  t.stage(4);
  await t.click(BTN, "결정 영수증 확인", MOVE);
  await t.waitFor(".nx-timeline");
  t.hideCursor();
  await t.spot(".nx-receipt-rounds", { tag: "결정 영수증", title: "회차마다 사건 · 후보 · 선택 · 승인 · 결과", sub: "원래 AI 제안은 덮어쓰지 않습니다 · 판단 주체(Zoro-1 · 규칙)도 함께" }, LONG);
  await t.spot(".nx-timeline", { tag: "결정 영수증", title: "누가, 언제, 무엇을 결정했는지 추적합니다", sub: "강제 입력 차단 · 거부된 승인 · 의견까지 남습니다" }, 1600);
  await t.scrollBy(400, 2800);
  await t.sleep(1200);
  t.unspot();

  // ---------- 변수 ①: 직접 만든 상황 ----------
  t.stage(-1);
  await t.chapter({ no: "", title: "변수를 바꾸면?", sub: "기본 상황에서 팬 고장과 냉각 레벨을 바꿔 보고, 그 상황으로 다시 판단합니다", kind: "title" }, 3200);
  await t.go("/scenario");
  await t.waitFor(".nx-scn-presets");
  t.stage(0);
  await t.click(".nx-scn-preset", "기본 상황", MOVE);
  t.hideCursor();
  let pv = preview();
  await t.spot(".nx-scn-result", { tag: "변수 ①", title: `기본 상황: 사건 ${pv.n}건`, sub: `${pv.names.join(" · ")} · 미리 계산한 계획 → ${pv.pick}` }, READ);
  t.unspot();
  await t.click('[aria-label="N5 팬 이상"]', undefined, MOVE);
  t.hideCursor();
  pv = preview();
  await t.spot(".nx-scn-result", { tag: "변수 ①", title: `N5 팬이 고장 나면 → 사건 ${pv.n}건`, sub: `${pv.names.join(" · ")} · 계획도 바뀝니다 → ${pv.pick}` }, LONG);
  t.unspot();
  await setField(t, "Z2 냉각 레벨", 5);
  t.hideCursor();
  pv = preview();
  await t.spot(".nx-scn-result", { tag: "변수 ①", title: `Z2 냉각을 5단계로 올리면 → 사건 ${pv.n}건`, sub: `${pv.names.join(" · ") || "사건 없음"} · 냉각만으로 풀리는 문제는 사건에서 빠집니다` }, LONG);
  t.caption({ tag: "변수 ①", title: "직접 만든 이 상황으로 서버 판단까지 가 봅니다", sub: "미리보기는 화면 계산 · 시작하면 서버가 같은 값으로 다시 계산합니다" });
  await t.sleep(2600);
  await t.click(BTN, "이 상황으로 시작", MOVE);
  await t.waitFor(".nx-inc-list", undefined, WAIT_DECIDE);
  t.stage(1);
  t.hideCursor();
  await t.spot(".nx-inc-list", { tag: "변수 ① · 운영 현황", title: "서버가 다시 계산한 사건", sub: "같은 흐름을 그대로 탑니다" }, 3400);
  t.unspot();
  t.caption(null);
  await t.click(BTN, "사건 상세 보기", FAST);
  await t.waitFor(".nx-callout");
  await t.click(BTN, "회사 운영 정책 확인", FAST);
  await t.waitFor(".nx-funnel");
  t.stage(2);
  await t.click(BTN, "정책 적용 후 AI 판단", FAST);
  await t.waitFor(".nx-verdict, .nx-handoff", undefined, WAIT_DECIDE);
  t.hideCursor();
  if (t.exists(".nx-verdict")) {
    const j1 = await judge(t);
    const pick1 = await t.text(".nx-verdict-main strong");
    await t.spot(".nx-verdict", { tag: "변수 ① · 의사결정 센터", title: `상황이 바뀌면 계획도 바뀝니다 · ${j1.zoro ? "Zoro-1" : "규칙"}의 선택: ${pick1}`, sub: "같은 규칙 · 같은 검증을 거친 후보 안에서 다시 고릅니다" }, LONG, { block: "start" });
    t.unspot();
    t.caption({ tag: "변수 ① · 통제된 실행", title: "대안 비교 → 안전 검사 → 승인 요청", sub: "본편과 같은 단계를 거칩니다" });
    await t.click(BTN, "대안별 결과 보기", FAST);
    await t.waitFor(".nx-ftable");
    await t.click(BTN, "실행 전 안전 검사", FAST);
    await t.waitFor(".nx-banner--conditional, .nx-banner--allowed", undefined, WAIT_DECIDE);
    t.stage(3);
    await t.click(BTN, "담당자 승인 요청", FAST);
    await t.waitFor(".nx-decide");
    t.hideCursor();
    const roles1 = neededRoles();
    t.caption({ tag: "변수 ① · 협업 · 승인", title: `이번 계획은 ${rolesText(roles1)} 필요합니다`, sub: "필요한 역할은 고른 계획의 단계에 따라 달라집니다" });
    await t.sleep(3200);
    await approveAll(t, { move: { moveMs: 700, afterMs: 400 }, read: 1800 });
    await t.waitFor(".nx-exec-banner", undefined, WAIT_DECIDE);
    await t.click(BTN, "회차 결과 보기", FAST);
    await t.waitFor(".nx-rounds");
    t.hideCursor();
    await t.spot(".nx-banner", { tag: "변수 ① · 회차 요약", title: "직접 만든 상황도 같은 흐름으로 끝까지 처리됩니다", sub: "상황 → 사건 → 후보 → 선택 → 검사 → 승인 → 가상 실행 → 회차" }, READ);
    t.unspot();
  } else {
    await t.spot(".nx-handoff", { tag: "변수 ① · 의사결정 센터", title: "이 상황에서는 안전한 계획이 없어 사람에게 넘깁니다" }, READ);
    t.unspot();
  }

  // ---------- 변수 ②: 회차 반복과 사람에게 넘김 ----------
  t.stage(-1);
  await t.chapter({ no: "", title: "어떻게 해도 못 푸는 문제가 섞이면?", sub: "N4 과열에 더해, 일 자체가 마감보다 긴 J05가 있는 날", kind: "title" }, 3200);
  await t.go("/scenario");
  await t.waitFor(".nx-scn-presets");
  await t.click(".nx-scn-preset", "손쓸 수 없는 문제가 섞인 날", MOVE);
  t.hideCursor();
  t.stage(0);
  await t.spot(".nx-scn-result", { tag: "변수 ②", title: "N4 과열은 풀 수 있지만, J05는 일 자체가 마감보다 깁니다", sub: "AI가 무리하게 실행하는지, 멈추고 사람을 부르는지 봅니다" }, READ);
  t.unspot();
  await t.click(BTN, "이 상황으로 시작", MOVE);
  await t.waitFor(".nx-inc-list", undefined, WAIT_DECIDE);
  t.stage(1);
  t.caption({ tag: "변수 ②", title: "같은 흐름으로 사건 정렬 → 운영 정책 → 서버 판단" });
  await t.click(BTN, "사건 상세 보기", FAST);
  await t.waitFor(".nx-callout");
  await t.click(BTN, "회사 운영 정책 확인", FAST);
  await t.waitFor(".nx-funnel");
  t.stage(2);
  await t.click(BTN, "정책 적용 후 AI 판단", FAST);
  await t.waitFor(".nx-verdict", undefined, WAIT_DECIDE);
  t.hideCursor();
  const j2 = await judge(t);
  const pick2 = await t.text(".nx-verdict-main strong");
  await t.spot(".nx-verdict", { tag: "변수 ② · 1회차", title: `1회차: 풀 수 있는 과열부터 · ${j2.zoro ? "Zoro-1" : "규칙"}의 선택: ${pick2}`, sub: "J05 마감 문제는 어떤 계획으로도 풀 수 없어 따로 운영자에게 넘깁니다" }, LONG, { block: "start" });
  t.unspot();
  t.caption({ tag: "변수 ② · 통제된 실행", title: "대안 비교 → 안전 검사 → 승인 요청", sub: "본편과 같은 단계를 거칩니다" });
  await t.click(BTN, "대안별 결과 보기", FAST);
  await t.waitFor(".nx-ftable");
  await t.click(BTN, "실행 전 안전 검사", FAST);
  await t.waitFor(".nx-banner--conditional, .nx-banner--allowed", undefined, WAIT_DECIDE);
  t.stage(3);
  await t.click(BTN, "담당자 승인 요청", FAST);
  await t.waitFor(".nx-decide");
  t.hideCursor();
  const roles2 = neededRoles();
  t.caption({ tag: "변수 ② · 협업 · 승인", title: `고른 계획에 맞춰 ${rolesText(roles2)} 필요합니다`, sub: "어느 계획이 뽑혀도 필요한 역할만 승인하면 실행됩니다" });
  await t.sleep(3000);
  await approveAll(t, { move: { moveMs: 700, afterMs: 400 }, read: 1800 });
  await t.waitFor(".nx-exec-banner", undefined, WAIT_DECIDE);
  await t.click(BTN, "회차 결과 보기", FAST);
  await t.waitFor(".nx-rounds");
  t.hideCursor();
  if (t.exists(BTN, "2회차 판단")) {
    await t.spot(".nx-banner", { tag: "변수 ② · 회차 요약", title: "N4 과열은 풀렸고, J05 마감 문제가 남았습니다", sub: "실행 뒤 상태를 기준으로 2회차를 다시 계산합니다" }, READ);
    t.unspot();
    await t.click(BTN, "2회차 판단", MOVE);
    await t.waitFor(".nx-verdict, .nx-handoff", undefined, WAIT_DECIDE);
    t.stage(2);
    t.hideCursor();
    if (t.exists(".nx-handoff")) {
      await t.spot(".nx-handoff", { tag: "변수 ② · 2회차", title: "남은 문제에 안전한 계획이 없어 멈춥니다", sub: "무리해서 실행하지 않고 사람에게 넘깁니다" }, LONG);
      t.unspot();
    }
  } else {
    await t.spot(".nx-banner", { tag: "변수 ② · 회차 요약", title: "남은 문제에 안전한 계획이 없어 멈춥니다", sub: "무리해서 실행하지 않고 사람에게 넘깁니다" }, LONG);
    t.unspot();
  }
  if (t.exists(BTN, "사람에게 넘김 보기")) {
    await t.click(BTN, "사람에게 넘김 보기", MOVE);
    await t.waitFor(".nx-ticket");
    t.hideCursor();
    await t.spot(".nx-handoff", { tag: "사람에게 넘김", title: "AI가 멈추고 사람을 부릅니다", sub: "설비는 건드리지 않고, 승인 · 실행 단계로도 가지 않습니다" }, READ);
    await t.spot(".nx-ticket", { tag: "사람에게 넘김", title: "누구에게 무엇을 요청했는지 남깁니다", sub: "이 요청과 이유도 결정 영수증에 기록됩니다" }, READ);
    t.unspot();
  }

  // ---------- 기록 · 분석: 이번 시연의 실제 기록 ----------
  t.stage(4);
  await t.go("/receipts");
  await t.waitFor(".nx-timeline");
  t.hideCursor();
  await t.spot(".nx-receipt-rounds", { tag: "결정 영수증", title: "회차를 넘어간 결정도 한 기록으로 이어집니다", sub: "1회차 실행 · 2회차 사람에게 넘김" }, READ);
  t.unspot();
  await t.click(BTN, "기록 상세 보기", MOVE);
  await t.waitFor(".nx-tbars", undefined, WAIT_DECIDE);
  t.hideCursor();
  await t.spot(".nx-kpis--6", { tag: "기록 · 분석", title: "이번 시연의 실제 기록을 집계합니다", sub: "사건 단위로 셉니다 · 성공 = 해결한 사건 · 실패 = 사람에게 넘긴 사건 · 사람 이관률 · 마감 준수" }, LONG);
  await t.spot(".nx-tbars", { tag: "기록 · 분석", title: "어떤 유형의 사건에서 마감을 놓쳤는지 찾습니다", sub: "실패 패턴 → 정책 · 시스템 개선으로 연결" }, READ);
  t.unspot();

  // ---------- 기업이 얻는 것 · 도입 ----------
  t.stage(-1);
  await t.chapter(
    {
      no: "",
      title: "기업이 얻는 것",
      kind: "pitch",
      items: [
        { title: "안전한 실행", sub: "회사 규칙을 어기는 실행은 모델과 분리된 코드가 처음부터 차단" },
        { title: "동시다발 대응", sub: "여러 사건을 중요도 순으로 묶어 검증된 계획으로" },
        { title: "멈출 줄 아는 AI", sub: "풀 수 없는 문제는 무리하지 않고 사람에게 넘긴다" },
        { title: "감사 대응", sub: "모든 결정의 근거 · 승인 · 결과를 한 기록으로" },
      ],
    },
    6400,
  );
  await t.chapter(
    {
      no: "",
      title: "도입은 단계적으로",
      kind: "pitch",
      numbered: true,
      items: [
        { title: "Shadow Mode", sub: "실제 텔레메트리를 읽기 전용으로 연결해 제안만 기록" },
        { title: "제한된 파일럿", sub: "일부 클러스터에서 기존 승인 흐름과 함께 운영" },
        { title: "운영 확대", sub: "사내 정책 · 티켓 시스템과 연동해 범위 확장" },
      ],
    },
    5600,
  );

  // ---------- 엔딩 ----------
  await t.chapter({ no: "", title: "Better Decisions. Better Operations.", sub: "NEXTERA · 더 나은 판단이 더 안전한 운영을 만듭니다", kind: "end" }, 3600);
  await t.go("/");
  window.scrollTo(0, 0);
}

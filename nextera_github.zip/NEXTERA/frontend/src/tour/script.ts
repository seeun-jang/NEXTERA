// 자동 시연 대본 · 발표용 2분 — 핵심 흐름과 차별점만, 장면마다 자막 하나를 읽을 시간을 둔다.
// 영상은 LIVE(실제 Zoro-1)로 찍는다. 서버 결과에 따라 달라지는 값(후보 수, 고른 계획, 필요 승인, 판단 주체)은
// 하드코딩하지 않고 화면에서 읽어 자막에 쓴다. 검증하지 않은 성과 수치(절감률 등)는 넣지 않는다.
// 제출용 긴 버전은 scriptFull.ts.
import type { Chapter } from "./TourProvider";
import { STAGES } from "./TourProvider";

export interface TourApi {
  sleep(ms: number): Promise<void>;
  waitFor(sel: string, text?: string, timeout?: number): Promise<Element>;
  text(sel: string, fallback?: string): Promise<string>;
  go(path: string): Promise<void>;
  caption(c: { tag?: string; title: string; sub?: string; top?: boolean } | null): void;
  chapter(c: Chapter, ms?: number): Promise<void>;
  spot(sel: string, c: { tag?: string; title: string; sub?: string; top?: boolean } | null, ms: number, opts?: { text?: string; block?: ScrollLogicalPosition }): Promise<void>;
  unspot(): void;
  click(sel: string, text?: string, opts?: { moveMs?: number; afterMs?: number }): Promise<void>;
  type(sel: string, value: string): Promise<void>;
  hideCursor(): void;
  scrollBy(dy: number, ms: number): Promise<void>;
  exists(sel: string, text?: string): boolean;
  stage(i: number): void;
}

export const ch = (i: number, sub: string): Chapter => ({
  no: String(i + 1).padStart(2, "0"),
  title: STAGES[i],
  sub,
  flow: { steps: STAGES, active: i },
});

export const BTN = "button";
/** LIVE에서 서버 판단(Zoro-1 4회 질문)을 기다리는 최대 시간 */
export const WAIT_DECIDE = 45000;

// ---------- 화면에서 읽는 도우미 (LIVE 결과에 따라 자막과 클릭을 맞춘다) ----------

const ROLES = [
  { name: "A · 냉각 운영", who: "냉각 담당자(A)", what: "냉각 단계" },
  { name: "B · GPU 운영", who: "GPU 담당자(B)", what: "일 이동 단계" },
] as const;

/** 협업·승인 화면의 "필요한 승인자" 표에서 이 계획에 필요한 역할만 고른다. 필요 없는 역할의 상태 칸은 "참조". */
export function neededRoles() {
  const rows = Array.from(document.querySelectorAll(".nx-table tbody tr"));
  return ROLES.filter((r) =>
    rows.some((tr) => {
      const td = tr.querySelectorAll("td");
      return td.length === 3 && (td[0].textContent ?? "").includes(r.name) && (td[2].textContent ?? "").trim() !== "참조";
    }),
  );
}

/** "A와 B" / "B만" 같은 자막용 문구 */
export function rolesText(roles: ReturnType<typeof neededRoles>) {
  if (roles.length === 2) return "냉각(A)과 일 이동(B) 승인이 모두";
  if (roles.length === 1) return roles[0].name.startsWith("A") ? "냉각(A) 승인만" : "일 이동(B) 승인만";
  return "승인이";
}

/** 필요한 역할을 A → B 순서로 하나씩 승인한다. 마지막 승인 버튼은 "승인하고 실행". 어떤 조합(A만 · B만 · A와 B)이든 통과한다. */
export async function approveAll(t: TourApi, opts: { move?: { moveMs: number; afterMs: number }; read?: number } = {}) {
  const move = opts.move ?? { moveMs: 500, afterMs: 300 };
  const roles = neededRoles();
  if (!roles.length) throw new Error("자동 시연: 필요한 승인 역할을 화면에서 읽지 못했습니다");
  for (const [i, r] of roles.entries()) {
    const last = i === roles.length - 1;
    // 자막을 먼저 바꾼 뒤 역할을 고른다(앞 역할의 자막이 다음 역할 화면에 남지 않게)
    t.caption({
      tag: "협업 · 승인",
      title: `${r.who}가 ${r.what}를 승인합니다`,
      sub: last ? "필요한 승인이 모두 모이면 실행 직전에 최신 상태로 다시 검사하고 실행합니다" : "다음 역할의 승인이 남아 있습니다",
    });
    await t.click(".nx-decide .nx-seg button", r.name, move);
    await t.sleep(opts.read ?? 1200);
    await t.click(".nx-decide .nx-btn", "승인", { moveMs: move.moveMs, afterMs: last ? 900 : 500 });
  }
}

/** 의사결정 센터의 판단 줄. 실제 모델이 답했는지, 규칙으로 대신 골랐는지에 따라 자막을 바꾼다. */
export async function judge(t: TourApi) {
  const how = await t.text(".nx-modelbar .caption");
  return { zoro: how.includes("Zoro-1 응답"), how };
}

/** 운영 정책 화면의 후보 깔때기 숫자: [전략, 연쇄 계획, 정리, Safety Gate, 열위 제거, Zoro-1 전달] */
export function funnelNums() {
  return Array.from(document.querySelectorAll(".nx-funnel-step .n")).map((el) => (el.textContent ?? "").trim());
}

export async function runScript(t: TourApi) {
  // ---------- 오프닝 ----------
  await t.go("/");
  window.scrollTo(0, 0);
  await t.chapter({ no: "", title: "NEXTERA", sub: "AI 인프라 운영팀을 위한 의사결정 에이전트", kind: "title" }, 1800);
  await t.chapter(
    {
      no: "",
      title: "사건이 겹쳐도, 규칙 안에서 판단하고 사람이 통제합니다",
      sub: "계획은 규칙 코드가 만들고 검증 · 선택은 Zoro-1 · 실행은 승인 뒤 가상 환경에서",
      kind: "flow",
      flow: { steps: ["상황 설정", "사건 정렬", "계획 생성 · 검증", "Zoro-1 선택", "안전 검사", "역할별 승인", "가상 실행", "회차 · 영수증"], animate: true },
    },
    4400,
  );
  await t.click(BTN, "지금 체험하기", { moveMs: 500, afterMs: 700 });

  // ---------- 1 상황 설정 ----------
  await t.waitFor(".nx-scn-presets");
  t.hideCursor();
  await t.chapter(ch(0, "상황을 직접 정한다"), 1100);
  t.stage(0);
  await t.click(".nx-scn-preset", "사건이 동시에 터진 날", { moveMs: 500, afterMs: 500 });
  t.hideCursor();
  await t.spot(".nx-scn-result", { tag: "상황 설정", title: "노드 · 냉각 구역 · 일을 정하면 사건을 바로 계산합니다", sub: "이번 상황: 과열 두 곳 + 앞의 일 때문에 마감을 놓칠 일 하나" }, 3800);
  t.unspot();
  await t.click(BTN, "이 상황으로 시작", { moveMs: 500, afterMs: 700 });

  // ---------- 2 상황 파악 ----------
  await t.waitFor(".nx-inc-list", undefined, WAIT_DECIDE);
  t.hideCursor();
  await t.chapter(ch(1, "무엇이 급한가"), 1100);
  t.stage(1);
  await t.spot(".nx-inc-list", { tag: "운영 현황", title: "동시에 생긴 사건을 급한 순서로 줄 세웁니다", sub: "한계까지 남은 시간이 짧을수록, 일의 우선순위가 높을수록 위" }, 3800);
  t.unspot();
  await t.click(BTN, "사건 상세 보기", { moveMs: 500, afterMs: 700 });
  await t.waitFor(".nx-callout");
  t.hideCursor();
  const forecast = await t.text(".nx-callout");
  await t.spot(".nx-split-main .nx-card", { tag: "사건 상세", title: "아무것도 하지 않으면?", sub: forecast }, 2800);
  t.unspot();
  await t.click(BTN, "회사 운영 정책 확인", { moveMs: 500, afterMs: 700 });

  // ---------- 3 판단 ----------
  await t.waitFor(".nx-funnel");
  t.hideCursor();
  await t.chapter(ch(2, "규칙 코드가 만들고, Zoro-1이 고른다"), 1100);
  t.stage(2);
  const f = funnelNums();
  await t.spot(
    ".nx-funnel",
    { tag: "운영 정책", title: `전략 ${f[0] ?? ""}개로 계획을 만들고, 검증된 상위 ${f[f.length - 1] ?? ""}개만 Zoro-1에 전달합니다`, sub: "연쇄 계획 → 정리 → Safety Gate → 열위 제거 · 규칙을 어기는 계획은 모델에 가지 않습니다" },
    4400,
  );
  t.unspot();
  await t.click(BTN, "정책 적용 후 AI 판단", { moveMs: 500, afterMs: 800 });
  await t.waitFor(".nx-verdict", undefined, WAIT_DECIDE);
  t.hideCursor();
  const j = await judge(t);
  await t.spot(
    ".nx-modelbar",
    j.zoro
      ? { tag: "의사결정 센터", title: "Zoro-1이 검증된 후보 안에서 고릅니다", sub: "같은 후보를 순서만 바꿔 여러 번 묻고, 가장 많이 1위인 계획을 택합니다" }
      : { tag: "의사결정 센터", title: "Zoro-1 응답이 없어 규칙 순위로 골랐습니다", sub: "모델이 실패해도 검증된 후보 안에서만 고릅니다" },
    4000,
  );
  const pick = await t.text(".nx-verdict-main strong");
  await t.spot(".nx-verdict", { tag: "의사결정 센터", title: `${j.zoro ? "Zoro-1" : "규칙"}의 선택: ${pick}`, sub: "한 계획으로 사건 3건을 함께 풉니다 · 아직 실행 전" }, 3600);
  t.unspot();
  await t.click(BTN, "대안별 결과 보기", { moveMs: 500, afterMs: 600 });
  await t.waitFor(".nx-ftable");
  t.caption({ tag: "대안별 결과", title: "계획마다 온도 · 에너지 · 완료 시간을 미리 비교합니다" });
  await t.sleep(1400);

  // ---------- 4 통제된 실행 ----------
  await t.chapter(ch(3, "AI가 골라도, 바로 실행되지 않는다"), 1100);
  t.stage(3);
  await t.click(BTN, "실행 전 안전 검사", { moveMs: 500, afterMs: 800 });
  await t.waitFor(".nx-banner--conditional, .nx-banner--allowed", undefined, WAIT_DECIDE);
  t.hideCursor();
  await t.spot(".nx-split-main .nx-card", { tag: "안전 검사", title: "모델과 분리된 코드가 한 번 더 검사합니다", sub: "P0 보호 · 자리 · 멈추기 규칙 · 열 한계 · 승인 권한" }, 3400);
  t.unspot();
  await t.click(BTN, "강제 입력 검사 실행", { moveMs: 500, afterMs: 600 });
  t.hideCursor();
  await t.spot(".nx-testpanel .nx-block-danger", { tag: "안전 검사", title: "규칙을 어기는 입력은 차단됩니다", sub: "P0 일 옮기기 → 실행 큐에서 제외 · 시도는 영수증에 기록" }, 3600);
  t.unspot();
  await t.click(BTN, "담당자 승인 요청", { moveMs: 500, afterMs: 800 });

  await t.waitFor(".nx-decide");
  t.hideCursor();
  const roles = neededRoles();
  t.caption({ tag: "협업 · 승인", title: `이 계획은 ${rolesText(roles)} 필요합니다`, sub: "단계마다 승인할 역할이 다릅니다" });
  await t.sleep(2400);
  await t.click(".nx-decide .nx-seg button", "관제 운영자", { moveMs: 500, afterMs: 300 });
  await t.click(BTN, "그래도 서버에 승인 요청 보내 보기", { moveMs: 500, afterMs: 500 });
  t.hideCursor();
  await t.spot(".nx-decide .nx-block-danger", { tag: "협업 · 승인", title: "권한 없는 승인은 거부됩니다", sub: "버튼 잠금 + 서버 거부, 두 겹" }, 3200);
  t.unspot();
  await approveAll(t, { read: 1100 });

  await t.waitFor(".nx-exec-banner", undefined, WAIT_DECIDE);
  t.hideCursor();
  await t.spot(".nx-kpis--3", { tag: "실행 및 결과", title: "가상 환경에서만 실행합니다", sub: "실제 설비 제어 없음 · 수치는 시뮬레이션" }, 3200);
  t.unspot();
  await t.click(BTN, "회차 결과 보기", { moveMs: 500, afterMs: 700 });
  await t.waitFor(".nx-rounds");
  t.hideCursor();
  await t.spot(".nx-banner", { tag: "회차 요약", title: "실행 뒤 상태로 남은 문제를 다시 계산합니다", sub: "남으면 다음 회차 · 안전한 계획이 없으면 사람에게 넘김" }, 3400);
  t.unspot();

  // ---------- 5 결정 영수증 ----------
  await t.chapter(ch(4, "모든 판단을 하나의 기록으로"), 1100);
  t.stage(4);
  await t.click(BTN, "결정 영수증 확인", { moveMs: 500, afterMs: 800 });
  await t.waitFor(".nx-timeline");
  t.hideCursor();
  await t.spot(".nx-receipt-rounds", { tag: "결정 영수증", title: "회차마다 사건 · 후보 · 선택 · 승인 · 결과를 남깁니다", sub: "차단된 시도와 거부된 승인까지" }, 3300);
  await t.spot(".nx-timeline", { tag: "결정 영수증", title: "누가, 언제, 무엇을 결정했는지 추적합니다" }, 2400);
  t.unspot();

  // ---------- 차별점 · 엔딩 ----------
  t.stage(-1);
  await t.chapter(
    {
      no: "",
      title: "NEXTERA가 다른 점",
      kind: "pitch",
      items: [
        { title: "겹친 사건을 한 계획으로", sub: "급한 순서로 정렬하고, 전략별 연쇄 계획으로 함께 푼다" },
        { title: "검증된 후보 안에서만 AI가 선택", sub: "규칙 코드가 걸러 낸 상위 후보를 Zoro-1이 고른다" },
        { title: "사람이 통제하는 실행과 기록", sub: "역할별 승인 · 실행 직전 재검사 · 결정 영수증" },
      ],
    },
    5000,
  );
  await t.chapter({ no: "", title: "Better Decisions. Better Operations.", sub: "NEXTERA · 더 나은 판단이 더 안전한 운영을 만듭니다", kind: "end" }, 2600);
  await t.go("/");
  window.scrollTo(0, 0);
}

# Brev 단일 서버 배포

NEXTERA 백엔드(포트 8000) 하나가 Zoro-1 모델을 직접 올리고(`zoro1_local`), 빌드된 화면까지 서빙한다.

이 인스턴스(드라이버 565.57, CUDA 12.7)에서는 SGLang 서버가 CUDA 13에 묶여 있어 뜨지 않는다. 그래서 모델 폴더의
`zoro_decide.py`(Decider)를 백엔드 안에서 직접 쓴다. PyTorch는 CUDA 12.6용(`2.14.1+cu126`)으로 설치되어 있어야 한다.

## 1. 코드 올리기

JupyterLab 왼쪽 파일 목록에 `NEXTERA_v12_integrated.zip`을 끌어다 놓는다. 이전 폴더가 있으면 이름을 바꿔 보존한 뒤 푼다
(이전 실행 로그 `backend/runs`와 DB가 그 안에 남는다).

```bash
cd ~ && [ -d NEXTERA ] && mv NEXTERA NEXTERA_old_$(date +%H%M); python -m zipfile -e NEXTERA_v12_integrated.zip .
```

## 2. 백엔드 실행 (tmux 세션)

```bash
tmux new -s api
source ~/zoro-env/bin/activate            # torch·transformers·fastapi·uvicorn 이 이미 들어 있는 환경
export HF_TOKEN=...                        # 읽기 전용 토큰
export SNAP=/ephemeral/cache/huggingface/hub/models--trillionlabs--Zoro-1/snapshots/bf1b76b9b4df03b05fcbb73444e1cd4db0f566da
export NEXTERA_PROVIDER=zoro1_local ZORO1_SNAPSHOT_DIR=$SNAP
cd ~/NEXTERA/backend
python -m uvicorn app.main:app --host 0.0.0.0 --port 8000
```

시작하면서 모델을 미리 올린다("Zoro-1 모델 로드 완료" 로그). `Ctrl+B` 다음 `D`로 빠져나온다.

## 3. 확인 (다른 터미널)

```bash
curl -s localhost:8000/api/health
curl -s -X POST localhost:8000/api/decide -H 'content-type: application/json' \
  -d '{"incident_id":"INC-0412","snapshot_id":"S0","policy_version":"1.2"}' > decide.json
python3 -c "import json; d=json.load(open('decide.json'))['decision']; print(d['provider'], d['decision_mode'], d['selected_id'], d['probs'], d['latency_ms'], d['fallback_reason'], d['model_error'])"
```

`provider`가 `zoro1`이고 `probs`가 채워져 있으면 실제 모델로 판단한 것이다. `rule`이면 뒤의 `fallback_reason`과 `model_error`를 본다.

## 4. 프론트 빌드

빌드본은 설정 없이 live 모드이고 같은 서버의 `/api`를 부른다. 서버에 Node가 없으면 먼저 설치한다(관리자 권한 불필요).

```bash
node -v || { curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.1/install.sh | bash; source ~/.nvm/nvm.sh; nvm install 22; }
cd ~/NEXTERA/frontend
npm install
npm run build                  # frontend/dist 생성 (타입 검사 후 빌드)
```

타입 검사에서 막히면 오류 메시지를 확인하고, 급하면 `npx vite build`로 빌드만 할 수 있다.
자기 PC에서 빌드했다면 `frontend/dist` 폴더를 서버의 `~/NEXTERA/frontend/dist`로 올린다.
백엔드는 요청 때마다 `dist`를 읽으므로 다시 띄울 필요가 없다. 브라우저에서 `http://<서버>:8000/`을 연다.

## 5. 외부 공개

Brev 콘솔의 인스턴스 화면에서 포트 8000을 공개하고, 로그인하지 않은 기기로 열리는지 확인한 뒤 그 주소로 QR을 만든다.

## 6. 제출용 실행 로그

백엔드 서버와 모델을 동시에 두 번 올리지 않도록, 서버를 잠시 내리고 실행한다.

```bash
cd ~/NEXTERA/backend
python eval_runner.py --zoro-backend zoro1_local --quick      # 먼저 짧게
python eval_runner.py --zoro-backend zoro1_local               # 전체 매트릭스
ls runs/eval_*/submission_logs/
```

## 재시작 시

tmux 세션은 재부팅하면 사라진다. 2번을 다시 실행한다. SQLite(`backend/nextera.db`)의 영수증은 남는다.
모델은 `/ephemeral` 아래에 있어 인스턴스를 Stop하면 지워질 수 있다. 종료 전까지 Stop하지 않는다.


## 다중 작업 버전 (`/api/v2`, 프론트 v12가 사용)

노드 1~6개·일 1~10개·계획 후보·회차 반복을 지원하는 백엔드가 `backend/app/multi/`에 들어 있다. 기존 화면과 `/api/*`에는 영향이 없다.
호출 규격은 `backend/MULTI_API.md`. 화면 없이 실제 모델로 확인하려면:

```
cd ~/NEXTERA/backend && python multi_demo.py --provider zoro1_local
```

"""실제 HTTP 서버(uvicorn)를 띄워 프론트가 부르는 방식 그대로 확인한다."""
from __future__ import annotations

import json
import os
import socket
import threading
import time
import urllib.error
import urllib.request

import pytest

uvicorn = pytest.importorskip("uvicorn")


def _free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


@pytest.fixture(scope="module")
def base(tmp_path_factory):
    tmp = tmp_path_factory.mktemp("srv")
    dist = tmp / "dist"
    (dist / "assets").mkdir(parents=True)
    (dist / "index.html").write_text("<!doctype html><title>NEXTERA test</title>", encoding="utf-8")
    (dist / "assets" / "app.js").write_text("console.log('ok')", encoding="utf-8")
    os.environ.update({"NEXTERA_PROVIDER": "rule", "NEXTERA_DB": str(tmp / "t.db"), "NEXTERA_DIST": str(dist)})
    from app import main

    port = _free_port()
    server = uvicorn.Server(uvicorn.Config(main.app, host="127.0.0.1", port=port, log_level="warning"))
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()
    for _ in range(100):
        if server.started:
            break
        time.sleep(0.05)
    yield f"http://127.0.0.1:{port}"
    server.should_exit = True
    thread.join(timeout=5)


_opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))


def http(base, method, path, body=None, role="operator", session="h1", raw=False):
    data = None if body is None else (body if isinstance(body, bytes) else json.dumps(body).encode())
    req = urllib.request.Request(base + path, data=data, method=method,
                                 headers={"Content-Type": "application/json", "X-Role": role, "X-Session": session})
    try:
        with _opener.open(req, timeout=10) as r:
            text = r.read().decode()
            return r.status, (text if raw else json.loads(text)), dict(r.headers)
    except urllib.error.HTTPError as e:
        text = e.read().decode()
        return e.code, (text if raw else json.loads(text)), dict(e.headers)


def test_http_api_and_error_shape(base):
    st, health, _ = http(base, "GET", "/api/health")
    assert st == 200 and health["status"] == "ok" and health["provider_mode"] == "rule"
    st, state, _ = http(base, "GET", "/api/state?snapshot=S0")
    assert st == 200 and state["snapshot_id"] == "S0" and len(state["nodes"]) == 6
    st, dec, _ = http(base, "POST", "/api/decide", {"incident_id": "INC-0412", "snapshot_id": "S0", "policy_version": "1.2"})
    assert st == 200 and dec["decision"]["selected_id"] == "A-MIG-J07-N2"
    st, v, _ = http(base, "POST", "/api/validate", {"decision_id": "DR-0412-01", "action_id": "A-MIG-J07-N2", "origin": "model"})
    st, err, _ = http(base, "POST", f"/api/approvals/{v['approval_id']}/decision", {"action": "approve", "idempotency_key": "x"}, role="cooling_A")
    assert st == 403 and err == {"error": {"code": "ROLE_FORBIDDEN", "message": err["error"]["message"], "policy_id": "POL-04"}}
    st, err, _ = http(base, "POST", "/api/decide", b"{not json")
    assert st == 400 and err["error"]["code"] == "INVALID_REQUEST"
    st, err, _ = http(base, "GET", "/api/unknown")
    assert st == 404 and err["error"]["code"] == "NOT_FOUND"
    st, other, _ = http(base, "GET", "/api/receipts", session="h2")
    assert st == 200 and other == []                                    # 세션 분리
    st, reset, _ = http(base, "POST", "/api/demo/reset")                # 본문 없는 POST
    assert st == 200 and reset == {"snapshot_id": "S0", "scenario": {}}


def test_http_serves_frontend_with_spa_fallback(base):
    st, html, _ = http(base, "GET", "/", raw=True)
    assert st == 200 and "NEXTERA test" in html
    st, js, _ = http(base, "GET", "/assets/app.js", raw=True)
    assert st == 200 and "console.log" in js
    st, html, _ = http(base, "GET", "/approvals/APR-0412-01", raw=True)   # 새로고침해도 화면이 열린다
    assert st == 200 and "NEXTERA test" in html
    st, html, _ = http(base, "GET", "/../../etc/passwd", raw=True)
    assert "root:" not in html


def test_http_cors_preflight(base):
    req = urllib.request.Request(base + "/api/decide", method="OPTIONS", headers={
        "Origin": "http://localhost:5173", "Access-Control-Request-Method": "POST",
        "Access-Control-Request-Headers": "content-type,x-role,x-session"})
    with _opener.open(req, timeout=10) as r:
        assert r.status == 200
        allowed = r.headers.get("access-control-allow-headers", "").lower()
        assert "x-role" in allowed and "x-session" in allowed

"""백엔드 테스트. 실행: (backend 폴더에서) python -m pytest -q

실제 Zoro-1 을 부르지 않는다. 모델 경로는 tests/fake_zoro.py(테스트용 가짜 서버)로 확인한다.
"""
from __future__ import annotations

import copy

import pytest

from app import api, config, engine, safety_gate
from app.candidates import build_candidates, find
from app.providers import Zoro1HttpAdapter, get_provider
from app.service import NexteraService
from app.simulator import simulate
from tests.fake_zoro import FakeZoro

DID = "DR-0412-01"


@pytest.fixture()
def world():
    return {
        "snap": config.load_snapshot("seed:snapshot_S0.json"), "physics": config.load_physics(),
        "policy": config.load_policy(), "cfg": config.load_decision_cfg(), "incident": config.load_incident("INC-0412"),
    }


def make_service(provider="rule", **overrides):
    return NexteraService(db_path=":memory:", provider_mode=provider, overrides=overrides or None)


def call(sv, method, path, body=None, role="operator", q=None, session="t"):
    return api.dispatch(sv, method, path, q or {}, body, {"X-Role": role, "X-Session": session})


def ok(sv, *a, **kw):
    status, payload = call(sv, *a, **kw)
    assert status == 200, payload
    return payload


# ------------------------------------------------------------------ 코어
def test_candidates_seven_to_five(world):
    cands = build_candidates(world["snap"], world["incident"], world["policy"])
    assert len(cands) == 7
    assert [c["id"] for c in cands if not c["filtered_out"]] == ["A-COOL-Z2-UP", "A-MIG-J07-N2", "A-DEF-J08-30", "A-INFO", "A-ESC"]
    assert {c["id"]: c["filter_reason"] for c in cands if c["filtered_out"]} == {"A-MIG-J07-N3": "POL-03", "A-DEF-J09": "POL-01"}
    assert find(cands, "A-MIG-J07-N2")["requires_approval_role"] == "gpu_B"
    assert find(cands, "A-COOL-Z2-UP")["requires_approval_role"] == "cooling_A"


def test_simulator_no_action_violates_and_actions_help(world):
    cands = build_candidates(world["snap"], world["incident"], world["policy"])
    base = simulate(world["snap"], world["physics"], world["policy"], None)
    assert base["ticks"] == 16 and base["horizon_s"] == 480
    assert base["violates_limit"] and base["peak_node"] == "N4"
    cool = simulate(world["snap"], world["physics"], world["policy"], find(cands, "A-COOL-Z2-UP"))
    mig = simulate(world["snap"], world["physics"], world["policy"], find(cands, "A-MIG-J07-N2"))
    assert not cool["violates_limit"] and not mig["violates_limit"]
    assert cool["cooling_kwh"] > base["cooling_kwh"]           # 냉각 강화는 에너지를 더 쓴다
    assert mig["jobs"]["J07"]["finish_s"] > cool["jobs"]["J07"]["finish_s"]  # 이동은 재시작만큼 늦다
    # 시드와의 일관성: t=0 의 발열이 관측 전력과 같다(상승 중인 N4 외에는 온도가 유지된다)
    assert abs(base["series"]["N6"][1] - base["series"]["N6"][0]) < 1e-6


def test_simulation_is_deterministic(world):
    a = simulate(world["snap"], world["physics"], world["policy"], None)
    b = simulate(copy.deepcopy(world["snap"]), copy.deepcopy(world["physics"]), world["policy"], None)
    assert a["series"] == b["series"] and a["cooling_kwh"] == b["cooling_kwh"]


def test_safety_gate_blocks_hard_rules(world):
    cands = build_candidates(world["snap"], world["incident"], world["policy"])
    g = safety_gate.check_action(find(cands, "A-MIG-J07-N3"), world["snap"], world["policy"], world["physics"])
    assert g["verdict"] == "blocked" and g["hard_violations"] == ["POL-03"]
    g = safety_gate.check_action(find(cands, "A-DEF-J09"), world["snap"], world["policy"], world["physics"])
    assert g["verdict"] == "blocked" and "POL-01" in g["hard_violations"]
    g = safety_gate.check_action(find(cands, "A-DEF-J08-30"), world["snap"], world["policy"], world["physics"])
    assert g["verdict"] == "blocked" and g["hard_violations"] == ["POL-02"]
    g = safety_gate.check_action(find(cands, "A-MIG-J07-N2"), world["snap"], world["policy"], world["physics"])
    assert g["verdict"] == "conditional" and not g["hard_violations"]
    g = safety_gate.check_action({"id": "X", "type": "delete_everything", "params": {}}, world["snap"], world["policy"], world["physics"])
    assert g["verdict"] == "blocked"  # 알 수 없는 행동은 차단


def test_gate_ignores_caller_supplied_numbers(world):
    cands = build_candidates(world["snap"], world["incident"], world["policy"])
    bad = dict(find(cands, "A-DEF-J08-30"), predicted_peak_temp_c=60.0, probability=0.99)
    assert safety_gate.check_action(bad, world["snap"], world["policy"], world["physics"])["verdict"] == "blocked"


def test_approval_authority(world):
    cands = build_candidates(world["snap"], world["incident"], world["policy"])
    roles = config.load_roles()
    mig, cool = find(cands, "A-MIG-J07-N2"), find(cands, "A-COOL-Z2-UP")
    assert safety_gate.check_approval(mig, "gpu_B", world["policy"], roles)["ok"]
    assert not safety_gate.check_approval(mig, "cooling_A", world["policy"], roles)["ok"]
    assert safety_gate.check_approval(cool, "cooling_A", world["policy"], roles)["ok"]
    assert not safety_gate.check_approval(cool, "gpu_B", world["policy"], roles)["ok"]
    assert not safety_gate.check_approval(mig, "operator", world["policy"], roles)["ok"]


def _rule_pick(world, changes):
    snap, physics, objective = engine.apply_changes(world["snap"], world["incident"], world["physics"], changes)
    prep = engine.prepare(snap, world["incident"], world["policy"], physics, world["cfg"], objective)
    return engine.decide(prep, get_provider("rule", world["cfg"])), prep


def test_deadline_ab_changes_rule_choice(world):
    assert _rule_pick(world, {})[0]["selected_id"] == "A-MIG-J07-N2"
    assert _rule_pick(world, {"deadline_min": 3})[0]["selected_id"] == "A-COOL-Z2-UP"
    assert _rule_pick(world, {"deadline_min": 8})[0]["selected_id"] == "A-MIG-J07-N2"


def test_same_five_minute_condition_gives_identical_numbers(world):
    base, prep_a = _rule_pick(world, {})
    same, prep_b = _rule_pick(world, {"deadline_min": 5})
    assert base["selected_id"] == same["selected_id"]
    for cid in prep_a.sims:
        for key in ("cooling_kwh", "total_kwh", "peak_temp_c", "completed_work_gpu_s"):
            assert prep_a.sims[cid][key] == prep_b.sims[cid][key]


def test_experiment_filters_and_escalation(world):
    out, prep = _rule_pick(world, {"n2_gpus_free": 4})
    assert find(prep.candidates, "A-MIG-J07-N2")["filter_reason"] == "POL-03" and out["selected_id"] == "A-COOL-Z2-UP"
    out, prep = _rule_pick(world, {"j07_priority": "P0"})
    assert find(prep.candidates, "A-MIG-J07-N2")["filter_reason"] == "POL-01"
    out, prep = _rule_pick(world, {"cooling_max": 3, "n2_gpus_free": 0})
    assert out["selected_id"] == "A-ESC" and out["decision_mode"] == "rule_handoff"   # 안전한 실행 후보가 없으면 사람에게 넘김
    with pytest.raises(engine.ChangeError):
        engine.apply_changes(world["snap"], world["incident"], world["physics"], {"deadlin_min": 3})


def test_override_rejects_unknown_key():
    with pytest.raises(config.OverrideError):
        config.load_physics({"rollout_tick": 10})
    assert config.load_physics({"rollout_ticks": 10})["rollout_ticks"] == 10


# ------------------------------------------------------------------ Zoro-1 어댑터 (가짜 서버)
def _zoro_decide(world, fake, **kw):
    cfg = copy.deepcopy(world["cfg"])
    cfg["zoro1"].update({"url": fake.url, "timeout_s": 1, "reasoning_timeout_s": 2})
    snap, physics, objective = engine.apply_changes(world["snap"], world["incident"], world["physics"], {})
    prep = engine.prepare(snap, world["incident"], world["policy"], physics, cfg, objective)
    return engine.decide(prep, Zoro1HttpAdapter(cfg), **kw)


def test_zoro_request_format_and_valid_response(world):
    with FakeZoro(pick="A-COOL-Z2-UP", top_prob=0.8) as fake:
        out = _zoro_decide(world, fake)
    sent = fake.requests[0]
    assert set(sent) == {"request", "reasoning", "max_reasoning_tokens"}      # temperature 는 기본값이면 생략
    assert sent["reasoning"] is False and sent["max_reasoning_tokens"] == 4096
    q = sent["request"]["questions"]
    assert q["action"]["type"] == "choice" and list(q["action"]["criteria"]) == ["A-COOL-Z2-UP", "A-MIG-J07-N2", "A-DEF-J08-30"]
    assert q["memo_thermal_risk"]["type"] == "noul" and q["risk_level"]["criteria"] == ["low", "elevated", "critical"]
    assert sent["request"]["state"]["ops_notes"][0]["text"] == "N4 팬 교체 필요, 부하 자제 요청"   # 메모 원문 그대로
    assert out["provider"] == "zoro1" and out["decision_mode"] == "direct" and out["is_real_model"]
    assert out["selected_id"] == "A-COOL-Z2-UP" and abs(sum(out["probs"].values()) - 1.0) < 1e-6
    assert out["fallback_reason"] is None and out["rationale"] is None
    assert out["raw_extra_fields"]["direct"]["timing_ms"] == 496.1                    # 모르는 키 보존
    assert out["diagnostics"]["memo_thermal_risk"]["p"] == 0.93
    assert out["diagnostics"]["risk_level"]["label"] == "critical"


def test_zoro_temperature_override_is_sent(world):
    with FakeZoro() as fake:
        _zoro_decide(world, fake, temperature=1.0)
    assert fake.requests[0]["temperature"] == 1.0


@pytest.mark.parametrize("behavior,code", [
    ("bad_sum", "INVALID_OUTPUT"), ("unknown_id", "INVALID_OUTPUT"), ("missing_id", "INVALID_OUTPUT"),
    ("missing_answer", "INVALID_OUTPUT"), ("bad_json", "INVALID_OUTPUT"), ("http_500", "ZORO1_HTTP_ERROR"),
])
def test_zoro_invalid_response_falls_back_to_rule(world, behavior, code):
    with FakeZoro(behavior=behavior) as fake:
        out = _zoro_decide(world, fake)
    assert out["provider"] == "rule" and out["decision_mode"] == "rule_fallback" and out["is_fallback"]
    assert out["fallback_reason"] == code and out["model_error"]["source"] == "zoro1_http"
    assert out["probs"] is None and out["selected_id"] == "A-MIG-J07-N2"
    assert not out["is_real_model"]


def test_zoro_timeout_and_unreachable(world):
    with FakeZoro(delay_s=1.6) as fake:
        out = _zoro_decide(world, fake)
    assert out["fallback_reason"] == "TIMEOUT" and out["provider"] == "rule"
    cfg = copy.deepcopy(world["cfg"])
    cfg["zoro1"]["url"] = "http://127.0.0.1:9/v1/decide"
    snap, physics, objective = engine.apply_changes(world["snap"], world["incident"], world["physics"], {})
    prep = engine.prepare(snap, world["incident"], world["policy"], physics, cfg, objective)
    out = engine.decide(prep, Zoro1HttpAdapter(cfg))
    assert out["fallback_reason"] == "ZORO1_UNREACHABLE"


def test_zoro_escalation_replaces_only_unsure_answers(world):
    with FakeZoro(behavior="low_conf", pick="A-MIG-J07-N2") as fake:
        out = _zoro_decide(world, fake, enable_escalation=True, escalation_threshold=0.7)
        direct_only = _zoro_decide(world, fake, enable_escalation=False)
    assert [r["reasoning"] for r in fake.requests[:2]] == [False, True]
    assert out["decision_mode"] == "escalated_reasoned" and out["escalated_questions"] == ["action"]
    # score 질문은 확률이 갈려도(0.51) 에스컬레이션 대상이 아니다(escalation_questions = ["action"])
    assert out["direct_probs"]["A-MIG-J07-N2"] == pytest.approx(0.4) and out["probs"]["A-MIG-J07-N2"] == pytest.approx(0.9)
    assert "test reasoning text" in out["reasoning_text"] and out["rationale"] is None
    assert out["raw_extra_fields"]["escalated"]["reasoning_ms"] == 25837.1
    assert direct_only["decision_mode"] == "direct" and direct_only["review"]["needs_review"]   # 0.4 < 0.55


def test_model_choice_violating_hard_rule_is_blocked_and_modified(world):
    with FakeZoro(pick="A-DEF-J08-30", top_prob=0.6) as fake:
        out = _zoro_decide(world, fake)
    assert out["proposed_id"] == "A-DEF-J08-30" and out["modified_after_block"]
    assert out["blocked"]["violations"] == ["POL-02"]
    assert out["selected_id"] in ("A-COOL-Z2-UP", "A-MIG-J07-N2")
    assert out["review"]["needs_review"]


def test_fault_injection_never_calls_model(world):
    with FakeZoro() as fake:
        cfg = copy.deepcopy(world["cfg"])
        cfg["zoro1"]["url"] = fake.url
        snap, physics, objective = engine.apply_changes(world["snap"], world["incident"], world["physics"], {})
        prep = engine.prepare(snap, world["incident"], world["policy"], physics, cfg, objective)
        out = engine.decide(prep, Zoro1HttpAdapter(cfg, fault_mode="timeout"))
    assert fake.requests == [] and out["fallback_reason"] == "TIMEOUT" and out["provider"] == "rule"


# ------------------------------------------------------------------ API 흐름
def test_full_demo_flow_with_rule_provider():
    sv = make_service("rule")
    assert ok(sv, "GET", "/api/health")["provider_mode"] == "rule"
    inc = ok(sv, "GET", "/api/incidents/INC-0412")
    assert inc["severity"] == "high" and inc["status"] == "needs_decision"
    assert "POL-02" in inc["no_action_forecast"]["violations"] and inc["no_action_forecast"]["horizon_ticks"] == 16
    assert len(ok(sv, "GET", "/api/policies", q={"version": "1.2"})["candidates"]) == 7

    d = ok(sv, "POST", "/api/decide", {"incident_id": "INC-0412", "snapshot_id": "S0", "policy_version": "1.2"})["decision"]
    assert d["decision_id"] == DID and d["provider"] == "rule" and d["selected_id"] == "A-MIG-J07-N2" and d["probs"] is None

    exp = ok(sv, "POST", "/api/experiments", {"decision_id": DID, "base_snapshot_id": "S0", "changes": {"deadline_min": 3}, "policy_version": "1.2"})
    assert exp["branch_id"] == "S0-b1" and exp["decision"]["selected_id"] == "A-COOL-Z2-UP"
    cmp_ = ok(sv, "GET", "/api/experiments/S0-b1/compare")
    assert cmp_["changed_keys"] == ["deadline_min"] and cmp_["base"]["decision"]["selected_id"] == "A-MIG-J07-N2"
    cf = ok(sv, "POST", "/api/futures", {"decision_id": DID, "snapshot_id": "S0-b1", "action_ids": ["A-MIG-J07-N2"], "horizon_ticks": 10})["estimates"][0]
    assert cf["horizon_ticks"] == 16 and cf["deadline_slack_min"]["J07"] < 0 and "DEADLINE_MISS" in cf["violations"]

    v = ok(sv, "POST", "/api/validate", {"decision_id": DID, "action_id": "A-MIG-J07-N2", "origin": "model"})
    assert v["verdict"] == "conditional" and v["approval_id"] == "APR-0412-01"
    forced = ok(sv, "POST", "/api/validate", {"decision_id": DID, "action_id": "A-MIG-J07-N3", "origin": "operator_forced"})
    assert forced["verdict"] == "blocked" and forced["approval_id"] is None
    assert any(c["policy_id"] == "POL-03" and c["result"] == "fail" for c in forced["checks"])

    aid = v["approval_id"]
    status, err = call(sv, "POST", "/api/execute", {"approval_id": aid, "idempotency_key": "k0"})
    assert status == 403 and err["error"]["code"] == "ROLE_FORBIDDEN"                       # 승인 전 실행 불가
    status, err = call(sv, "POST", f"/api/approvals/{aid}/decision", {"action": "approve", "idempotency_key": "a1"}, role="cooling_A")
    assert status == 403 and err["error"] == {"code": "ROLE_FORBIDDEN", "message": err["error"]["message"], "policy_id": "POL-04"}
    assert ok(sv, "GET", f"/api/approvals/{aid}")["status"] == "pending"                    # 거부 후에도 그대로
    ap = ok(sv, "POST", f"/api/approvals/{aid}/decision", {"action": "approve", "idempotency_key": "a2"}, role="gpu_B")
    assert ap["status"] == "approved" and ap["decided_by"] == "gpu_B"
    assert ok(sv, "POST", f"/api/approvals/{aid}/decision", {"action": "approve", "idempotency_key": "a2"}, role="gpu_B")["status"] == "approved"

    exe = ok(sv, "POST", "/api/execute", {"approval_id": aid, "idempotency_key": "k1"})
    assert exe["status"] == "succeeded" and exe["sla"]["met"] and all(c["result"] == "pass" for c in exe["recheck"])
    # 실행 후 스냅샷은 예측 구간의 끝(8분 뒤): J07 은 N2 로 옮겨져 완료됐고, N4 는 비어서 식었다
    j07 = next(j for j in exe["after"]["jobs"] if j["id"] == "J07")
    n4_before = next(n for n in exe["before"]["nodes"] if n["id"] == "N4")
    n4_after = next(n for n in exe["after"]["nodes"] if n["id"] == "N4")
    assert j07["node_id"] == "N2" and j07["status"] == "done" and exe["after"]["source"] == "sim_executed"
    assert n4_after["temp_c"] < n4_before["temp_c"] and n4_after["job_ids"] == [] and n4_after["gpus_free"] == 8
    assert exe["after"]["sim_time"] == "14:08:00"
    assert ok(sv, "POST", "/api/execute", {"approval_id": aid, "idempotency_key": "k1"})["execution_id"] == exe["execution_id"]
    status, err = call(sv, "POST", "/api/execute", {"approval_id": aid, "idempotency_key": "k2"})
    assert status == 409 and err["error"]["code"] == "ALREADY_EXECUTED"                     # 중복 실행 방지
    assert ok(sv, "GET", "/api/state")["nodes"][3]["job_ids"] == ["J07"]                    # S0 는 그대로 보존

    rc = ok(sv, "GET", f"/api/receipts/{DID}")
    types = [e["type"] for e in rc["events"]]
    assert rc["status"] == "executed" and [e["seq"] for e in rc["events"]] == list(range(1, len(types) + 1))
    for needed in ("incident_detected", "policy_applied", "decision_made", "experiment_run", "futures_simulated",
                   "validated", "blocked", "approval_requested", "approved", "rechecked", "executed"):
        assert needed in types, needed
    assert any(e["type"] == "blocked" and e["actor"] == "cooling_A" for e in rc["events"])   # 권한 거부 기록
    assert [b["branch_id"] for b in rc["branches"]] == ["S0", "S0-b1"] and rc["branches"][1]["changes"] == {"deadline_min": 3}
    assert next(c for c in rc["candidates"] if c["id"] == "A-MIG-J07-N3")["origin"] == "operator_forced"
    assert ok(sv, "GET", "/api/incidents/INC-0412")["status"] == "executed"
    an = ok(sv, "GET", "/api/analytics", q={"scenario": "전체", "policy": "v1.2", "period": "최근 7일", "result": "전체"})
    assert an["is_example"] is False and an["results"]["succeeded"] == 1 and an["blocked_attempts"] >= 2
    assert an["by_type"] == [{"type": "열 위험", "decisions": 2, "missed": 0}]
    assert {p["pattern"] for p in an["patterns"]} >= {"여유 없는 노드로 강제 이동 시도", "권한 없는 승인 시도"}
    assert all(p["decision_id"] == DID and p["count"] >= 1 and p["action"] for p in an["patterns"])
    # 프론트(병렬 미래)는 job_finish_min 의 우선 작업 외 항목을 "지연"으로 그린다: 영향받은 작업만 들어 있어야 한다
    fut = ok(sv, "POST", "/api/futures", {"decision_id": DID, "snapshot_id": "S0", "action_ids": ["A-COOL-Z2-UP", "A-MIG-J07-N2", "A-DEF-J08-30"], "horizon_ticks": 10})["estimates"]
    assert [sorted(e["job_finish_min"]) for e in fut] == [["J07"], ["J07"], ["J07", "J08"]]
    assert len(ok(sv, "GET", f"/api/receipts/{DID}/log")["runs"]) == 2


def test_state_drift_holds_execution():
    sv = make_service("rule")
    ok(sv, "POST", "/api/decide", {"incident_id": "INC-0412", "snapshot_id": "S0", "policy_version": "1.2"})
    v = ok(sv, "POST", "/api/validate", {"decision_id": DID, "action_id": "A-MIG-J07-N2", "origin": "model"})
    ok(sv, "POST", f"/api/approvals/{v['approval_id']}/decision", {"action": "approve", "idempotency_key": "a"}, role="gpu_B")
    ok(sv, "POST", "/api/demo/drift", {"node_id": "N2", "gpus_free": 0})       # 승인 뒤 N2 여유가 사라짐
    exe = ok(sv, "POST", "/api/execute", {"approval_id": v["approval_id"], "idempotency_key": "k"})
    assert exe["status"] == "held" and exe["after"] == exe["before"]
    failed = {c["name"] for c in exe["recheck"] if c["result"] == "fail"}
    assert {"상태", "대상 노드 용량"} <= failed
    assert ok(sv, "GET", f"/api/receipts/{DID}")["status"] == "held"


def test_fault_injection_via_api_and_recovery():
    with FakeZoro(pick="A-COOL-Z2-UP") as fake:
        sv = make_service("zoro1", decision={"zoro1.url": fake.url})
        body = {"incident_id": "INC-0412", "snapshot_id": "S0", "policy_version": "1.2"}
        d1 = ok(sv, "POST", "/api/decide", body)["decision"]
        assert d1["provider"] == "zoro1" and d1["probs"] and d1["fallback_reason"] is None
        ok(sv, "POST", "/api/demo/fault", {"mode": "invalid"})
        d2 = ok(sv, "POST", "/api/decide", body)["decision"]
        assert d2["provider"] == "rule" and d2["fallback_reason"] == "INVALID_OUTPUT" and d2["fault_injected"] and d2["probs"] is None
        ok(sv, "POST", "/api/demo/fault", {"mode": "off"})
        assert ok(sv, "POST", "/api/decide", body)["decision"]["provider"] == "zoro1"
        events = ok(sv, "GET", f"/api/receipts/{DID}")["events"]
        assert any(e["type"] == "model_error" and "장애 주입" in e["summary"] for e in events)
        assert any(e["type"] == "fallback" for e in events)
        real = [e for e in events if e["type"] == "decision_made" and e.get("provider") == "zoro1"]
        assert real and "zoro1_request" in real[0]["data"]                     # 실제 호출의 요청·응답 보존


def test_sessions_are_isolated_and_reset_works():
    sv = make_service("rule")
    body = {"incident_id": "INC-0412", "snapshot_id": "S0", "policy_version": "1.2"}
    ok(sv, "POST", "/api/decide", body, session="judge1")
    assert ok(sv, "GET", "/api/receipts", session="judge1") and ok(sv, "GET", "/api/receipts", session="judge2") == []
    ok(sv, "POST", "/api/demo/reset", session="judge2")
    assert len(ok(sv, "GET", "/api/receipts", session="judge1")) == 1
    ok(sv, "POST", "/api/demo/reset", session="judge1")
    assert ok(sv, "GET", "/api/receipts", session="judge1") == []


def test_error_format_and_bad_input():
    sv = make_service("rule")
    for args, status, code in [
        (("GET", "/api/incidents/INC-9999"), 404, "NOT_FOUND"),
        (("GET", "/api/state"), 200, None),
        (("GET", "/api/nope"), 404, "NOT_FOUND"),
        (("POST", "/api/validate", {"decision_id": DID, "action_id": "A-XXX", "origin": "model"}), 400, "INVALID_REQUEST"),
        (("POST", "/api/experiments", {"decision_id": DID, "base_snapshot_id": "S0", "changes": {"deadline_min": "soon"}}), 400, "INVALID_REQUEST"),
        (("POST", "/api/execute", {"decision_id": DID, "action_id": "A-MIG-J07-N2", "idempotency_key": "k"}), 403, "ROLE_FORBIDDEN"),
        (("POST", "/api/decide", {"snapshot_id": "S9"}), 404, "NOT_FOUND"),
    ]:
        st, payload = call(sv, *args)
        assert st == status, (args, payload)
        if code:
            assert payload["error"]["code"] == code and payload["error"]["message"]
    st, payload = call(sv, "GET", "/api/health", role="hacker")
    assert st == 200                                                              # 역할은 승인 요청에서만 검사
    st, payload = call(sv, "POST", "/api/approvals/APR-0412-01/comments", {"text": "x"}, role="hacker")
    assert st in (400, 404)


def test_real_zoro_response_shape_is_accepted(world):
    """2026-11-19 Brev 에서 zoro_decide.py 가 실제로 돌려준 응답. 검증·진단 추출이 이 형식을 받아들이는지 확인한다."""
    from app.providers.base import answer_confidence, validate_answers

    real = {
        "answers": {
            "action": {"type": "choice", "choice": "A-MIG-J07-N2", "confidence": 0.9518,
                       "probabilities": {"A-COOL-Z2-UP": 0.0289, "A-MIG-J07-N2": 0.9678, "A-DEF-J08-30": 0.0033}},
            "memo_thermal_risk": {"type": "noul", "noul": 0.8744},
            "risk_level": {"type": "score", "score": 1.4888, "legend": ["low", "elevated", "critical"], "confidence": 0.2333,
                           "probabilities": {"0": 0.0227, "1": 0.4657, "2": 0.5116}},
        },
        "timing_ms": 496.1,
    }
    questions = {
        "action": {"type": "choice", "criteria": {"A-COOL-Z2-UP": "", "A-MIG-J07-N2": "", "A-DEF-J08-30": ""}},
        "memo_thermal_risk": {"type": "noul"},
        "risk_level": {"type": "score", "criteria": ["low", "elevated", "critical"]},
    }
    problems, warnings = validate_answers(questions, real["answers"], world["cfg"]["prob_sum_tolerance"])
    assert problems == {} and warnings == []
    assert answer_confidence(real["answers"]["action"]) == 0.9678
    assert answer_confidence(real["answers"]["risk_level"]) == 0.5116
    diag = engine._diagnostics(real["answers"])
    assert diag["memo_thermal_risk"]["p"] == 0.8744 and diag["risk_level"]["label"] == "elevated"


def test_handoff_when_no_action_meets_deadline_and_rules(world):
    """마감 2분: 어떤 설비 조작도 마감 안에 끝나지 않는다 → 모델을 부르지 않고 사람에게 넘긴다(프론트 v9 '사람에게 넘김' 흐름)."""
    with FakeZoro(pick="A-COOL-Z2-UP") as fake:
        cfg = copy.deepcopy(world["cfg"])
        cfg["zoro1"]["url"] = fake.url
        snap, physics, objective = engine.apply_changes(world["snap"], world["incident"], world["physics"], {"deadline_min": 2})
        prep = engine.prepare(snap, world["incident"], world["policy"], physics, cfg, objective)
        out = engine.decide(prep, Zoro1HttpAdapter(cfg))
    assert fake.requests == []                                   # 고를 수 있는 안전한 행동이 없으면 모델을 부르지 않는다
    assert out["selected_id"] == "A-ESC" and out["provider"] == "rule" and out["decision_mode"] == "rule_handoff"
    assert out["fallback_reason"] == "NO_FEASIBLE_ACTION" and not out["is_fallback"] and out["probs"] is None
    assert "마감" in out["rationale"] and "POL-02" in out["rationale"]

    sv = make_service("rule")
    ok(sv, "POST", "/api/decide", {"incident_id": "INC-0412", "snapshot_id": "S0", "policy_version": "1.2"})
    exp = ok(sv, "POST", "/api/experiments", {"decision_id": DID, "base_snapshot_id": "S0", "changes": {"deadline_min": 2}, "policy_version": "1.2"})
    assert exp["decision"]["selected_id"] == "A-ESC" and exp["estimate"]["action_id"] == "A-ESC"
    assert "J07" in exp["estimate"]["job_finish_min"] and "POL-02" in exp["estimate"]["violations"]   # 설비를 그대로 뒀을 때의 예측
    cmp_ = ok(sv, "GET", f"/api/experiments/{exp['branch_id']}/compare")
    assert cmp_["branch"]["decision"]["rationale"] and cmp_["base"]["decision"]["selected_id"] == "A-MIG-J07-N2"
    events = ok(sv, "GET", f"/api/receipts/{DID}")["events"]
    assert any(e["type"] == "escalated" and e.get("is_assumption") for e in events)
    # 마감 3분에서는 냉각 강화가 마감을 지키므로 넘기지 않는다
    exp3 = ok(sv, "POST", "/api/experiments", {"decision_id": DID, "base_snapshot_id": "S0", "changes": {"deadline_min": 3}, "policy_version": "1.2"})
    assert exp3["decision"]["selected_id"] == "A-COOL-Z2-UP"


def test_scenario_reset_applies_to_base_state_and_every_step():
    """프론트 v10 '01 상황 설정': POST /api/demo/reset {scenario} 값이 S0·판단·실험·검사·영수증에 그대로 쓰인다."""
    sv = make_service("rule")
    # 옮길 자리가 없는 날 + N4 84°C + 승인 지연 2분
    sc = {"n2_gpus_free": 0, "n4_temp_c": 84, "approval_delay_min": 2}
    assert ok(sv, "POST", "/api/demo/reset", {"scenario": sc}) == {"snapshot_id": "S0", "scenario": sc}
    state = ok(sv, "GET", "/api/state")
    n4 = next(n for n in state["nodes"] if n["id"] == "N4")
    assert n4["temp_c"] == 84 and next(n for n in state["nodes"] if n["id"] == "N2")["gpus_free"] == 0
    hist = next(h for h in state["history"] if h["node_id"] == "N4")["points"]
    assert hist[-1]["temp_c"] == 84 and hist[0]["temp_c"] == 77.0          # 이력도 같은 만큼(+3) 이동
    inc = ok(sv, "GET", "/api/incidents/INC-0412")
    assert next(t for t in inc["no_action_forecast"]["temp_series"] if t["node_id"] == "N4")["points"][0]["temp_c"] == 84
    res = ok(sv, "POST", "/api/decide", {"incident_id": "INC-0412", "snapshot_id": "S0", "policy_version": "1.2"})
    by_id = {c["id"]: c for c in res["candidates"]}
    assert by_id["A-MIG-J07-N2"]["filtered_out"] and by_id["A-MIG-J07-N2"]["filter_reason"] == "POL-03"
    assert res["decision"]["selected_id"] != "A-MIG-J07-N2"
    # 실험은 상황 값 위에 덮어쓴다: 기록되는 변경은 실험 조건만, 계산에는 상황 값도 함께
    exp = ok(sv, "POST", "/api/experiments", {"decision_id": DID, "base_snapshot_id": "S0", "changes": {"deadline_min": 8}, "policy_version": "1.2"})
    assert exp["changes"] == {"deadline_min": 8}
    assert {c["id"]: c for c in exp["candidates"]}["A-MIG-J07-N2"]["filtered_out"]
    rc = ok(sv, "GET", f"/api/receipts/{DID}")
    assert rc["scenario"] == sc
    first = [e for e in rc["events"] if e["summary"].startswith("시연 상황 설정")]
    assert len(first) == 1 and first[0]["is_assumption"] and "N4 84°C" in first[0]["summary"] and "승인 지연 2분" in first[0]["summary"]
    assert ok(sv, "GET", "/api/health")["scenario"] == sc
    # 본문 없이 초기화하면 시드 그대로
    assert ok(sv, "POST", "/api/demo/reset") == {"snapshot_id": "S0", "scenario": {}}
    assert next(n for n in ok(sv, "GET", "/api/state")["nodes"] if n["id"] == "N4")["temp_c"] == 81
    # 잘못된 값은 400 이고 상태는 바뀌지 않는다
    st, err = call(sv, "POST", "/api/demo/reset", {"scenario": {"deadline_min": "x"}})
    assert st == 400 and err["error"]["code"] == "INVALID_REQUEST"


def test_scenario_presets_of_frontend_v10():
    """화면 프리셋 6종의 규칙 기준 결과(모델 없이도 같은 Safety Gate·시뮬레이터로 계산)."""
    sv = make_service("rule")
    expect = {
        "base": ({}, "A-MIG-J07-N2"),
        "tight": ({"deadline_min": 2}, "A-ESC"),
        "full": ({"n2_gpus_free": 0}, "A-COOL-Z2-UP"),
        "peak": ({"objective": "energy"}, "A-MIG-J07-N2"),
        "p0": ({"j07_priority": "P0"}, "A-COOL-Z2-UP"),
        "hot": ({"n4_temp_c": 84, "cooling_max": 3, "n2_gpus_free": 0}, "A-ESC"),
    }
    for name, (sc, want) in expect.items():
        ok(sv, "POST", "/api/demo/reset", {"scenario": sc})
        res = ok(sv, "POST", "/api/decide", {"incident_id": "INC-0412", "snapshot_id": "S0", "policy_version": "1.2"})
        assert res["decision"]["selected_id"] == want, name
        assert res["decision"]["rationale"]
    # P0 로 바꾸면 사건 제목과 차단 사유(POL-01)도 따라 바뀐다
    ok(sv, "POST", "/api/demo/reset", {"scenario": {"j07_priority": "P0"}})
    assert "P0 작업 J07" in ok(sv, "GET", "/api/incidents/INC-0412")["title"]
    # 사람에게 넘긴 상황에서도 검사·영수증 화면이 열린다
    ok(sv, "POST", "/api/demo/reset", {"scenario": {"deadline_min": 2}})
    ok(sv, "POST", "/api/decide", {"incident_id": "INC-0412", "snapshot_id": "S0", "policy_version": "1.2"})
    val = ok(sv, "POST", "/api/validate", {"decision_id": DID, "action_id": "A-ESC", "origin": "model"})
    assert val["verdict"] == "allowed" and not val.get("approval_id")   # 설비 조작이 아니므로 승인 요청을 만들지 않는다
    rc = ok(sv, "GET", f"/api/receipts/{DID}")
    assert any(e["type"] == "escalated" for e in rc["events"]) and rc["branches"][0]["selected_id"] == "A-ESC"

"""다중 작업 버전(/api/v2) 테스트: 시뮬레이터, 필수 규칙, 후보 생성, 판단, 역할별 승인, 회차 반복.

시나리오는 프론트 프리셋(src/sim/model.ts)과 같은 값이다(data/multi_scenarios.json).
"""
from __future__ import annotations

import copy
import json
from pathlib import Path

from app import api, config
from app.multi import load_config
from app.multi.planner import generate
from app.multi.sim import check_steps, simulate
from app.multi.world import ScenarioError, build_state, view
from app.service import NexteraService
from tests.fake_zoro import FakeZoro

CFG = load_config()
PRESETS = {k: v["scenario"] for k, v in json.loads((Path(__file__).resolve().parents[1] / "data" / "multi_scenarios.json").read_text(encoding="utf-8")).items()}
BASE, MULTI, FULL, STUCK = PRESETS["base"], PRESETS["multi"], PRESETS["full"], PRESETS["stuck"]
RAW = ("type", "job", "to", "preempt", "minutes", "zone", "level")


def svc(provider="rule", **overrides):
    return NexteraService(db_path=":memory:", provider_mode=provider, overrides=overrides or None)


def call(sv, method, path, body=None, role="operator", session="m"):
    return api.dispatch(sv, method, path, {}, body, {"X-Role": role, "X-Session": session})


def ok(sv, *a, **kw):
    st, out = call(sv, *a, **kw)
    assert st == 200, (st, out)
    return out


def test_world_zones_fan_and_queue():
    st = build_state(MULTI, CFG)
    assert [z["node_ids"] for z in st["zones"]] == [["N1", "N2"], ["N3", "N4"], ["N5", "N6"]]
    assert [n["fan"] for n in st["nodes"]] == [False, True, False, True, False, False]
    v = {n["id"]: n for n in view(st, CFG)["nodes"]}
    assert v["N2"]["running"] == ["J02", "J03"] and v["N2"]["gpus_free"] == 0          # 4+4장은 동시에 돈다
    assert v["N5"]["running"] == ["J08"] and v["N5"]["waiting"] == ["J06"]             # 8+4장 → 뒤의 일은 대기
    q = build_state({"nodes": [{"temp_c": 50}], "jobs": [{"id": "A", "gpus": 6, "remaining_min": 5, "node": "N1"},
                                                          {"id": "B", "gpus": 4, "remaining_min": 5, "node": "N1"},
                                                          {"id": "C", "gpus": 2, "remaining_min": 5, "node": "N1"}]}, CFG)
    assert view(q, CFG)["nodes"][0]["running"] == ["A", "C"]                           # B(4장)는 못 들어가 대기, 뒤의 작은 일 C(2장)는 빈자리에서 실행
    five = build_state({"nodes": [{"temp_c": 50}] * 5, "jobs": [{"gpus": 2, "remaining_min": 5, "node": "N5"}]}, CFG)
    assert [z["id"] for z in five["zones"]] == ["Z1", "Z2", "Z3"] and five["zones"][2]["node_ids"] == ["N5"]
    for bad in ({"nodes": [], "jobs": []}, {"nodes": [{"temp_c": 50}], "jobs": [{"gpus": 9, "remaining_min": 5, "node": "N1"}]},
                {"nodes": [{"temp_c": 50}], "jobs": [{"gpus": 2, "remaining_min": 5, "node": "N9"}]},
                {"nodes": [{"temp_c": 50}] * 7, "jobs": [{"gpus": 2, "remaining_min": 5, "node": "N1"}]}):
        try:
            build_state(bad, CFG)
            raise AssertionError("검증 실패여야 한다")
        except ScenarioError:
            pass


def test_thermal_model_matches_frontend_formula():
    def settle_temp(gpus, level, fan=False):
        st = build_state({"nodes": [{"temp_c": 70, "fan": fan}], "zones": [{"id": "Z1", "cooling_level": level}],
                          "jobs": [{"gpus": gpus, "remaining_min": 500, "node": "N1"}]}, CFG)
        return simulate(st, [], load_config({"physics": {"ticks": 400}}))["temps"]["N1"][-1]
    # 평형 온도 = 40 + 6.25 × GPU × (팬 이상 1.5) − 6 × 레벨
    assert abs(settle_temp(8, 3) - 72.0) < 0.1 and abs(settle_temp(8, 3, fan=True) - 97.0) < 0.1
    assert abs(settle_temp(8, 5, fan=True) - 85.0) < 0.1 and abs(settle_temp(4, 2) - 53.0) < 0.1
    st = build_state(BASE, CFG)
    a, b = simulate(st, [], CFG), simulate(st, [], CFG)
    assert a["temps"] == b["temps"] and a["jobs"] == b["jobs"]                         # 결정적
    assert a["thermal_nodes"] == ["N4"] and len(a["temps"]["N4"]) == 61                # 30분, 30초 간격
    assert all(v["projected_finish_s"] is not None for v in a["jobs"].values())


def test_presets_give_the_problems_the_screen_describes():
    ids = lambda sc: [p["id"] for p in generate(build_state(sc, CFG), CFG)["problems"]]
    assert ids(BASE) == ["HOT-N4"]
    assert set(ids(MULTI)) == {"HOT-N2", "HOT-N4", "LATE-J06"}
    assert ids(FULL) == ["HOT-N4"]
    assert set(ids(STUCK)) == {"HOT-N4", "LATE-J05"}


def test_hard_rules():
    st = build_state(MULTI, CFG)
    ids = lambda steps: [x["policy_id"] for x in check_steps(st, steps, CFG)]
    assert ids([{"type": "move", "job": "J09", "to": "N1"}]) == ["POL-01"]                         # P0 는 못 옮긴다
    assert ids([{"type": "defer", "job": "J09"}]) == ["POL-01"]
    assert ids([{"type": "defer", "job": "J02"}]) == [] and ids([{"type": "defer", "job": "J03"}]) == []   # P0 만 아니면 연기할 수 있다
    assert ids([{"type": "jump", "job": "J03", "to": "N5", "preempt": ["J08"]}]) == ["POL-09"]     # 덜 급한 일은 못 멈춘다
    assert ids([{"type": "jump", "job": "J06", "to": "N6", "preempt": ["J09"]}]) == ["POL-01"]     # P0 는 못 멈춘다
    assert ids([{"type": "cool", "zone": "Z1", "level": 6}]) == ["COOL-MAX"]
    assert ids([{"type": "move", "job": "J07", "to": "N3"}]) == []                                 # 줄 뒤에 세우는 이동은 허용
    assert ids([{"type": "move", "job": "J07", "to": "N1"}, {"type": "move", "job": "J07", "to": "N3"}]) == ["INVALID"]
    sim = simulate(st, [{"type": "jump", "job": "J06", "to": "N5", "preempt": ["J08"]}], CFG)      # 급한 일은 실행 중인 일을 멈추고 끼어든다
    assert not sim["skipped"] and sim["jobs"]["J06"]["first_run_s"] == 0.0 and "J06" not in sim["late_jobs"]
    assert sim["jobs"]["J08"]["projected_finish_s"] > simulate(st, [], CFG)["jobs"]["J08"]["projected_finish_s"]


def test_evacuate_returns_and_defer_resumes():
    st = build_state({"nodes": [{"temp_c": 86, "fan": True}, {"temp_c": 50}],
                      "jobs": [{"id": "A", "gpus": 8, "priority": "P2", "remaining_min": 40, "node": "N1", "deadline_min": 90}]}, CFG)
    sim = simulate(st, [{"type": "evacuate", "job": "A", "to": "N2"}], CFG)
    assert sim["jobs"]["A"]["node"] == "N1" and min(sim["temps"]["N1"]) < 78            # 식으면 원래 노드로 복귀
    assert simulate(st, [{"type": "move", "job": "A", "to": "N2"}], CFG)["jobs"]["A"]["node"] == "N2"
    sim = simulate(st, [{"type": "defer", "job": "A", "minutes": 5}], CFG)
    assert sim["jobs"]["A"]["projected_finish_s"] > 40 * 60 + 5 * 60


def test_candidates_are_verified_plans():
    st = build_state(MULTI, CFG)
    g = generate(st, CFG)
    assert 2 <= len(g["candidates"]) <= CFG["planner"]["max_candidates"]
    seen = set()
    for c in g["candidates"]:
        raw = [{k: s[k] for k in RAW if k in s} for s in c["steps"]]
        assert check_steps(st, raw, CFG) == []
        sim = simulate(st, raw, CFG)
        assert sim["thermal_nodes"] == [] and not sim["skipped"]                         # 풀 수 있는 과열은 모든 후보가 푼다
        assert c["max_peak_c"] == sim["max_peak_c"] and c["required_roles"] and c["temps"] == sim["temps"]
        assert all(v is not None for v in c["job_finish_min"].values())
        key = str(sorted(str(s) for s in raw))
        assert key not in seen
        seen.add(key)
    assert any(len(c["steps"]) >= 2 for c in g["candidates"])                            # 여러 행동을 묶은 계획
    assert any(len(c["required_roles"]) == 2 for c in g["candidates"])                   # 두 역할 승인이 필요한 계획
    assert generate(st, CFG)["candidates"] == g["candidates"]                            # 같은 입력 → 같은 후보
    s = g["stats"]
    assert s["strategies"] >= s["built"] >= s["merged"] >= s["safe"] >= s["pareto"] >= s["sent"] >= 1 and s["gen_ms"] < 5000


def test_unsolvable_problem_is_handed_off():
    g = generate(build_state(STUCK, CFG), CFG)                # J05 는 어떻게 해도 마감 안에 못 끝난다
    assert [p["id"] for p in g["escalate"]] == ["LATE-J05"] and g["candidates"]
    assert all("HOT-N4" in c["resolved"] and "LATE-J05" in c["remaining"] for c in g["candidates"])
    sv = svc()
    ok(sv, "POST", "/api/v2/scenario", STUCK)
    res = ok(sv, "POST", "/api/v2/decide")
    assert res["decision"]["escalate"] == ["LATE-J05"]
    plan = next(c for c in res["candidates"] if c["id"] == res["decision"]["selected_id"])
    for role in plan["required_roles"]:
        ok(sv, "POST", "/api/v2/approvals", {"plan_id": plan["id"]}, role=role)
    ex = ok(sv, "POST", "/api/v2/execute", {"plan_id": plan["id"]})
    assert ex["resolved"] == ["HOT-N4"] and [p["id"] for p in ex["remaining"]] == ["LATE-J05"] and ex["next"]["status"] == "next_round"
    ov = ok(sv, "GET", "/api/v2/state")
    assert ov["round"] == 2 and [p["id"] for p in ov["problems"]] == ["LATE-J05"]        # 계획을 적용한 상태에서 남은 문제를 다시 본다
    d = ok(sv, "POST", "/api/v2/decide")["decision"]
    assert d["status"] == "handoff" and d["fallback_reason"] == "NO_FEASIBLE_PLAN" and d["selected_id"] is None
    assert ok(sv, "GET", "/api/v2/state")["status"] == "handoff"
    sv2 = svc()
    ok(sv2, "POST", "/api/v2/scenario", {"nodes": [{"temp_c": 50}], "jobs": [{"gpus": 2, "remaining_min": 5, "node": "N1", "deadline_min": 30}]})
    assert ok(sv2, "POST", "/api/v2/decide")["decision"]["status"] == "no_problem"


def test_full_flow_two_role_approval():
    sv = svc()
    ov = ok(sv, "POST", "/api/v2/scenario", {"scenario": MULTI})
    assert ov["round"] == 1 and len(ov["problems"]) == 3 and len(ov["no_action"]["temps"]["N4"]) == 61
    res = ok(sv, "POST", "/api/v2/decide")
    d = res["decision"]
    assert d["provider"] == "rule" and d["selected_id"] == "P01" and d["stats"]["sent"] == len(d["model_candidates"]) <= 5
    plan = next(c for c in res["candidates"] if len(c["required_roles"]) == 2)
    pid = plan["id"]
    v = ok(sv, "POST", "/api/v2/validate", {"plan_id": pid})
    assert v["verdict"] == "conditional" and v["required_roles"] == ["cooling_A", "gpu_B"]
    forced = ok(sv, "POST", "/api/v2/validate", {"steps": [{"type": "move", "job": "J09", "to": "N1"}]})      # 화면의 강제 입력 테스트
    bad = next(c for c in forced["checks"] if c["result"] == "fail")
    assert forced["verdict"] == "blocked" and bad["policy_id"] == "POL-01" and "P0" in bad["message"]
    forced = ok(sv, "POST", "/api/v2/validate", {"steps": [{"type": "cool", "zone": "Z1", "level": 6}]})
    assert forced["verdict"] == "blocked" and forced["checks"][0]["policy_id"] == "COOL-MAX"
    st, err = call(sv, "POST", "/api/v2/execute", {"plan_id": pid})
    assert st == 409 and err["error"]["code"] == "APPROVAL_REQUIRED"
    st, err = call(sv, "POST", "/api/v2/approvals", {"plan_id": pid, "action": "approve"}, role="operator")
    assert st == 403 and err["error"]["code"] == "ROLE_FORBIDDEN" and err["error"]["message"]
    assert ok(sv, "POST", "/api/v2/approvals", {"plan_id": pid, "action": "approve"}, role="gpu_B")["status"] == "pending"
    st, err = call(sv, "POST", "/api/v2/execute", {"plan_id": pid})
    assert st == 409 and "cooling_A" in err["error"]["message"]                          # 한 역할만으로는 실행할 수 없다
    assert ok(sv, "POST", "/api/v2/approvals", {"plan_id": pid, "action": "approve"}, role="cooling_A")["status"] == "approved"
    ex = ok(sv, "POST", "/api/v2/execute", {"plan_id": pid})
    assert ex["status"] == "succeeded" and set(ex["resolved"]) >= {"HOT-N2", "HOT-N4"} and ex["after"]["nodes"] and ex["next"]["status"]
    assert ok(sv, "POST", "/api/v2/execute", {"plan_id": pid}) == ex                     # 같은 회차는 한 번만 실행
    rc = ok(sv, "GET", "/api/v2/receipt")
    types = [e["type"] for e in rc["events"]]
    for t in ("scenario_set", "candidates_generated", "decision_made", "validated", "blocked", "approved", "rechecked", "executed"):
        assert t in types, t
    assert ok(sv, "GET", "/api/v2/log")["rounds"][0]["zoro1_request"]["questions"]["action"]["type"] == "choice"


def test_rounds_continue_until_nothing_is_left():
    sv = svc(multi={"planner": {"max_steps": 1}})          # 한 번에 조작 1개만 허용 → 한 회차로는 다 못 푼다
    ok(sv, "POST", "/api/v2/scenario", MULTI)
    rounds = 0
    while True:
        res = ok(sv, "POST", "/api/v2/decide")
        d = res["decision"]
        if d["status"] != "decided":
            break
        plan = next(c for c in res["candidates"] if c["id"] == d["selected_id"])
        assert len(plan["steps"]) == 1
        for role in plan["required_roles"]:
            ok(sv, "POST", "/api/v2/approvals", {"plan_id": plan["id"]}, role=role)
        last = ok(sv, "POST", "/api/v2/execute", {"plan_id": plan["id"]})
        rounds += 1
        if last["next"]["status"] != "next_round":
            break
    assert rounds >= 2                                                   # 남은 문제를 확인하고 다시 고른다
    ov = ok(sv, "GET", "/api/v2/state")
    assert ov["status"] in ("resolved", "stalled", "max_rounds", "handoff") and len(ov["history"]) == rounds
    assert ov["history"][0]["resolved"] and ov["history"][0]["remaining"]
    rc = ok(sv, "GET", "/api/v2/receipt")
    assert [r["round"] for r in rc["rounds"]][:2] == [1, 2] and any(e["type"] == "round_started" for e in rc["events"])


def test_zoro_chooses_among_top_plans_and_falls_back():
    with FakeZoro(pick="P02") as fake:
        cfg = config.load_decision_cfg()
        cfg["zoro1"]["url"] = fake.url
        sv = svc("zoro1")
        sv.multi.decision_cfg = cfg
        ok(sv, "POST", "/api/v2/scenario", MULTI)
        res = ok(sv, "POST", "/api/v2/decide", {"include_request": True})
        d = res["decision"]
        assert d["provider"] == "zoro1" and d["is_real_model"] and d["selected_id"] == "P02"
        offered = [c["id"] for c in res["candidates"] if c["offered_to_model"]]
        assert offered == d["model_candidates"] == [c["id"] for c in res["candidates"]][:5] and len(res["candidates"]) > 5
        assert set(d["probs"]) == set(offered) and d["ranking"][0]["id"] == "P02"
        orders = [list(r["request"]["questions"]["action"]["criteria"]) for r in fake.requests]
        assert len(orders) == 4 and orders[1] == orders[0][::-1] and len({tuple(o) for o in orders}) == 4      # 순서만 바꿔 4번 묻는다
        assert d["decision_mode"] == "direct_order_averaged" and d["agreement"] == "4/4" and len(d["votes"]) == 4
        sent = fake.requests[-1]["request"]
        assert set(sent["questions"]["action"]["criteria"]) == set(offered)
        assert "Steps: (1)" in sent["questions"]["action"]["criteria"]["P01"] and len(sent["state"]["jobs"]) == 8
        assert any(n.get("fan_issue") for n in sent["state"]["nodes"])
    sv = svc("zoro1")
    cfg = config.load_decision_cfg()
    cfg["zoro1"]["url"] = "http://127.0.0.1:9"
    sv.multi.decision_cfg = cfg
    ok(sv, "POST", "/api/v2/scenario", MULTI)
    d = ok(sv, "POST", "/api/v2/decide")["decision"]
    assert d["provider"] == "rule" and d["is_fallback"] and d["fallback_reason"] == "ZORO1_UNREACHABLE" and d["selected_id"] == "P01"


def test_analytics_and_receipt_list_include_multi_runs():
    """분석 화면(기존 /api/analytics · /api/receipts)이 다중 작업 기록을 보여 준다."""
    sv = svc()
    assert ok(sv, "GET", "/api/analytics")["total_decisions"] == 0 and ok(sv, "GET", "/api/receipts") == []
    ok(sv, "POST", "/api/v2/scenario", STUCK)
    res = ok(sv, "POST", "/api/v2/decide")
    plan = next(c for c in res["candidates"] if c["id"] == res["decision"]["selected_id"])
    ok(sv, "POST", "/api/v2/validate", {"steps": [{"type": "cool", "zone": "Z1", "level": 9}]})
    call(sv, "POST", "/api/v2/approvals", {"plan_id": plan["id"], "action": "approve"}, role="operator")
    for role in plan["required_roles"]:
        ok(sv, "POST", "/api/v2/approvals", {"plan_id": plan["id"], "action": "approve"}, role=role)
    ok(sv, "POST", "/api/v2/execute", {"plan_id": plan["id"]})
    ok(sv, "POST", "/api/v2/decide")                                   # 2회차: 사람에게 넘김
    a = ok(sv, "GET", "/api/analytics")
    assert a["is_example"] is False and a["total_decisions"] == 2 and a["blocked_attempts"] == 2
    assert a["results"] == {"succeeded": 1, "held": 0, "failed": 1}    # 넘긴 결정은 실패로 센다 (보류 항목은 쓰지 않는다)
    assert a["escalation_rate_pct"] == 50.0                            # 이관 = 통째로 사람에게 넘긴 결정만 (2건 중 1건)
    assert a["deadline_met"] == {"met": 0, "total": 1}                 # 사건 단위: 마감 위험 사건은 J05 하나이고 지키지 못했다
    assert {t["type"]: t["missed"] for t in a["by_type"]} == {"과열 위험": 0, "마감 위험": 1}
    assert {t["type"]: t["decisions"] for t in a["by_type"]} == {"과열 위험": 1, "마감 위험": 1}   # 막대는 사건 수: 두 회차에 걸친 J05는 한 번만
    assert {t["type"] for t in a["by_type"]} == {"과열 위험", "마감 위험"}
    assert {p["pattern"] for p in a["patterns"]} >= {"규칙을 어기는 강제 입력", "권한 없는 승인 시도", "안전한 계획이 없어 사람에게 넘김"}
    rows = ok(sv, "GET", "/api/receipts")
    assert [r["decision_id"] for r in rows] == ["MR-02", "MR-01"] and rows[0]["status"] == "held" and rows[1]["status"] == "executed"
    assert rows[0]["execution"]["sla"]["met"] is False and rows[1]["execution"]["sla"]["met"] is True
    assert rows[1]["candidates"][0]["id"] == rows[1]["branches"][0]["selected_id"] and "→" in rows[1]["candidates"][0]["label"] or rows[1]["candidates"][0]["label"]
    assert ok(sv, "GET", "/api/receipts", session="other") == []       # 다른 접속자의 목록에는 섞이지 않는다
    other = ok(sv, "GET", "/api/analytics", session="other")           # 웹을 닫았다 다시 열면 새 접속자다: 이전 기록이 합산되지 않는다
    assert other["total_decisions"] == 0 and other["results"] == {"succeeded": 0, "held": 0, "failed": 0} and other["blocked_attempts"] == 0
    assert ok(sv, "GET", "/api/analytics")["total_decisions"] == 2     # 원래 접속자의 화면은 그대로


def test_node_already_over_limit_can_be_resolved_and_useless_plans_are_dropped():
    """시작부터 한계 이상인 노드: 빨리 식히면 풀린 것으로 본다. 아무 문제도 못 푸는 계획은 후보가 아니다."""
    sc = {"nodes": [{"temp_c": 60}, {"temp_c": 50}, {"temp_c": 70}, {"temp_c": 95, "fan": True}, {"temp_c": 95, "fan": True}],
          "zones": [{"id": "Z1"}, {"id": "Z2"}, {"id": "Z3"}],
          "jobs": [{"id": "A", "gpus": 8, "priority": "P1", "deadline_min": 30, "remaining_min": 10, "node": "N4"},
                   {"id": "B", "gpus": 2, "priority": "P0", "deadline_min": 60, "remaining_min": 20, "node": "N5"}]}
    st = build_state(sc, CFG)
    base = simulate(st, [], CFG)
    assert base["start_over"] == ["N4", "N5"]
    assert base["thermal_nodes"] == ["N4"]                       # N5 는 부하가 작아 스스로 2분 안에 내려온다 → 문제 아님
    assert base["recovered_s"]["N5"] is not None and base["recovered_s"]["N4"] is None
    g = generate(st, CFG)
    assert [p["id"] for p in g["problems"]] == ["HOT-N4"] and "이미 한계" in g["problems"][0]["text"]
    assert g["candidates"] and all(c["resolved"] == ["HOT-N4"] for c in g["candidates"])     # 옮기거나 식혀서 풀 수 있다
    # 풀 수 없는 경우: P0 8장 작업이 냉각 상한에 걸린 팬 이상 노드에 있다 → 풀지 못하는 계획을 후보로 내지 않고 사람에게 넘긴다
    stuck = {"nodes": [{"temp_c": 95, "fan": True}], "zones": [{"id": "Z1", "cooling_level": 3, "cooling_max": 3}],
             "jobs": [{"gpus": 8, "priority": "P0", "deadline_min": 90, "remaining_min": 20, "node": "N1"}]}
    g2 = generate(build_state(stuck, CFG), CFG)
    assert [p["id"] for p in g2["problems"]] == ["HOT-N1"] and g2["candidates"] == []


def test_analytics_bars_count_incidents_not_decisions():
    """한 계획이 사건 3건을 풀면 막대는 3건(과열 2 + 마감 1)이다. 평가된 결정은 1건 그대로."""
    sv = svc()
    ok(sv, "POST", "/api/v2/scenario", MULTI)
    res = ok(sv, "POST", "/api/v2/decide")
    plan = next(c for c in res["candidates"] if c["id"] == res["decision"]["selected_id"])
    for role in plan["required_roles"]:
        ok(sv, "POST", "/api/v2/approvals", {"plan_id": plan["id"], "action": "approve"}, role=role)
    ok(sv, "POST", "/api/v2/execute", {"plan_id": plan["id"]})
    q = lambda **f: api.dispatch(sv, "GET", "/api/analytics", f, None, {"X-Session": "m"})[1]
    assert q()["total_decisions"] == 3 and q()["results"] == {"succeeded": 3, "held": 0, "failed": 0}   # 결정 1번, 사건 3건
    assert q()["deadline_met"] == {"met": 1, "total": 1} and q()["escalation_rate_pct"] == 0.0
    assert q()["by_type"] == [{"type": "과열 위험", "decisions": 2, "missed": 0}, {"type": "마감 위험", "decisions": 1, "missed": 0}]
    assert q(scenario="과열 위험")["by_type"] == [{"type": "과열 위험", "decisions": 2, "missed": 0}]   # 사건 종류 필터 = 그 종류의 막대만
    assert q(scenario="마감 위험")["by_type"] == [{"type": "마감 위험", "decisions": 1, "missed": 0}]


def test_analytics_filters_apply_to_multi_runs():
    sv = svc()
    ok(sv, "POST", "/api/v2/scenario", STUCK)
    res = ok(sv, "POST", "/api/v2/decide")
    plan = next(c for c in res["candidates"] if c["id"] == res["decision"]["selected_id"])
    for role in plan["required_roles"]:
        ok(sv, "POST", "/api/v2/approvals", {"plan_id": plan["id"], "action": "approve"}, role=role)
    ok(sv, "POST", "/api/v2/execute", {"plan_id": plan["id"]})
    ok(sv, "POST", "/api/v2/decide")                                   # 2회차: 마감 문제만 남아 사람에게 넘김
    q = lambda **f: api.dispatch(sv, "GET", "/api/analytics", f, None, {"X-Session": "m"})[1]
    assert q()["total_decisions"] == 2
    assert q(result="성공")["total_decisions"] == 1 and q(result="성공")["results"] == {"succeeded": 1, "held": 0, "failed": 0}
    assert q(result="실패")["total_decisions"] == 1 and q(result="실패")["results"] == {"succeeded": 0, "held": 0, "failed": 1}
    assert q(result="보류")["total_decisions"] == 0                     # 보류 항목은 없앴다
    assert q(result="성공")["deadline_met"] == {"met": 0, "total": 0} and q(result="실패")["deadline_met"] == {"met": 0, "total": 1}
    assert q(scenario="과열 위험")["total_decisions"] == 1 and q(scenario="마감 위험")["total_decisions"] == 1
    assert q(scenario="마감 위험", result="성공")["total_decisions"] == 0   # 마감 위험 사건(J05)은 풀지 못했다
    assert q(period="오늘")["total_decisions"] == 2 and q(period="최근 30일")["total_decisions"] == 2

"""테스트 전용 가짜 Zoro-1 서버. 실제 모델이 아니다 — 어댑터의 요청 형식·응답 검증·폴백 경로를 확인하는 용도다.

POST /v1/decide 를 받아 behavior 에 따라 응답한다. 받은 요청 본문은 server.requests 에 쌓인다.
"""
from __future__ import annotations

import json
import threading
import time
from http.server import BaseHTTPRequestHandler, HTTPServer


class FakeZoro:
    def __init__(self, behavior: str = "ok", pick: str | None = None, top_prob: float = 0.8, delay_s: float = 0.0):
        self.behavior = behavior
        self.pick = pick
        self.top_prob = top_prob
        self.delay_s = delay_s
        self.requests: list[dict] = []
        outer = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args):  # 조용히
                pass

            def do_POST(self):
                body = json.loads(self.rfile.read(int(self.headers.get("Content-Length", "0"))) or b"{}")
                outer.requests.append(body)
                if outer.delay_s:
                    time.sleep(outer.delay_s)
                if self.path != "/v1/decide":
                    self.send_response(404)
                    self.end_headers()
                    return
                if outer.behavior == "http_500":
                    self.send_response(500)
                    self.end_headers()
                    self.wfile.write(b"boom")
                    return
                payload = b"not json" if outer.behavior == "bad_json" else json.dumps(outer.answer(body)).encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(payload)

        self.httpd = HTTPServer(("127.0.0.1", 0), Handler)
        self.port = self.httpd.server_address[1]
        self.url = f"http://127.0.0.1:{self.port}/v1/decide"
        self._thread = threading.Thread(target=self.httpd.serve_forever, daemon=True)

    def answer(self, body: dict) -> dict:
        questions = body["request"]["questions"]
        reasoning = bool(body.get("reasoning"))
        answers: dict = {}
        for qid, q in questions.items():
            if q["type"] == "choice":
                ids = list(q["criteria"])
                pick = self.pick if self.pick in ids else ids[0]
                top = self.top_prob
                if self.behavior == "low_conf":
                    top = 0.9 if reasoning else 0.4
                rest = (1.0 - top) / max(1, len(ids) - 1)
                probs = {i: (top if i == pick else rest) for i in ids}
                if self.behavior == "bad_sum":
                    probs = {i: 0.9 for i in ids}
                if self.behavior == "unknown_id":
                    probs["A-NOT-A-CANDIDATE"] = 0.0
                if self.behavior == "missing_id":
                    probs.pop(ids[-1])
                answers[qid] = {"type": "choice", "choice": pick, "confidence": top, "probabilities": probs}
            elif q["type"] == "noul":
                answers[qid] = {"type": "noul", "noul": 0.93}
            elif q["type"] == "score":
                levels = q["criteria"]
                n = len(levels)
                probs = {str(i): 0.0 for i in range(n)}
                probs[str(n - 1)] = 0.5116
                probs[str(n - 2)] = 0.4884
                answers[qid] = {"type": "score", "score": (n - 1) * 0.5116 + (n - 2) * 0.4884, "legend": levels,
                                "confidence": 0.2333, "probabilities": probs}
        if self.behavior == "missing_answer":
            answers.pop("action")
        out = {"answers": answers, "timing_ms": 496.1, "model": "fake-zoro-for-tests"}
        if reasoning:
            out["reasoning"] = "We need to analyze the incident. test reasoning text"
            out["reasoning_ms"] = 25837.1
        return out

    def __enter__(self):
        self._thread.start()
        return self

    def __exit__(self, *exc):
        self.httpd.shutdown()
        self.httpd.server_close()

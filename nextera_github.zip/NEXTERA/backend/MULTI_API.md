# 다중 작업 버전 API (`/api/v2`)

노드 1~6개, 일 1~10개, 여러 행동을 묶은 계획 후보, 회차 반복. 기존 `/api/*`(단일 사건 흐름)는 그대로 동작하고 서로 영향을 주지 않는다.
화면 구조가 정해지면 `backend/app/multi/service.py`(얇은 층)만 맞추면 된다. 계산 부분은 `sim.py`·`planner.py`·`decide.py`에 있다.

헤더는 기존과 같다: `X-Session`(접속자 구분), `X-Role`(`operator` · `cooling_A` · `gpu_B`). 오류 본문도 `{"error":{"code","message"}}` 형식이다.

## 흐름

```
POST /api/v2/scenario   상황 설정 → 회차 1 상태와 문제 목록
POST /api/v2/decide     후보(계획) 생성 + Zoro-1 선택
POST /api/v2/validate   안전 검사 (후보 또는 운영자가 직접 넣은 단계)
POST /api/v2/approvals  역할별 승인 (필요한 역할이 모두 승인해야 실행 가능)
POST /api/v2/execute    가상 실행 → 8분 뒤 상태 → 남은 문제 → 다음 회차
GET  /api/v2/state      현재 회차 상태·문제·회차 기록
GET  /api/v2/receipt    회차별 문제·후보·판단·승인·실행과 이벤트
GET  /api/v2/log        영수증 + 회차별 Zoro-1 요청 원문 (제출 로그용)
```

## 1. 상황 설정 — `POST /api/v2/scenario`

```json
{
  "nodes": [{"temp_c": 63}, {"temp_c": 46}, {"temp_c": 66}, {"temp_c": 84}, {"temp_c": 71}, {"temp_c": 69}],
  "zones": [{"id": "Z1", "cooling_level": 3, "cooling_max": 5}, {"id": "Z2", "cooling_level": 3, "cooling_max": 4}],
  "jobs": [
    {"id": "J1", "gpus": 8, "priority": "P1", "deadline_min": 12, "remaining_min": 9, "node": "N4"},
    {"id": "J3", "gpus": 4, "priority": "P1", "deadline_min": 15, "remaining_min": 6, "node": "N4"}
  ],
  "objective": "balanced"
}
```

- `nodes`: 1~6개. `id`를 생략하면 순서대로 `N1`… 이 된다. `temp_c`(현재 온도)와 `fan`(팬 이상 여부, 생략하면 false)을 받는다.
- 구역은 노드 2개당 하나로 자동 배정된다(N1·N2=Z1, N3·N4=Z2, N5·N6=Z3). `zones`는 냉각 레벨·상한만 바꾼다. 생략하면 레벨 3, 상한 5.
- `jobs`: 1~10개. `gpus` 1~8, `priority` P0~P2, `deadline_min`(없으면 null), `remaining_min`(남은 작업 시간), `node`. 같은 노드에서는 배열 순서가 줄 순서다(`order` 숫자를 주면 그 순서).
- 한 노드의 일은 줄 순서대로 GPU 합이 8장 이하인 만큼 동시에 돈다. 못 들어가는 일은 대기하고, 그 뒤의 작은 일이 빈자리에 들어갈 수 있으면 먼저 실행한다. 노드당 일은 최대 4개(`multi_config.json`의 `max_jobs_per_node`).
- `{"scenario": {...}}`로 감싸 보내도 된다. 값이 잘못되면 400.

응답(= `GET /api/v2/state`): `round`, `max_rounds`, `status`, `state`, `problems`, `no_action`, `history`, `limits`.

- `state.nodes[]`: `id, zone, temp_c, gpus_total, gpus_used, gpus_free, running[], waiting[]`
- `state.zones[]`: `id, node_ids, cooling_level, cooling_max`
- `state.jobs[]`: `id, gpus, priority, deadline_min, remaining_min, node, status(running|waiting|deferred)`
- `problems[]`(중요도 순): `id`(`HOT-N4`, `LATE-J3`), `kind`(overheat|deadline), `node`, `job`, `priority`, `severity`(high|medium|low), `time_min`, `text`
- `no_action`: 조치 없이 둘 때의 예측(`peak_c`, `reach_limit_min`, `temps`(노드별 30초 간격), `job_finish_min`, `late_jobs`)
- `status`: `open` → 진행 중, `resolved` · `handoff` · `stalled` · `max_rounds` → 종료

## 2. 판단 — `POST /api/v2/decide`

응답: `decision`, `candidates`, `problems`, `escalate`. 본문에 `{"include_request": true}`를 주면 Zoro-1 요청 원문도 온다.

- `candidates[]`(규칙 순위 순, 최대 24개): `id`(`P01`…), `label`, `strategies[]`, `steps[]`, `required_roles[]`,
  `max_peak_c`, `max_peak_node`, `peak_c`, `cooling_kwh`, `cooling_kwh_delta`, `late_jobs[]`, `job_finish_min`, `resolved[]`, `remaining[]`, `new_problems[]`,
  `temps`(노드별 30초 간격 온도, 30분), `offered_to_model`
- `steps[]`: `index, type, label, requires_approval_role` + 종류별 값

| type | 값 | 뜻 | 승인 |
|---|---|---|---|
| `move` | `job, to` | 다른 노드로 이동(빈자리 또는 줄 뒤) | gpu_B |
| `jump` | `job, to, preempt[]` | 줄 맨 앞에 세움. `preempt`의 실행 중인 일을 멈춘다 | gpu_B |
| `evacuate` | `job, to` | 옮겼다가 원래 노드가 78°C 이하로 식으면 복귀 | gpu_B |
| `defer` | `job, minutes` | 뒤로 미룸. P0만 아니면 가능 | gpu_B |
| `cool` | `zone, level` | 구역 냉각 레벨 변경 | cooling_A |

- `decision`: `status`(decided|handoff|no_problem), `provider`(zoro1|rule|mock), `selected_id`, `probs`(후보별 확률), `ranking`(상위 5개),
  `needs_review`, `rationale`, `latency_ms`, `fallback_reason`, `escalate[]`, `stats`(`gen_ms`, `sims`)
- `decision.stats`: 화면의 후보 깔때기 수치 `strategies → built → merged → safe → pareto → sent`와 `gen_ms`, `sims`.
- `rejected[]`: 검증에서 탈락한 계획 `{strategy, reason, policy, steps}`.
- `escalate`: 어떤 계획으로도 풀 수 없는 문제(과열·마감 모두). 계획 실행과 별개로 사람에게 넘긴다.
- 안전한 계획이 하나도 없으면 `status: "handoff"`, 문제가 없으면 `status: "no_problem"`.
- Zoro-1 호출이 실패하면 규칙 순위 1위로 이어 간다(`provider: "rule"`, `fallback_reason`).
- 화면에는 검증된 후보 전부(최대 24개)가 오지만 Zoro-1에는 규칙 순위 상위 5개만 선택지로 준다(`planner.max_model_candidates`). 후보마다 `offered_to_model`로 구분하고, `decision.model_candidates`에 목록이 있다.
- Zoro-1에는 같은 후보를 순서만 바꿔 4번 묻고(원래 순서, 뒤집은 순서, 고정 씨앗으로 섞은 순서 2개) 가장 많은 순서에서 1위였던 계획을 고른다(동률이면 평균 확률). `multi_config.json`의 `decision.order_votes`.
  Brev 실측에서 순서를 뒤집으면 1위가 바뀌었기 때문이다. `decision.votes`에 순서별 선택이, `decision.agreement`에 최종 선택과 일치한 횟수가 들어 있다.

## 3. 안전 검사 — `POST /api/v2/validate`

`{"plan_id": "P01"}` 또는 운영자 강제 입력 `{"steps": [{"type": "move", "job": "J4", "to": "N2"}]}`.
응답: `verdict`(conditional|blocked), `checks[]`(`policy_id`, `result`(pass|warn|fail|needs_approval), `message`), `required_roles[]`. 차단은 영수증에 남는다.

| 규칙 | 내용 |
|---|---|
| POL-01 | P0 일은 옮기거나 미루거나 멈출 수 없다 |
| POL-02 | 계획이 과열(88°C 이상)을 만들거나 키우면 차단. 원래 있던 과열을 못 푼 것은 경고(남은 문제). 시작부터 88°C 이상인 노드는 2분 안에 한계 아래로 내려오고 그 뒤 다시 넘지 않으면 풀린 것으로 본다(`physics.recover_grace_min`) |
| POL-03 | 노드에 일을 더 놓을 수 없으면 차단 |
| POL-09 | 더 급한 일(우선순위가 높거나, 같으면 마감이 빠른 일)만 다른 일을 멈출 수 있다. 멈춘 일이 그 때문에 마감을 놓쳐도 차단 |
| COOL-MAX | 구역 냉각 상한 초과 |

## 4. 승인 — `POST /api/v2/approvals`

`{"plan_id": "P01", "action": "approve"}` + `X-Role`. 계획에 필요한 역할이 아니면 403 `ROLE_FORBIDDEN`(기록됨).
응답: `required_roles`, `approved`(역할 → 승인한 단계 번호), `status`(pending|approved|rejected).

## 5. 실행 — `POST /api/v2/execute`

`{"plan_id": "P01"}`. 승인이 모자라면 409 `APPROVAL_REQUIRED`. 실행 직전에 상태와 규칙을 다시 검사하고, 막히면 409 `RECHECK_FAILED`.
응답: `status`(succeeded), `recheck[]`, `steps[]`, `before`, `after`(계획을 적용한 직후의 상태), `resolved[]`, `remaining[]`(문제 객체), `escalated[]`, `next`.
다음 회차는 `after` 상태에서 남은 문제를 다시 계산한다(시간은 흐르지 않는다. `physics.after_snapshot_s`로 바꿀 수 있다).

`next.status`:

| 값 | 뜻 |
|---|---|
| `next_round` | 남은 문제가 있어 다음 회차로. `/decide`를 다시 부른다 |
| `resolved` | 남은 문제 없음 |
| `stalled` | 직전 회차와 남은 문제가 같음 → 사람에게 넘김 |
| `max_rounds` | 최대 회차(기본 4) 도달 → 남은 문제는 사람에게 넘김 |

## 설정과 확인

- 값은 `backend/data/multi_config.json`: 물리 상수, 한계, 후보 수(`max_candidates` 24), 계획당 최대 단계(`max_steps` 10), 최대 회차.
- 온도: 프론트 엔진(`src/sim/engine.ts`)과 같은 식이다. 평형 온도 = 40 + 6.25 × 실행 GPU 수 × (팬 이상이면 1.5) − 6 × 냉각 레벨, 시간상수 4분, 85°C부터 작업 속도 0.7배.
  예측 구간은 30분(30초 간격 61점), 냉각 에너지 = 구역 레벨 합 × 1.2 kW × 0.5시간. 계획의 단계는 0분에 적용한다.
- 화면 없이 끝까지 돌려 보기: `python multi_demo.py --provider zoro1_local` (프론트 프리셋과 같은 내장 시나리오 4종, 결과는 `runs/multi_<시각>/`).
- 테스트: `NEXTERA_PRELOAD=0 python -m pytest -q` (기존 34개 + 다중 작업 10개).

#!/usr/bin/env bash
# NEXTERA 백엔드 실행 (frontend/dist 가 있으면 화면까지 같은 포트로 서빙)
set -euo pipefail
cd "$(dirname "$0")"
exec python -m uvicorn app.main:app --host 0.0.0.0 --port "${PORT:-8000}"

"""설정·시드 로더와 override.

- 시드(스냅샷·정책·역할)는 프론트와 공유하는 data/seed 를 그대로 읽는다.
- 물리 상수·판단 설정·사건 정의는 backend/data 의 JSON 에 있다. 코드에 숫자를 박지 않는다.
- override 는 {"physics": {...}, "decision": {...}} 형태이고 점(.) 경로와 {"$add": x} 를 지원한다.
  존재하지 않는 키는 오타 방지를 위해 OverrideError 를 낸다.
"""
from __future__ import annotations

import copy
import hashlib
import json
import os
from pathlib import Path
from typing import Any

BACKEND_DIR = Path(__file__).resolve().parent.parent
REPO_DIR = BACKEND_DIR.parent
DATA_DIR = Path(os.environ.get("NEXTERA_DATA_DIR") or BACKEND_DIR / "data")
SEED_DIR = Path(os.environ.get("NEXTERA_SEED_DIR") or REPO_DIR / "data" / "seed")


class ConfigError(ValueError):
    pass


class OverrideError(ConfigError):
    pass


def _read(path: Path) -> Any:
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError as e:
        raise ConfigError(f"설정 파일 없음: {path}") from e
    except json.JSONDecodeError as e:
        raise ConfigError(f"JSON 형식 오류: {path}: {e}") from e


def canonical_hash(obj: Any) -> str:
    raw = json.dumps(obj, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:12]


# ----------------------------------------------------------------- override

def _child(container: Any, key: str, path: str) -> Any:
    if isinstance(container, list):
        for item in container:
            if isinstance(item, dict) and item.get("id") == key:
                return item
        if key.isdigit() and int(key) < len(container):
            return container[int(key)]
        raise OverrideError(f"override 경로 '{path}': 리스트에 id '{key}' 없음")
    if isinstance(container, dict):
        if key not in container:
            raise OverrideError(f"override 경로 '{path}': 키 '{key}' 없음")
        return container[key]
    raise OverrideError(f"override 경로 '{path}': '{key}' 위쪽이 객체가 아님")


def _resolve(old: Any, value: Any, path: str) -> Any:
    if isinstance(value, dict) and set(value.keys()) == {"$add"}:
        if not isinstance(old, (int, float)) or isinstance(old, bool):
            raise OverrideError(f"override 경로 '{path}': $add 는 숫자에만 쓸 수 있음")
        return old + value["$add"]
    return value


def set_path(obj: Any, dotted: str, value: Any) -> None:
    parts = dotted.split(".")
    cur = obj
    for p in parts[:-1]:
        cur = _child(cur, p, dotted)
    last = parts[-1]
    old = _child(cur, last, dotted)
    new = _resolve(old, value, dotted)
    if isinstance(cur, list):
        idx = next(i for i, item in enumerate(cur) if item is old)
        cur[idx] = new
    else:
        cur[last] = new


def apply_overrides(obj: dict, overrides: dict | None, _prefix: str = "") -> dict:
    """obj 를 제자리에서 수정하고 반환한다."""
    for key, value in (overrides or {}).items():
        path = f"{_prefix}{key}"
        if "." in key:
            set_path(obj, key, value)
            continue
        if key not in obj:
            raise OverrideError(f"override 키 '{path}' 없음")
        if isinstance(value, dict) and isinstance(obj[key], dict) and set(value.keys()) != {"$add"}:
            apply_overrides(obj[key], value, _prefix=f"{path}.")
        else:
            obj[key] = _resolve(obj[key], value, path)
    return obj


# ------------------------------------------------------------------ loaders

def load_physics(overrides: dict | None = None) -> dict:
    return apply_overrides(_read(DATA_DIR / "physics_config.json"), overrides)


def load_decision_cfg(overrides: dict | None = None) -> dict:
    cfg = apply_overrides(_read(DATA_DIR / "decision_config.json"), overrides)
    env_url = os.environ.get("ZORO1_URL")
    if env_url:
        cfg["zoro1"]["url"] = env_url
    # 모델에 줄 선택지: executable(실행 가능한 후보만, 기본) | all_passed(정책 통과 후보 전부 = 정보 요청·이관 포함)
    choice_set = os.environ.get("NEXTERA_CHOICE_SET")
    if choice_set:
        if choice_set not in ("executable", "all_passed"):
            raise ConfigError("NEXTERA_CHOICE_SET 은 executable 또는 all_passed 여야 합니다")
        cfg["choice_set"] = choice_set
    return cfg


def load_policy() -> dict:
    """{"version": "1.2", "policies": [...], ...} — 프론트 시드 그대로."""
    return _read(SEED_DIR / "policy_v1.2.json")


def load_roles() -> list[dict]:
    return _read(SEED_DIR / "roles.json")


def load_incidents() -> dict:
    data = _read(DATA_DIR / "incidents.json")
    return {k: v for k, v in data.items() if not k.startswith("_")}


def load_incident(incident_id: str) -> dict:
    incidents = load_incidents()
    if incident_id not in incidents:
        raise ConfigError(f"사건 '{incident_id}' 없음. 사용 가능: {sorted(incidents)}")
    return {"id": incident_id, **incidents[incident_id]}


def load_snapshot(ref: str) -> dict:
    """ref = "seed:snapshot_S0.json" 또는 backend/data 기준 상대 경로."""
    path = SEED_DIR / ref[5:] if ref.startswith("seed:") else DATA_DIR / ref
    snap = _read(path)
    validate_snapshot(snap)
    return snap


def validate_snapshot(snap: dict) -> None:
    sid = snap.get("snapshot_id", "?")
    zone_ids = {z["id"] for z in snap["zones"]}
    node_ids = [n["id"] for n in snap["nodes"]]
    job_ids = [j["id"] for j in snap["jobs"]]
    if len(node_ids) != len(set(node_ids)) or len(job_ids) != len(set(job_ids)):
        raise ConfigError(f"{sid}: 노드 또는 작업 id 중복")
    for n in snap["nodes"]:
        if n["zone_id"] not in zone_ids:
            raise ConfigError(f"{sid}: 노드 {n['id']} 의 구역 {n['zone_id']} 없음")
        if not 0 <= n["gpus_free"] <= n["gpus_total"]:
            raise ConfigError(f"{sid}: 노드 {n['id']} gpus_free 범위 오류")
        for jid in n["job_ids"]:
            if jid not in job_ids:
                raise ConfigError(f"{sid}: 노드 {n['id']} 의 작업 {jid} 없음")
    for j in snap["jobs"]:
        if j["node_id"] is not None and j["node_id"] not in node_ids:
            raise ConfigError(f"{sid}: 작업 {j['id']} 의 노드 {j['node_id']} 없음")


def snapshot_version(snap: dict) -> str:
    """상태 버전: 판단에 쓰이는 내용(노드·작업·구역·메모)의 해시. 온도 이력은 제외."""
    core = {k: snap[k] for k in ("nodes", "jobs", "zones", "notes")}
    return f"{snap['snapshot_id']}@{canonical_hash(core)}"


def deep(obj: Any) -> Any:
    return copy.deepcopy(obj)

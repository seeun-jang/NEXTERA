"""Zoro-1 입력 조립 (어댑터·라우터와 분리).

build_request(...) → {"state": {...}, "questions": {...}}   (Zoro-1 /v1/decide 의 "request" 값)

전략 버전
- v1_raw            : 상태·메모·정책·후보를 있는 그대로 요약
- v2_tradeoff_hints : v1 + 후보별 시뮬레이션 트레이드오프(최고 온도·냉각 에너지·마감 여유)와 메모 맥락

언어(lang): "en" | "ko" — 지시문과 후보 설명의 언어. 운영 메모와 정책 문구는 원문 그대로 넣는다.
"""
from __future__ import annotations

from .simulator import job_map, node_map, policy_limits

STRATEGIES = ("v1_raw", "v2_tradeoff_hints")
LANGS = ("en", "ko")

ROLE_TEXT = {
    "en": {"cooling_A": "Cooling Ops", "gpu_B": "GPU Ops"},
    "ko": {"cooling_A": "냉각 운영", "gpu_B": "GPU 운영"},
}

OBJECTIVE_TEXT = {
    "en": {
        "balanced": "meet job deadlines first, then avoid thermal throttling, then minimize cooling energy",
        "energy": "meet job deadlines first, then minimize cooling energy and power peaks",
        "performance": "finish the priority job as early as possible, then avoid thermal throttling",
    },
    "ko": {
        "balanced": "마감 준수 우선, 그다음 열 스로틀링 회피, 그다음 냉각 에너지 절감",
        "energy": "마감 준수 우선, 그다음 냉각 에너지와 전력 피크 절감",
        "performance": "우선 작업을 가능한 한 빨리 완료, 그다음 열 스로틀링 회피",
    },
}

TEXT = {
    "en": {
        "action": "Choose the single best response to this thermal incident. Hard rules can never be broken. "
                  "Objective priority: {objective}. Use the ops notes as context.",
        "memo": "Does the ops memo indicate cooling degradation or thermal risk on the hot node?",
        "risk": "How severe is the thermal and SLA conflict?",
        "risk_levels": ["low", "elevated", "critical"],
        "hard_rules": [
            "P0 jobs must never be stopped, moved, or deferred.",
            "Predicted peak node temperature must stay at or below {limit:g}°C.",
            "A migration target node must have at least as many free GPUs as the job requests.",
        ],
        "approve": " Needs approval by {role}.",
        "cooling": "Raise cooling of zone {zone} from level {frm} to {to} (max {mx}). Uses more cooling power.",
        "migrate": "Move job {job} ({prio}, {gpus} GPUs) from {src} to {dst} ({free} GPUs free). Restart costs {restart:g} min.",
        "defer": "Pause job {job} ({prio}, on {node}) for {minutes} min.",
        "info": "Request more information before acting; changes nothing now.",
        "esc": "Hand the decision to a human operator; changes nothing now.",
        "hint": " Simulated: peak {peak:.1f}°C on {node} (limit {limit:g}°C{exceed}); cooling energy {kwh:.3f} kWh "
                "({delta:+.1f}% vs no action){jobpart}.",
        "exceed": ", EXCEEDS LIMIT",
        "jobpart": "; {job} finishes at {fin:.1f} min vs deadline {dl:g} min ({state})",
        "late": "late by {x:.1f} min", "slack": "slack {x:.1f} min",
    },
    "ko": {
        "action": "이 열 위험 사건에 대한 최선의 대응 하나를 고르세요. 필수 규칙은 어길 수 없습니다. "
                  "목표 우선순위: {objective}. 운영 메모를 맥락으로 반영하세요.",
        "memo": "운영 메모가 고온 노드의 냉각 저하 또는 열 위험을 가리킵니까?",
        "risk": "열 위험과 마감(SLA) 충돌이 얼마나 심각합니까?",
        "risk_levels": ["낮음", "주의", "심각"],
        "hard_rules": [
            "P0 작업은 중단·이동·연기할 수 없다.",
            "예측 최고 노드 온도는 {limit:g}°C 이하여야 한다.",
            "이동 대상 노드의 여유 GPU는 작업 요청 GPU 수 이상이어야 한다.",
        ],
        "approve": " {role} 승인 필요.",
        "cooling": "{zone} 구역 냉각을 레벨 {frm}에서 {to}로 강화(최대 {mx}). 냉각 전력이 늘어난다.",
        "migrate": "작업 {job}({prio}, GPU {gpus}장)을 {src}에서 {dst}(여유 GPU {free}장)로 이동. 재시작 비용 {restart:g}분.",
        "defer": "작업 {job}({prio}, {node})을 {minutes}분 동안 정지.",
        "info": "행동 전에 추가 정보를 요청한다. 지금은 아무것도 바꾸지 않는다.",
        "esc": "판단을 운영자에게 넘긴다. 지금은 아무것도 바꾸지 않는다.",
        "hint": " 시뮬레이션: 최고 {peak:.1f}°C({node}, 한계 {limit:g}°C{exceed}), 냉각 에너지 {kwh:.3f} kWh"
                "(조치 없음 대비 {delta:+.1f}%){jobpart}.",
        "exceed": ", 한계 초과",
        "jobpart": ", {job} 완료 {fin:.1f}분 / 마감 {dl:g}분({state})",
        "late": "{x:.1f}분 초과", "slack": "여유 {x:.1f}분",
    },
}


def _tradeoff(sim: dict, baseline: dict, primary_job: str | None) -> dict:
    base_cool = baseline["cooling_kwh"]
    out = {
        "predicted_peak_temp_c": round(sim["peak_temp_c"], 1),
        "peak_node": sim["peak_node"],
        "exceeds_safety_limit": bool(sim["violates_limit"]),
        "throttle_min": round(sim["throttle_job_s"] / 60.0, 1),
        "cooling_kwh": round(sim["cooling_kwh"], 3),
        "cooling_vs_no_action_pct": round((sim["cooling_kwh"] - base_cool) / base_cool * 100.0, 1) if base_cool > 0 else 0.0,
        "completed_work_gpu_min": round(sim["completed_work_gpu_s"] / 60.0, 1),
        "deadline_misses": list(sim["deadline_misses"]),
    }
    job = sim["jobs"].get(primary_job) if primary_job else None
    if job and job["finish_s"] is not None:
        out["primary_job"] = primary_job
        out["primary_job_finish_min"] = round(job["finish_s"] / 60.0, 1)
        if job["deadline_s"] is not None:
            out["primary_job_deadline_min"] = round(job["deadline_s"] / 60.0, 1)
            out["primary_job_slack_min"] = round(job["slack_s"] / 60.0, 1)
    return out


def describe(c: dict, snap: dict, lang: str) -> str:
    t = TEXT[lang]
    nodes, jobs = node_map(snap), job_map(snap)
    p = c["params"]
    if c["type"] == "cooling_change":
        z = next(z for z in snap["zones"] if z["id"] == p["zone"])
        text = t["cooling"].format(zone=p["zone"], frm=p["from"], to=p["to"], mx=z["cooling_max"])
    elif c["type"] == "job_migrate":
        j = jobs[p["job"]]
        text = t["migrate"].format(job=j["id"], prio=j["priority"], gpus=j["gpus"], src=j["node_id"], dst=p["to"],
                                   free=nodes[p["to"]]["gpus_free"], restart=j.get("restart_cost_min") or 0)
    elif c["type"] == "job_defer":
        j = jobs[p["job"]]
        text = t["defer"].format(job=j["id"], prio=j["priority"], node=j["node_id"], minutes=p.get("minutes"))
    elif c["type"] == "request_info":
        text = t["info"]
    else:
        text = t["esc"]
    role = c.get("requires_approval_role")
    if role:
        text += t["approve"].format(role=ROLE_TEXT[lang].get(role, role))
    return text


def build_request(
    *,
    snap: dict,
    incident: dict,
    policy: dict,
    options: list[dict],
    sims: dict[str, dict],
    no_action_sim: dict,
    strategy_version: str = "v2_tradeoff_hints",
    lang: str = "en",
    objective: str = "balanced",
    include_diagnostics: bool = True,
) -> dict:
    if strategy_version not in STRATEGIES:
        raise ValueError(f"알 수 없는 strategy_version '{strategy_version}'. 사용 가능: {STRATEGIES}")
    if lang not in LANGS:
        raise ValueError(f"알 수 없는 lang '{lang}'. 사용 가능: {LANGS}")
    t = TEXT[lang]
    limit_c, throttle_c = policy_limits(policy)
    primary_job = (incident.get("job_ids") or [None])[0]

    state: dict = {
        "incident": {"id": incident["id"], "title": incident.get("title"),
                     "hot_nodes": incident.get("node_ids", []), "priority_jobs": incident.get("job_ids", [])},
        "time": snap.get("sim_time"),
        "nodes": [
            {"id": n["id"], "zone": n["zone_id"], "temp_c": n["temp_c"], "gpu_util_pct": n["gpu_util_pct"],
             "power_kw": n["power_kw"], "gpus_total": n["gpus_total"], "gpus_free": n["gpus_free"],
             "jobs": n["job_ids"], "flags": n["flags"]}
            for n in snap["nodes"]
        ],
        "jobs": [
            {"id": j["id"], "priority": j["priority"], "node": j["node_id"], "gpus": j["gpus"],
             "remaining_min": j["remaining_min"], "deadline_min": j["deadline_min"],
             "restart_cost_min": j.get("restart_cost_min"), "status": j["status"]}
            for j in snap["jobs"]
        ],
        "zones": [{"id": z["id"], "cooling_level": z["cooling_level"], "cooling_max": z["cooling_max"]} for z in snap["zones"]],
        "ops_notes": [{"author": n.get("author"), "time": n.get("created_at"), "node": n.get("node_id"), "text": n["text"]}
                      for n in snap.get("notes", [])],
        "policy": {
            "version": policy["version"],
            "hard_rules": [r.format(limit=limit_c) for r in t["hard_rules"]],
            "source_text": [{"id": p["id"], "type": p["type"], "text": p["text"]} for p in policy["policies"]],
        },
        "limits": {"safety_limit_c": limit_c, "throttle_c": throttle_c},
        "objective_priority": OBJECTIVE_TEXT[lang].get(objective, OBJECTIVE_TEXT[lang]["balanced"]),
    }
    if (snap.get("site") or {}).get("power_cap_kw"):
        state["site"] = snap["site"]

    criteria: dict[str, str] = {}
    for c in options:
        text = describe(c, snap, lang)
        if strategy_version == "v2_tradeoff_hints" and c["id"] in sims:
            sim = sims[c["id"]]
            base_cool = no_action_sim["cooling_kwh"]
            delta = (sim["cooling_kwh"] - base_cool) / base_cool * 100.0 if base_cool > 0 else 0.0
            jobpart = ""
            job = sim["jobs"].get(primary_job) if primary_job else None
            if job and job["finish_s"] is not None and job["deadline_s"] is not None:
                late = job["lateness_s"] > 0
                state_text = (t["late"] if late else t["slack"]).format(x=(job["lateness_s"] if late else job["slack_s"]) / 60.0)
                jobpart = t["jobpart"].format(job=primary_job, fin=job["finish_s"] / 60.0, dl=job["deadline_s"] / 60.0, state=state_text)
            text += t["hint"].format(peak=sim["peak_temp_c"], node=sim["peak_node"], limit=limit_c,
                                     exceed=t["exceed"] if sim["violates_limit"] else "",
                                     kwh=sim["cooling_kwh"], delta=delta, jobpart=jobpart)
        criteria[c["id"]] = text

    if strategy_version == "v2_tradeoff_hints":
        state["no_action_forecast"] = _tradeoff(no_action_sim, no_action_sim, primary_job)
        state["tradeoffs"] = {c["id"]: _tradeoff(sims[c["id"]], no_action_sim, primary_job) for c in options if c["id"] in sims}
        noted = {n.get("node_id") for n in snap.get("notes", []) if n.get("node_id")}
        state["memo_context"] = {
            "notes_target_nodes": sorted(noted),
            "notes_target_is_hot_node": bool(noted & set(incident.get("node_ids", []))),
            "node_flags": {n["id"]: n["flags"] for n in snap["nodes"] if n["flags"]},
        }

    questions: dict[str, dict] = {
        "action": {
            "type": "choice",
            "instructions": t["action"].format(objective=state["objective_priority"]),
            "criteria": criteria,
        }
    }
    if include_diagnostics:
        questions["memo_thermal_risk"] = {"type": "noul", "instructions": t["memo"]}
        questions["risk_level"] = {"type": "score", "instructions": t["risk"], "criteria": list(t["risk_levels"])}
    return {"state": state, "questions": questions}

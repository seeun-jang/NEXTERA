"""SQLite 저장소. 세션(접속자)별로 결정·검사·승인·실행·영수증 이벤트를 보존한다.

- objects(session, kind, id) → JSON 본문. 삽입 순서를 ord 로 보존한다.
- events(session, seq)       → 영수증 이벤트. 추가만 한다(append-only).
"""
from __future__ import annotations

import json
import sqlite3
import threading
from typing import Any


class Store:
    def __init__(self, path: str = ":memory:"):
        self._db = sqlite3.connect(path, check_same_thread=False, isolation_level=None)
        self._lock = threading.RLock()
        with self._lock:
            self._db.execute("PRAGMA journal_mode=WAL")
            self._db.execute(
                "CREATE TABLE IF NOT EXISTS objects ("
                "session TEXT NOT NULL, kind TEXT NOT NULL, id TEXT NOT NULL, ord INTEGER NOT NULL, body TEXT NOT NULL, "
                "PRIMARY KEY (session, kind, id))")
            self._db.execute(
                "CREATE TABLE IF NOT EXISTS events ("
                "session TEXT NOT NULL, seq INTEGER NOT NULL, body TEXT NOT NULL, PRIMARY KEY (session, seq))")

    # ------------------------------------------------------------ objects
    def put(self, session: str, kind: str, oid: str, obj: Any) -> None:
        body = json.dumps(obj, ensure_ascii=False)
        with self._lock:
            row = self._db.execute("SELECT ord FROM objects WHERE session=? AND kind=? AND id=?", (session, kind, oid)).fetchone()
            if row:
                self._db.execute("UPDATE objects SET body=? WHERE session=? AND kind=? AND id=?", (body, session, kind, oid))
            else:
                nxt = self._db.execute("SELECT COALESCE(MAX(ord), 0) + 1 FROM objects WHERE session=?", (session,)).fetchone()[0]
                self._db.execute("INSERT INTO objects (session, kind, id, ord, body) VALUES (?,?,?,?,?)", (session, kind, oid, nxt, body))

    def get(self, session: str, kind: str, oid: str) -> Any | None:
        with self._lock:
            row = self._db.execute("SELECT body FROM objects WHERE session=? AND kind=? AND id=?", (session, kind, oid)).fetchone()
        return json.loads(row[0]) if row else None

    def list(self, session: str, kind: str) -> list[Any]:
        with self._lock:
            rows = self._db.execute("SELECT body FROM objects WHERE session=? AND kind=? ORDER BY ord", (session, kind)).fetchall()
        return [json.loads(r[0]) for r in rows]

    def list_all(self, kind: str) -> list[tuple[str, Any]]:
        """모든 세션의 객체 (분석용)."""
        with self._lock:
            rows = self._db.execute("SELECT session, body FROM objects WHERE kind=? ORDER BY session, ord", (kind,)).fetchall()
        return [(r[0], json.loads(r[1])) for r in rows]

    # ------------------------------------------------------------- events
    def add_event(self, session: str, event: dict) -> dict:
        with self._lock:
            seq = self._db.execute("SELECT COALESCE(MAX(seq), 0) + 1 FROM events WHERE session=?", (session,)).fetchone()[0]
            event = {**event, "seq": seq}
            self._db.execute("INSERT INTO events (session, seq, body) VALUES (?,?,?)", (session, seq, json.dumps(event, ensure_ascii=False)))
        return event

    def events(self, session: str) -> list[dict]:
        with self._lock:
            rows = self._db.execute("SELECT body FROM events WHERE session=? ORDER BY seq", (session,)).fetchall()
        return [json.loads(r[0]) for r in rows]

    def all_events(self) -> list[tuple[str, dict]]:
        with self._lock:
            rows = self._db.execute("SELECT session, body FROM events ORDER BY session, seq").fetchall()
        return [(r[0], json.loads(r[1])) for r in rows]

    # ------------------------------------------------------------ session
    def clear_session(self, session: str) -> None:
        with self._lock:
            self._db.execute("DELETE FROM objects WHERE session=?", (session,))
            self._db.execute("DELETE FROM events WHERE session=?", (session,))

    def sessions(self) -> list[str]:
        with self._lock:
            rows = self._db.execute("SELECT DISTINCT session FROM objects ORDER BY session").fetchall()
        return [r[0] for r in rows]

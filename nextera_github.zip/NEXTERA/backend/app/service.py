"""NEXTERA API 서비스 — 계약(shared/contracts/types.ts)의 엔드포인트 동작.

HTTP 프레임워크와 무관하다(api.py 가 경로를 이 클래스의 메서드로 연결한다).
상태는 세션(X-Session 헤더)별로 SQLite 에 저장하므로 접속자끼리 서로의 시연을 덮어쓰지 않는다.
시각은 시뮬레이션 시각("HH:MM:SS")이며, 스냅샷 S0 는 사람이 판단하는 동안 고정된다.
"""
from __future__ import annotations

import os
import socket
import threading
import time
from typing import Any
from urllib.parse import urlparse

from . import CONTRACT_VERSION, candidates as cand_mod, config, engine, safety_gate
from .errors import ApiError, invalid, not_found
from .estimates import to_estimate
from .providers import PROVIDER_NAMES, Zoro1LocalAdapter, get_provider
from .simulator import job_map, simulate
from .store import Store

ROLE_IDS = ("operator", "cooling_A", "gpu_B", "policy_admin")
FAULT_MODES = ("off", "timeout", "invalid", "unreachable")
APPROVAL_ACTIONS = {"approve": "approved", "request_changes": "changes_requested", "reject": "rejected", "escalate": "escalated"}
APPROVAL_LABEL = {"approve": "승인", "request_changes": "수정 요청", "reject": "거부", "escalate": "이관"}
VERDICT_LOG = {"blocked": "BLOCKED · 실행 큐 제외", "conditional": "CONDITIONAL · 승인 필요", "allowed": "ALLOWED"}


def to_sec(t: str) -> int:
    h, m, s = (int(x) for x in t.split(":"))
    return h * 3600 + m * 60 + s


def to_time(sec: float) -> str:
    sec = int(round(sec))
    return f"{sec // 3600 % 24:02d}:{sec % 3600 // 60:02d}:{sec % 60:02d}"


class NexteraService:
    def __init__(self, db_path: str | None = None, provider_mode: str | None = None,
                 incident_id: str | None = None, overrides: dict | None = None):
        overrides = overrides or {}
        self.store = Store(db_path or os.environ.get("NEXTERA_DB") or str(config.BACKEND_DIR / "nextera.db"))
        self.policy = config.load_policy()
        self.roles = config.load_roles()
        self.physics = config.load_physics(overrides.get("physics"))
        self.decision_cfg = config.load_decision_cfg(overrides.get("decision"))
        self.incident = config.load_incident(incident_id or os.environ.get("NEXTERA_INCIDENT") or "INC-0412")
        self.seed = config.load_snapshot(self.incident["snapshot"])
        self.provider_mode = provider_mode or os.environ.get("NEXTERA_PROVIDER") or "zoro1"
        if self.provider_mode not in PROVIDER_NAMES:
            raise ValueError(f"NEXTERA_PROVIDER 는 {PROVIDER_NAMES} 중 하나여야 합니다 (받은 값: {self.provider_mode})")
        self.tag = self.incident["decision_prefix"].split("-", 1)[-1]
        self.base_id = self.seed["snapshot_id"]
        self._locks: dict[str, threading.RLock] = {}
        self._locks_guard = threading.Lock()
        self._reach_cache: tuple[float, bool] = (0.0, False)
        # 다중 작업 버전(/api/v2). 모델 연결 방식과 저장소만 함께 쓴다.
        from .multi.service import MultiService
        self.multi = MultiService(self.store, self.provider_mode, self.decision_cfg, overrides.get("multi"))

    # ================================================================ 내부 도구
    def _lock(self, session: str) -> threading.RLock:
        with self._locks_guard:
            return self._locks.setdefault(session, threading.RLock())

    def _ensure(self, s: str, scenario: dict | None = None) -> dict:
        meta = self.store.get(s, "meta", "meta")
        if meta is None:
            scenario = dict(scenario or {})
            # 상황 설정 값은 이 세션의 S0 에 그대로 들어간다(화면에 보이는 값 = 판단에 쓰는 값).
            # 운영 목표·승인 지연은 스냅샷 값이 아니므로 meta 에 두고 계산할 때마다 적용한다.
            snap, _, _ = engine.apply_changes(self.seed, self.incident, self.physics, scenario)
            meta = {"clock_s": to_sec(self.seed["sim_time"]), "counters": {}, "fault_mode": "off",
                    "decision_id": f"{self.incident['decision_prefix']}-01", "scenario": scenario}
            self.store.put(s, "meta", "meta", meta)
            self.store.put(s, "snapshot", self.base_id, snap)
            self.store.add_event(s, {
                "at": self.seed["sim_time"], "actor": "system", "type": "incident_detected",
                "summary": f"사건 감지 {self.incident['id']} · {self._title(snap)}", "ref_id": self.incident["id"],
            })
            if scenario:
                self.store.add_event(s, {
                    "at": self.seed["sim_time"], "actor": "operator", "type": "severity_changed", "is_assumption": True,
                    "summary": f"시연 상황 설정 · {self._describe_scenario(scenario)}", "ref_id": self.incident["id"],
                    "data": {"scenario": scenario},
                })
        return meta

    def _title(self, snap: dict) -> str:
        """사건 제목. 상황 설정으로 주 작업의 우선순위가 바뀌면 제목의 우선순위도 따라 바꾼다."""
        title = self.incident["title"]
        jid = (self.incident.get("job_ids") or [None])[0]
        seed_job = next((j for j in self.seed["jobs"] if j["id"] == jid), None)
        job = next((j for j in snap["jobs"] if j["id"] == jid), None)
        if seed_job and job and seed_job["priority"] != job["priority"]:
            title = title.replace(f"{seed_job['priority']} 작업", f"{job['priority']} 작업")
        return title

    def _describe_scenario(self, scenario: dict) -> str:
        jid = (self.incident.get("job_ids") or ["작업"])[0]
        nid = (self.incident.get("node_ids") or ["노드"])[0]
        spare = self.incident.get("spare_node") or "대상 노드"
        zone = (self.incident["candidates"].get("cooling_zones") or ["구역"])[0]
        label = {
            "n4_temp_c": lambda v: f"{nid} {v:g}°C",
            "deadline_min": lambda v: f"{jid} 마감 {v:g}분",
            "j07_priority": lambda v: f"{jid} {v}",
            "n2_gpus_free": lambda v: f"{spare} 여유 GPU {v:g}장",
            "cooling_max": lambda v: f"{zone} 냉각 상한 {v:g}",
            "objective": lambda v: {"energy": "에너지 우선", "performance": "성능 우선"}.get(v, "균형"),
            "approval_delay_min": lambda v: f"승인 지연 {v:g}분",
            "without_notes": lambda v: "운영 메모 없음",
        }
        return " · ".join(label[k](v) if k in label else f"{k}={v}" for k, v in scenario.items())

    def _scenario(self, s: str) -> dict:
        return self._ensure(s).get("scenario") or {}

    def _runtime(self, s: str) -> dict:
        """상황 설정 가운데 스냅샷 밖의 값(운영 목표·승인 지연)."""
        sc = self._scenario(s)
        return {k: sc[k] for k in engine.SCENARIO_RUNTIME_KEYS if k in sc}

    def _physics(self, s: str) -> dict:
        """이 세션의 물리 설정(상황 설정의 승인 지연 반영)."""
        rt = self._runtime(s)
        if "approval_delay_min" not in rt:
            return self.physics
        return engine.apply_changes(self.seed, self.incident, self.physics, {"approval_delay_min": rt["approval_delay_min"]})[1]

    def _now(self, s: str, advance: int = 1) -> str:
        meta = self._ensure(s)
        meta["clock_s"] += advance
        self.store.put(s, "meta", "meta", meta)
        return to_time(meta["clock_s"])

    def _next(self, s: str, name: str) -> int:
        meta = self._ensure(s)
        meta["counters"][name] = meta["counters"].get(name, 0) + 1
        self.store.put(s, "meta", "meta", meta)
        return meta["counters"][name]

    def _log(self, s: str, *, actor: str, type: str, summary: str, at: str | None = None, **extra: Any) -> dict:
        event = {"at": at or self._now(s), "actor": actor, "type": type, "summary": summary}
        event.update({k: v for k, v in extra.items() if v is not None})
        return self.store.add_event(s, event)

    def _live(self, s: str) -> dict:
        self._ensure(s)
        return self.store.get(s, "snapshot", self.base_id)

    def _snapshot(self, s: str, snapshot_id: str) -> dict:
        self._ensure(s)
        snap = self.store.get(s, "snapshot", snapshot_id)
        if snap is None:
            raise not_found(f"스냅샷 {snapshot_id}가 없습니다.")
        return snap

    def _decision_id(self, s: str) -> str:
        return self._ensure(s)["decision_id"]

    def _check_decision_id(self, s: str, decision_id: str) -> None:
        if decision_id != self._decision_id(s):
            raise not_found(f"결정 {decision_id}가 없습니다.")

    def _role(self, role: str | None) -> str:
        role = role or "operator"
        if role not in ROLE_IDS:
            raise invalid(f"알 수 없는 역할 '{role}'. 허용: {list(ROLE_IDS)}")
        return role

    def _changes_of(self, s: str, branch_id: str) -> dict:
        if branch_id == self.base_id:
            return {}
        exp = self.store.get(s, "experiment", branch_id) or self.store.get(s, "pending_branch", branch_id)
        if exp is None:
            raise not_found(f"실험 분기 {branch_id}가 없습니다.")
        return exp["changes"]

    def _prepare(self, s: str, branch_id: str, changes: dict | None = None) -> engine.Prepared:
        changes = self._changes_of(s, branch_id) if changes is None else changes
        changes = {**self._runtime(s), **changes}   # 상황 설정 위에 실험 조건을 덮어쓴다
        try:
            snap, physics, objective = engine.apply_changes(self._live(s), self.incident, self.physics, changes)
        except engine.ChangeError as e:
            raise invalid(str(e)) from e
        if branch_id != self.base_id:
            snap["snapshot_id"], snap["parent_id"], snap["source"] = branch_id, self.base_id, "assumption"
        return engine.prepare(snap, self.incident, self.policy, physics, self.decision_cfg, objective)

    def _candidates(self, s: str) -> list[dict]:
        return cand_mod.build_candidates(self._live(s), self.incident, self.policy)

    def _estimate(self, prep: engine.Prepared, action_id: str | None) -> dict:
        """prep 의 조건에서 행동 하나의 Estimate. 후보에 없거나 탈락한 행동도 '했다면'을 계산해 위반을 표시한다."""
        if action_id is None:
            return to_estimate(prep.no_action_sim, prep.no_action_sim, prep.physics, self.incident["job_ids"])
        cand = cand_mod.find(prep.candidates, action_id)
        extra_violation = None
        if cand is None:
            base = cand_mod.find(cand_mod.build_candidates(self.seed, self.incident, self.policy), action_id)
            if base is None:
                raise invalid(f"알 수 없는 행동 {action_id}")
            cand, extra_violation = base, "NOT_AVAILABLE"
        elif cand["filtered_out"]:
            extra_violation = cand["filter_reason"]
        sim = prep.sims.get(action_id)
        if sim is None:
            if cand["type"] in cand_mod.EXECUTABLE_TYPES and extra_violation != "POL-01":
                sim = simulate(prep.snap, prep.physics, self.policy, cand)
            else:
                sim = dict(prep.no_action_sim, action_id=action_id)
        est = to_estimate(sim, prep.no_action_sim, prep.physics, self.incident["job_ids"])
        est["action_id"] = action_id
        if extra_violation and extra_violation not in est["violations"]:
            est["violations"].insert(0, extra_violation)
            est["risk"], est["risk_note"] = "high", f"정책상 실행 불가 ({extra_violation})"
        return est

    def _label(self, cands: list[dict], action_id: str | None) -> str:
        c = cand_mod.find(cands, action_id) if action_id else None
        return c["label"] if c else str(action_id)

    # ================================================================ 상태·사건·정책
    def _zoro_reachable(self) -> bool:
        if self.provider_mode == "zoro1_local":
            return Zoro1LocalAdapter._decider is not None
        if self.provider_mode != "zoro1":
            return False
        stamp, value = self._reach_cache
        if time.time() - stamp < 5.0:
            return value
        url = urlparse(self.decision_cfg["zoro1"]["url"])
        try:
            with socket.create_connection((url.hostname, url.port or 80), timeout=0.5):
                value = True
        except OSError:
            value = False
        self._reach_cache = (time.time(), value)
        return value

    def health(self, s: str) -> dict:
        meta = self._ensure(s)
        contract_mode = {"zoro1": "zoro1", "zoro1_local": "zoro1", "mock": "mock", "rule": "rule"}[self.provider_mode]
        return {
            "status": "ok", "contract_version": CONTRACT_VERSION, "provider_mode": contract_mode,
            "zoro1_reachable": self._zoro_reachable(),
            "provider_backend": self.provider_mode, "fault_mode": meta["fault_mode"],
            "incident_id": self.incident["id"], "horizon_ticks": int(self.physics["rollout_ticks"]),
            "physics_version": self.physics["version"], "physics_hash": config.canonical_hash(self.physics),
            "scenario": meta.get("scenario") or {},
        }

    def reset(self, s: str, body: dict | None = None) -> dict:
        """시연 초기화. body.scenario(01 상황 설정 값)를 주면 그 상황의 S0 로 시작한다."""
        scenario = (body or {}).get("scenario") or {}
        if not isinstance(scenario, dict):
            raise invalid("scenario 는 객체여야 합니다")
        try:
            engine.apply_changes(self.seed, self.incident, self.physics, scenario)   # 값 검증(잘못되면 400, 상태는 그대로)
        except engine.ChangeError as e:
            raise invalid(str(e)) from e
        with self._lock(s):
            self.store.clear_session(s)
            self._ensure(s, scenario)
            return {"snapshot_id": self.base_id, "scenario": scenario}

    def set_fault(self, s: str, body: dict) -> dict:
        mode = (body or {}).get("mode", "off")
        if mode not in FAULT_MODES:
            raise invalid(f"mode 는 {list(FAULT_MODES)} 중 하나여야 합니다")
        with self._lock(s):
            meta = self._ensure(s)
            meta["fault_mode"] = mode
            self.store.put(s, "meta", "meta", meta)
            return {"mode": mode}

    def drift(self, s: str, body: dict) -> dict:
        """시연용: 판단 이후 현장 상태가 바뀐 상황을 만든다(예: 다른 작업이 대상 노드의 GPU를 차지)."""
        body = body or {}
        with self._lock(s):
            snap = self._live(s)
            node = next((n for n in snap["nodes"] if n["id"] == body.get("node_id")), None)
            free = body.get("gpus_free")
            if node is None or not isinstance(free, int) or not 0 <= free <= node["gpus_total"]:
                raise invalid("node_id 와 gpus_free(0~gpus_total 정수)가 필요합니다")
            before = config.snapshot_version(snap)
            node["gpus_free"] = free
            self.store.put(s, "snapshot", self.base_id, snap)
            self._log(s, actor="system", type="severity_changed",
                      summary=f"현장 상태 변화 감지 · {node['id']} 여유 GPU {free}장 (시연용 주입)", ref_id=node["id"],
                      data={"state_version_before": before, "state_version_after": config.snapshot_version(snap)})
            return {"state_version": config.snapshot_version(snap), "node_id": node["id"], "gpus_free": free}

    def get_state(self, s: str, snapshot_id: str | None = None) -> dict:
        return self._snapshot(s, snapshot_id or self.base_id)

    def get_incident(self, s: str, incident_id: str) -> dict:
        if incident_id != self.incident["id"]:
            raise not_found(f"사건 {incident_id}가 없습니다.")
        snap = self._live(s)
        physics = self._physics(s)
        base_sim = simulate(snap, physics, self.policy, None)
        forecast = to_estimate(base_sim, base_sim, physics, self.incident["job_ids"])
        executed = any(e["status"] == "succeeded" for e in self.store.list(s, "execution"))
        pending = any(a["status"] == "pending" for a in self.store.list(s, "approval"))
        return {
            "id": self.incident["id"],
            "severity": {"high": "high", "medium": "medium", "low": "low"}[forecast["risk"]],
            "title": self._title(snap),
            "node_ids": self.incident["node_ids"], "job_ids": self.incident["job_ids"],
            "detected_at": self.seed["sim_time"],
            "status": "executed" if executed else ("awaiting_approval" if pending else "needs_decision"),
            "policy_refs": self.incident["policy_refs"], "snapshot_id": self.base_id,
            "no_action_forecast": forecast,
        }

    def get_policies(self, s: str, version: str | None = None) -> dict:
        current = self.policy["version"]
        if version and version.lstrip("v") != current:
            raise not_found(f"정책 버전 {version}이 없습니다.")
        return {"version": current, "policies": self.policy["policies"], "roles": self.roles,
                "candidates": self._candidates(s),
                "label": self.policy.get("label"), "manual_excerpt": self.policy.get("manual_excerpt")}

    # ================================================================ 판단
    def _run_decision(self, s: str, branch_id: str, changes: dict | None = None) -> tuple[dict, engine.Prepared, dict]:
        meta = self._ensure(s)
        prep = self._prepare(s, branch_id, changes)
        fault = None if meta["fault_mode"] == "off" else meta["fault_mode"]
        provider = get_provider(self.provider_mode, self.decision_cfg, fault_mode=fault)
        out = engine.decide(prep, provider)
        cands = prep.candidates
        is_base = branch_id == self.base_id
        ver = self.policy["version"]
        passed = sum(1 for c in cands if not c["filtered_out"])

        self._log(s, actor="system", type="policy_applied", ref_id=branch_id,
                  summary=f"정책 v{ver} 적용 · 후보 {len(cands)} → {passed}", is_assumption=(not is_base) or None)
        if out["model_error"]:
            injected = fault is not None
            self._log(s, actor="system", type="model_error", ref_id=branch_id,
                      summary=f"Zoro-1 호출 실패 · {out['fallback_reason']}" + (" (시연용 장애 주입)" if injected else ""),
                      data={"error": out["model_error"], "fault_injected": injected})
            self._log(s, actor="system", type="fallback", provider="rule", ref_id=branch_id,
                      summary="규칙 폴백으로 전환 · 같은 Safety Gate 적용")

        created_at = self._now(s, 2)
        decision = {
            "decision_id": meta["decision_id"], "incident_id": self.incident["id"], "snapshot_id": branch_id,
            "policy_version": ver, "branch_id": branch_id,
            "provider": out["provider"], "selected_id": out["selected_id"], "probs": out["probs"],
            "rationale": out["rationale"], "latency_ms": out["latency_ms"],
            "fallback_reason": out["fallback_reason"], "created_at": created_at,
            # ---- 계약 v1.1 선택 필드
            "decision_mode": out["decision_mode"], "is_fallback": out["is_fallback"],
            "proposed_id": out["proposed_id"], "modified_after_block": out["modified_after_block"],
            "blocked": out["blocked"], "direct_probs": out["direct_probs"],
            "escalated_questions": out["escalated_questions"],
            "diagnostics": out["diagnostics"], "review": out["review"],
            "sim_explanation": out["sim_explanation"], "model_error": out["model_error"],
            "reasoning_text": out["reasoning_text"],
            "fault_injected": bool(out["model_error"]) and fault is not None,
            "meta": out["meta"],
        }
        proposed_label = self._label(cands, out["proposed_id"])
        data = {"decision_mode": out["decision_mode"], "probs": out["probs"], "latency_ms": out["latency_ms"],
                "review": out["review"], "diagnostics": out["diagnostics"], "meta": out["meta"]}
        if out["is_real_model"]:
            data.update({"zoro1_request": out["request"], "zoro1_answers": out["answers"],
                         "direct_answers": out["direct_answers"], "raw_extra_fields": out["raw_extra_fields"],
                         "reasoning_text": out["reasoning_text"]})
        prefix = "판단" if is_base else f"실험 {branch_id} 판단"
        self._log(s, at=created_at, actor="model" if out["is_real_model"] else "system", type="decision_made",
                  provider=out["provider"], ref_id=branch_id, is_assumption=(not is_base) or None,
                  summary=f"{prefix}: {proposed_label}", data=data)
        if out["modified_after_block"]:
            self._log(s, actor="system", type="blocked", ref_id=branch_id, is_assumption=(not is_base) or None,
                      summary=f"제안 차단 · {proposed_label} · {', '.join(out['blocked']['violations'])}",
                      data={"checks": out["blocked"]["checks"]})
            self._log(s, actor="system", type="decision_made", provider=out["provider"], ref_id=branch_id,
                      is_assumption=(not is_base) or None,
                      summary=f"수정 판단: {self._label(cands, out['selected_id'])} (필수 규칙을 지키는 차순위)")

        chosen = cand_mod.find(cands, out["selected_id"])
        if chosen and chosen["type"] in ("escalate", "request_info"):
            # 설비 조작 대신 사람에게 넘긴 판단: 승인·실행 없이 기록만 남긴다 (알림은 실제로 보내지 않는다)
            self._log(s, actor="system", type="escalated", ref_id=branch_id, is_assumption=(not is_base) or None,
                      summary=f"{chosen['label']} · 허용된 설비 조작이 조건을 만족하지 못해 사람에게 넘김 (알림 미발송)",
                      data={"reason": out["fallback_reason"]})

        self.store.put(s, "decision", branch_id, decision)
        self.store.put(s, "candidates", branch_id, cands)
        run_no = self._next(s, "run")
        self.store.put(s, "run", f"{run_no:04d}", {
            "run": run_no, "branch_id": branch_id, "changes": self._changes_of(s, branch_id) if changes is None else changes,
            "input_hash": config.canonical_hash({"state": out["meta"]["state_version"], "policy": ver,
                                                 "physics": out["meta"]["physics_hash"], "objective": out["meta"]["objective"]}),
            "selected_id": out["selected_id"], "provider": out["provider"], "decision_mode": out["decision_mode"],
            "created_at": created_at, "trace": out["trace"], "request": out["request"], "answers": out["answers"],
        })
        return decision, prep, out

    def decide(self, s: str, body: dict) -> dict:
        body = body or {}
        branch = body.get("branch_id") or body.get("snapshot_id") or self.base_id
        if body.get("incident_id") not in (None, self.incident["id"]):
            raise not_found(f"사건 {body.get('incident_id')}가 없습니다.")
        pv = body.get("policy_version")
        if pv and str(pv).lstrip("v") != self.policy["version"]:
            raise invalid(f"정책 버전 불일치: 요청 {pv}, 현재 {self.policy['version']}")
        with self._lock(s):
            self._snapshot(s, branch)
            decision, prep, _ = self._run_decision(s, branch)
            return {"decision": decision, "candidates": prep.candidates}

    def get_decision(self, s: str, decision_id: str, branch: str | None = None) -> dict:
        self._check_decision_id(s, decision_id)
        branch = branch or self.base_id
        decision = self.store.get(s, "decision", branch)
        if decision is None:
            raise not_found(f"분기 {branch}의 판단이 아직 없습니다.")
        return {"decision": decision, "candidates": self.store.get(s, "candidates", branch) or []}

    def _base_experiment(self, s: str) -> dict:
        decision = self.store.get(s, "decision", self.base_id)
        if decision is None:
            decision, _, _ = self._run_decision(s, self.base_id)
        prep = self._prepare(s, self.base_id)
        return {"branch_id": self.base_id, "base_snapshot_id": self.base_id, "changes": {},
                "candidates": self.store.get(s, "candidates", self.base_id) or prep.candidates,
                "decision": decision, "estimate": self._estimate(prep, decision["selected_id"])}

    def create_experiment(self, s: str, body: dict, role: str | None = None) -> dict:
        body = body or {}
        base = body.get("base_snapshot_id") or self.base_id
        changes = body.get("changes")
        if not isinstance(changes, dict):
            raise invalid("changes 객체가 필요합니다")
        with self._lock(s):
            self._snapshot(s, base)
            merged = {**self._changes_of(s, base), **changes}
            self._prepare(s, self.base_id, merged)  # 조건 검증(잘못된 값이면 400)
            if self.store.get(s, "decision", self.base_id) is None:
                self._run_decision(s, self.base_id)
            branch_id = f"{base}-b{self._next(s, 'branch')}"
            self.store.put(s, "pending_branch", branch_id, {"changes": merged})
            decision, prep, _ = self._run_decision(s, branch_id)
            self.store.put(s, "snapshot", branch_id, prep.snap)
            exp = {"branch_id": branch_id, "base_snapshot_id": base, "changes": merged,
                   "candidates": prep.candidates, "decision": decision,
                   "estimate": self._estimate(prep, decision["selected_id"])}
            self.store.put(s, "experiment", branch_id, exp)
            desc = ", ".join(f"{k}={v}" for k, v in merged.items())
            self._log(s, actor=self._role(role), type="experiment_run", ref_id=branch_id, is_assumption=True,
                      summary=f"실험 {branch_id} ({desc} 가정)", data={"changes": merged})
            return exp

    def compare(self, s: str, branch_id: str) -> dict:
        with self._lock(s):
            self._ensure(s)
            branch = self.store.get(s, "experiment", branch_id)
            if branch is None:
                raise not_found(f"실험 분기 {branch_id}가 없습니다.")
            return {"base": self._base_experiment(s), "branch": branch, "changed_keys": list(branch["changes"].keys())}

    def futures(self, s: str, body: dict) -> dict:
        body = body or {}
        snapshot_id = body.get("snapshot_id") or self.base_id
        action_ids = body.get("action_ids")
        if not isinstance(action_ids, list) or not action_ids:
            raise invalid("action_ids 배열이 필요합니다")
        with self._lock(s):
            self._snapshot(s, snapshot_id)
            prep = self._prepare(s, snapshot_id)
            estimates = [self._estimate(prep, None if a in (None, "NO_ACTION") else a) for a in action_ids]
            ticks = int(self.physics["rollout_ticks"])
            self._log(s, actor="simulator", type="futures_simulated", ref_id=snapshot_id,
                      is_assumption=(snapshot_id != self.base_id) or None,
                      summary=f"병렬 미래 {len(action_ids)}안 시뮬레이션 ({ticks}틱)",
                      data={"action_ids": action_ids, "requested_horizon_ticks": body.get("horizon_ticks"), "horizon_ticks": ticks})
            return {"estimates": estimates}

    # ================================================================ 안전 검사·승인
    def validate(self, s: str, body: dict) -> dict:
        body = body or {}
        origin = body.get("origin", "model")
        if origin not in ("model", "operator_forced"):
            raise invalid("origin 은 model 또는 operator_forced 여야 합니다")
        with self._lock(s):
            self._check_decision_id(s, body.get("decision_id", ""))
            snap = self._live(s)
            cands = self._candidates(s)
            action = cand_mod.find(cands, body.get("action_id", ""))
            if action is None:
                raise invalid(f"알 수 없는 행동 {body.get('action_id')}")
            gate = safety_gate.check_action(action, snap, self.policy, self._physics(s))
            verdict = gate["verdict"]
            at = self._now(s, 2)
            vid = f"VAL-{self.tag}-{self._next(s, 'validation'):02d}"
            forced = origin == "operator_forced"
            validation = {
                "validation_id": vid, "decision_id": body["decision_id"], "action_id": action["id"],
                "origin": origin, "snapshot_id": self.base_id, "policy_version": self.policy["version"],
                "checks": gate["checks"], "verdict": verdict, "approval_id": None,
                "log": [f"{at} validate {action['label']}" + (" (operator_forced)" if forced else "")]
                       + [f"{at} {c['policy_id']} {c['name']} {c['observed']} {c['result'].upper()}" for c in gate["checks"]]
                       + [f"{at} result {VERDICT_LOG[verdict]}"],
                "state_version": config.snapshot_version(snap), "hard_violations": gate["hard_violations"],
            }
            if verdict == "blocked":
                self._log(s, at=at, actor="system", type="blocked", ref_id=vid,
                          summary=f"{'테스트 ' if forced else ''}차단 · {action['label']} · {', '.join(gate['hard_violations'])}",
                          data={"origin": origin, "checks": [c for c in gate["checks"] if c["result"] == "fail"]})
            else:
                self._log(s, at=at, actor="system", type="validated", ref_id=vid,
                          summary=f"안전 검사 {'조건부 허용' if verdict == 'conditional' else '허용'} · {action['label']}",
                          data={"origin": origin})
            if verdict == "conditional":
                role = safety_gate.required_role(action, self.policy)
                existing = next((a for a in self.store.list(s, "approval")
                                 if a["action_id"] == action["id"] and a["status"] == "pending"
                                 and a.get("state_version") == validation["state_version"]), None)
                if existing:
                    validation["approval_id"] = existing["approval_id"]
                else:
                    aid = f"APR-{self.tag}-{self._next(s, 'approval'):02d}"
                    t = self._now(s, 1)
                    others = [r["id"] for r in self.roles if r["can_approve"] and r["id"] != role]
                    valid_min = float(self.decision_cfg["approval_valid_min"])
                    self.store.put(s, "approval", aid, {
                        "approval_id": aid, "decision_id": body["decision_id"], "action_id": action["id"],
                        "required_role": role, "notified_roles": [role] + others, "status": "pending",
                        "comments": [], "decided_by": None, "decided_at": None,
                        "expires_at": to_time(to_sec(t) + valid_min * 60),
                        "state_version": validation["state_version"], "policy_version": self.policy["version"],
                        "validation_id": vid,
                    })
                    validation["approval_id"] = aid
                    self._log(s, at=t, actor="system", type="approval_requested", ref_id=aid,
                              summary=f"승인 요청 {aid} 생성 · 필요 역할 {role}")
            self.store.put(s, "validation", vid, validation)
            return validation

    def _approval(self, s: str, approval_id: str) -> dict:
        self._ensure(s)
        approval = self.store.get(s, "approval", approval_id)
        if approval is None:
            raise not_found(f"승인 요청 {approval_id}가 없습니다.")
        return approval

    def get_approval(self, s: str, approval_id: str) -> dict:
        return self._approval(s, approval_id)

    def list_approvals(self, s: str) -> list[dict]:
        self._ensure(s)
        return self.store.list(s, "approval")

    def comment_approval(self, s: str, approval_id: str, body: dict, role: str | None) -> dict:
        text = str((body or {}).get("text", "")).strip()
        if not text:
            raise invalid("의견 내용(text)이 필요합니다")
        role = self._role(role)
        with self._lock(s):
            approval = self._approval(s, approval_id)
            at = self._now(s, 3)
            approval["comments"].append({"role": role, "text": text[:500], "at": at})
            self.store.put(s, "approval", approval_id, approval)
            self._log(s, at=at, actor=role, type="comment", ref_id=approval_id, summary=f"의견 등록: {text[:200]}")
            return approval

    def decide_approval(self, s: str, approval_id: str, body: dict, role: str | None) -> dict:
        body = body or {}
        act = body.get("action")
        key = body.get("idempotency_key")
        if act not in APPROVAL_ACTIONS:
            raise invalid(f"action 은 {list(APPROVAL_ACTIONS)} 중 하나여야 합니다")
        if not key:
            raise invalid("idempotency_key 가 필요합니다")
        role = self._role(role)
        with self._lock(s):
            approval = self._approval(s, approval_id)
            action = cand_mod.find(self._candidates(s), approval["action_id"])
            if action is None:
                raise invalid(f"알 수 없는 행동 {approval['action_id']}")
            auth = safety_gate.check_approval(action, role, self.policy, self.roles)
            if not auth["ok"]:
                # 권한 없는 승인 시도는 서버에서 거부하고 기록한다 (UI 비활성과 무관).
                self._log(s, actor=role, type="blocked", ref_id=approval_id,
                          summary=f"권한 없는 승인 시도 거부 · {auth['policy_id'] or '권한'}",
                          data={"attempted": act, "required_role": auth["required_role"]})
                raise ApiError(403, "ROLE_FORBIDDEN", auth["message"], policy_id=auth["policy_id"])
            if approval["status"] != "pending":
                if self.store.get(s, "approval_key", approval_id) == key:
                    return approval  # 같은 요청의 재전송
                raise ApiError(409, "ALREADY_EXECUTED", "이미 결정된 승인 요청입니다.")
            now = self._ensure(s)["clock_s"]
            if now > to_sec(approval["expires_at"]):
                approval["status"] = "expired"
                self.store.put(s, "approval", approval_id, approval)
                raise ApiError(409, "APPROVAL_EXPIRED", "승인 유효기한이 지났습니다. 안전 검사를 다시 실행하세요.")
            approval["status"] = APPROVAL_ACTIONS[act]
            approval["decided_by"] = role
            approval["decided_at"] = self._now(s, 3)
            note = str(body.get("note") or "").strip()
            if note:
                approval["comments"].append({"role": role, "text": note[:500], "at": approval["decided_at"]})
            self.store.put(s, "approval", approval_id, approval)
            self.store.put(s, "approval_key", approval_id, key)
            self._log(s, at=approval["decided_at"], actor=role, type=APPROVAL_ACTIONS[act], ref_id=approval_id,
                      summary=APPROVAL_LABEL[act] + (f" · {note[:200]}" if note else ""))
            return approval

    # ================================================================ 실행
    def execute(self, s: str, body: dict) -> dict:
        body = body or {}
        key = body.get("idempotency_key")
        if not key:
            raise invalid("idempotency_key 가 필요합니다")
        with self._lock(s):
            self._ensure(s)
            prior = self.store.get(s, "execution", key)
            if prior:
                return prior  # 같은 요청은 한 번만 적용
            cands = self._candidates(s)
            approval = None
            if "approval_id" in body:
                approval = self._approval(s, body["approval_id"])
                action = cand_mod.find(cands, approval["action_id"])
                if action is None:
                    raise invalid(f"알 수 없는 행동 {approval['action_id']}")
                if approval["status"] != "approved":
                    raise ApiError(403, "ROLE_FORBIDDEN", "권한자 승인 전에는 실행할 수 없습니다.",
                                   policy_id=cand_mod.APPROVAL_POLICY.get(action["type"]))
            else:
                self._check_decision_id(s, body.get("decision_id", ""))
                action = cand_mod.find(cands, body.get("action_id", ""))
                if action is None:
                    raise invalid(f"알 수 없는 행동 {body.get('action_id')}")
                if safety_gate.required_role(action, self.policy):
                    raise ApiError(403, "ROLE_FORBIDDEN", "승인이 필요한 행동입니다.",
                                   policy_id=cand_mod.APPROVAL_POLICY.get(action["type"]))
            if any(e["status"] == "succeeded" for e in self.store.list(s, "execution")):
                raise ApiError(409, "ALREADY_EXECUTED", "이 결정은 이미 실행되었습니다.")
            execution = self._do_execute(s, action, approval, key)
            self.store.put(s, "execution", key, execution)
            return execution

    def _do_execute(self, s: str, action: dict, approval: dict | None, key: str) -> dict:
        physics = self._physics(s)
        before = config.deep(self._live(s))
        ver = self.policy["version"]
        t0 = self._now(s, 1)
        state_now = config.snapshot_version(before)
        physical = action["type"] in cand_mod.EXECUTABLE_TYPES

        # ---- 실행 직전 재검증: 상태·정책 버전, Safety Gate, 권한, 유효기한
        recheck: list[dict] = []
        expected_state = approval.get("state_version") if approval else state_now
        recheck.append({"policy_id": "-", "name": "상태", "criterion": "검사 시점과 같은 상태",
                        "observed": "변화 없음" if expected_state == state_now else f"변경됨 ({expected_state} → {state_now})",
                        "result": "pass" if expected_state == state_now else "fail"})
        expected_policy = approval.get("policy_version") if approval else ver
        recheck.append({"policy_id": f"v{ver}", "name": "정책", "criterion": "버전 동일",
                        "observed": f"v{ver} 그대로" if expected_policy == ver else f"v{expected_policy} → v{ver}",
                        "result": "pass" if expected_policy == ver else "fail"})
        gate = safety_gate.check_action(action, before, self.policy, physics, include_approval=False)
        recheck.extend(gate["checks"])
        if approval:
            auth = safety_gate.check_approval(action, approval.get("decided_by"), self.policy, self.roles)
            recheck.append({"policy_id": auth["policy_id"] or "-", "name": "권한", "criterion": "승인자 역할 일치",
                            "observed": f"{approval.get('decided_by')} 승인", "result": "pass" if auth["ok"] else "fail"})
            fresh = self._ensure(s)["clock_s"] <= to_sec(approval["expires_at"])
            recheck.append({"policy_id": "-", "name": "유효기한", "criterion": f"{approval['expires_at']} 이전",
                            "observed": t0, "result": "pass" if fresh else "fail"})
        failed = [c for c in recheck if c["result"] == "fail"]

        primary_id = (self.incident.get("job_ids") or [None])[0]
        after_s = float(physics["after_snapshot_s"])
        ref_id = approval["approval_id"] if approval else action["id"]
        eid = f"EXE-{self.tag}-{self._next(s, 'execution'):02d}"
        no_action = simulate(before, physics, self.policy, None)

        def sla_of(sim: dict) -> dict:
            job = sim["jobs"].get(primary_id) if primary_id else None
            src = job_map(before).get(primary_id) if primary_id else None
            if not job or job["finish_s"] is None:
                return {"job_id": primary_id or "-", "finish_at": "-", "deadline_at": (src or {}).get("deadline_at") or "-",
                        "slack_min": 0.0, "met": False}
            finish_at = to_time(to_sec(before["sim_time"]) + job["finish_s"])
            deadline_at = (src or {}).get("deadline_at") or "-"
            return {"job_id": primary_id, "finish_at": finish_at, "deadline_at": deadline_at,
                    "slack_min": round(job["slack_s"] / 60.0, 1) if job["slack_s"] is not None else 0.0,
                    "met": bool(job["deadline_met"])}

        base = {"execution_id": eid, "approval_id": approval["approval_id"] if approval else None,
                "action_id": action["id"], "recheck": recheck, "source": "sim_executed", "idempotency_key": key}

        if failed:
            names = ", ".join(f"{c['name']}({c['policy_id']})" for c in failed)
            self._log(s, at=t0, actor="system", type="rechecked", ref_id=ref_id, summary=f"실행 직전 재검사 실패 · {names}",
                      data={"failed": failed})
            self._log(s, actor="system", type="execution_failed", ref_id=eid,
                      summary=f"실행 보류 · {action['label']} · 재검사 실패로 적용하지 않음")
            return {**base, "status": "held",
                    "steps": ([{"label": "승인", "at": approval.get("decided_at") or t0, "ok": True}] if approval else [])
                             + [{"label": f"실행 직전 재검사 실패: {names}", "at": t0, "ok": False},
                                {"label": "적용하지 않음 · 안전 검사를 다시 실행하세요", "at": t0, "ok": False}],
                    "before": before, "after": before, "sla": sla_of(no_action),
                    "estimate": to_estimate(no_action, no_action, physics, self.incident["job_ids"])}

        self._log(s, at=t0, actor="system", type="rechecked", ref_id=ref_id, summary="실행 직전 재검사 통과")

        if not physical:
            # 정보 요청·이관: 상태를 바꾸지 않는다. 사람의 판단을 기다리는 보류 상태로 기록한다.
            self._log(s, actor="simulator", type="executed", ref_id=eid,
                      summary=f"{action['label']} · 보류(상태 변화 없음) · 시뮬레이션")
            return {**base, "status": "held",
                    "steps": [{"label": "실행 직전 재검사 통과", "at": t0, "ok": True},
                              {"label": f"{action['label']} 접수 · 상태 변화 없음", "at": t0, "ok": True}],
                    "before": before, "after": before, "sla": sla_of(no_action),
                    "estimate": to_estimate(no_action, no_action, physics, self.incident["job_ids"])}

        sim = simulate(before, physics, self.policy, action, capture_s=after_s)
        after = self._after_snapshot(before, sim)
        self.store.put(s, "snapshot", after["snapshot_id"], after)
        sla = sla_of(sim)
        # 단계 시각은 시나리오 시간축이다: 스냅샷 시각 + 승인 대기(approval_wait_s) 시점에 적용된다.
        # (영수증 이벤트의 at 은 기록 순서를 위한 별도 시계다.)
        applied = to_time(to_sec(before["sim_time"]) + (sim["applied_at_s"] or 0.0))
        steps = [{"label": "승인", "at": applied, "ok": True}] if approval else []
        steps.append({"label": "실행 직전 재검사 통과", "at": applied, "ok": True})
        if action["type"] == "job_migrate":
            job = job_map(before)[action["params"]["job"]]
            restart = float(job.get("restart_cost_min") or 0.0)
            steps.append({"label": "체크포인트 저장 · 가상 환경에 적용", "at": applied, "ok": True})
            steps.append({"label": f"{action['params']['to']}에서 재시작 완료", "ok": True,
                          "at": to_time(to_sec(applied) + restart * 60)})
        else:
            steps.append({"label": "가상 환경에 적용", "at": applied, "ok": True})
        if sla["finish_at"] != "-":
            projected = sim["jobs"][primary_id]["finish_projected"]
            steps.append({"label": f"{primary_id} 완료 (예상{' · 추정' if projected else ''})", "at": sla["finish_at"], "ok": sla["met"]})

        self._log(s, actor="simulator", type="executed", ref_id=eid, summary=f"{action['label']} · 성공 · 시뮬레이션",
                  data={"peak_temp_c": round(sim["peak_temp_c"], 1), "cooling_kwh": round(sim["cooling_kwh"], 3)})
        if sla["finish_at"] != "-":
            tail = f"마감 준수 · 여유 {sla['slack_min']}분" if sla["met"] else "마감 미준수"
            self._log(s, at=sla["finish_at"], actor="simulator", type="executed", ref_id=eid,
                      summary=f"{primary_id} 완료 (예측) · {tail}")
        return {**base, "status": "succeeded", "steps": steps, "before": before, "after": after, "sla": sla,
                "estimate": to_estimate(sim, no_action, physics, self.incident["job_ids"])}

    def _after_snapshot(self, before: dict, sim: dict) -> dict:
        cap = sim["captured"]
        t = cap["t_s"]
        after = config.deep(before)
        after["snapshot_id"] = f"{before['snapshot_id']}-exec"
        after["parent_id"] = before["snapshot_id"]
        after["sim_time"] = to_time(to_sec(before["sim_time"]) + t)
        after["source"] = "sim_executed"
        gpus = {j["id"]: j["gpus"] for j in before["jobs"]}
        for n in after["nodes"]:
            st = cap["nodes"][n["id"]]
            left = [j for j in n["job_ids"] if j not in st["job_ids"]]
            came = [j for j in st["job_ids"] if j not in n["job_ids"]]
            n["gpus_free"] = max(0, min(n["gpus_total"], n["gpus_free"] + sum(gpus[j] for j in left) - sum(gpus[j] for j in came)))
            n["temp_c"] = round(st["temp_c"], 1)
            n["power_kw"] = round(st["power_kw"], 1)
            n["gpu_util_pct"] = int(round(st["gpu_util_pct"]))
            n["job_ids"] = st["job_ids"]
            flags = [f for f in n["flags"] if f != "rising"]
            if st["rising"]:
                flags.append("rising")
            n["flags"] = flags
        for j in after["jobs"]:
            st = cap["jobs"][j["id"]]
            j["node_id"] = st["node"]
            j["remaining_min"] = round(st["remaining_s"] / 60.0, 1)
            j["status"] = st["status"]
            if j.get("deadline_min") is not None:
                j["deadline_min"] = round(j["deadline_min"] - t / 60.0, 1)
        for z in after["zones"]:
            z["cooling_level"] = cap["levels"][z["id"]]
            z["power_kw"] = round(sum(n["power_kw"] for n in after["nodes"] if n["zone_id"] == z["id"]), 1)
        steps = int(t // sim["dt_s"])
        for h in after.get("history", []):
            vals = sim["series"].get(h["node_id"], [])
            for i in range(1, min(steps, len(vals) - 1) + 1):
                h["points"].append({"t": to_time(to_sec(before["sim_time"]) + i * sim["dt_s"]), "temp_c": round(vals[i], 1)})
        return after

    # ================================================================ 영수증·분석
    def _receipt(self, s: str) -> dict:
        meta = self._ensure(s)
        decisions = self.store.list(s, "decision")
        base = self.store.get(s, "decision", self.base_id)
        executions = self.store.list(s, "execution")
        done = next((e for e in executions if e["status"] == "succeeded"), None)
        latest = done or (executions[-1] if executions else None)
        validations = self.store.list(s, "validation")
        cands = config.deep(self.store.get(s, "candidates", self.base_id) or self._candidates(s))
        forced = {v["action_id"] for v in validations if v["origin"] == "operator_forced"}
        for c in cands:
            if c["id"] in forced:
                c["origin"] = "operator_forced"
        contract_mode = {"zoro1": "zoro1", "zoro1_local": "zoro1", "mock": "mock", "rule": "rule"}[self.provider_mode]
        return {
            "decision_id": meta["decision_id"], "incident_id": self.incident["id"],
            "policy_version": self.policy["version"], "snapshot_id": self.base_id,
            "provider": base["provider"] if base else contract_mode,
            "status": "executed" if done else ("held" if latest else "open"),
            "branches": [{
                "branch_id": d["branch_id"],
                "changes": (self.store.get(s, "experiment", d["branch_id"]) or {}).get("changes", {}),
                "selected_id": d["selected_id"], "provider": d["provider"],
                "executed": d["branch_id"] == self.base_id and done is not None,
                "proposed_id": d.get("proposed_id"), "decision_mode": d.get("decision_mode"),
                "modified_after_block": d.get("modified_after_block", False),
            } for d in decisions],
            "candidates": cands, "validations": validations, "approvals": self.store.list(s, "approval"),
            "execution": latest, "events": self.store.events(s),
            "meta": (base or {}).get("meta"),
            "scenario": meta.get("scenario") or {},
        }

    def get_receipt(self, s: str, decision_id: str) -> dict:
        self._check_decision_id(s, decision_id)
        return self._receipt(s)

    def list_receipts(self, s: str) -> list[dict]:
        self._ensure(s)
        v1 = [self._receipt(s)] if self.store.list(s, "decision") else []
        return self.multi.receipt_rows(s) + v1          # 다중 작업 버전의 회차별 결정이 위에 온다

    def get_log(self, s: str, decision_id: str) -> dict:
        """제출용 실행 로그: 판단 실행마다의 단계별 trace 와 영수증 이벤트."""
        self._check_decision_id(s, decision_id)
        return {"decision_id": decision_id, "incident_id": self.incident["id"],
                "provider_backend": self.provider_mode,
                "runs": self.store.list(s, "run"), "events": self.store.events(s)}

    def analytics(self, s: str, filters: dict | None = None) -> dict:
        """기존 단일 사건 기록과 다중 작업(/api/v2) 기록을 합쳐 집계한다. 모두 실제 기록이고, 이 접속자(s)의 것만 센다."""
        out = self._analytics_v1(s, filters)
        m = self.multi.analytics(filters, s)
        n1, n2 = out["total_decisions"], m["total_decisions"]
        handed1 = round(out["escalation_rate_pct"] * n1 / 100.0) if n1 else 0
        out["total_decisions"] = n1 + n2
        out["blocked_attempts"] += m["blocked_attempts"]
        out["escalation_rate_pct"] = round((handed1 + m["handed"]) / (n1 + n2) * 100.0, 1) if n1 + n2 else 0.0
        for key in ("deadline_met", "consistency", "results", "providers"):
            for k, v in m[key].items():
                out[key][k] = out[key].get(k, 0) + v
        out["by_type"] = [t for t in out["by_type"] if t["decisions"]] + m["by_type"]
        out["patterns"] = out["patterns"] + m["patterns"]
        return out

    def _analytics_v1(self, s: str, filters: dict | None = None) -> dict:
        """이 접속자(s)의 실제 기록만 집계한다(예시 값 아님). filters = 화면의 scenario·policy·period·result."""
        filters = filters or {}
        meta = self._ensure(s)
        own = lambda rows: [(x, o) for x, o in rows if x == s]      # 다른 탭·다른 접속자의 기록은 섞지 않는다
        runs = own(self.store.list_all("run"))
        validations = own(self.store.list_all("validation"))
        approvals = own(self.store.list_all("approval"))
        executions = own(self.store.list_all("execution"))
        decisions = own(self.store.list_all("decision"))
        events = own(self.store.all_events())
        blocked = sum(1 for _, e in events if e["type"] == "blocked")
        escalated = sum(1 for _, a in approvals if a["status"] == "escalated")
        succeeded = [e for _, e in executions if e["status"] == "succeeded"]
        first: dict[tuple[str, str], str] = {}
        same = total = 0
        for session, r in runs:
            k = (session, r["input_hash"])
            if k in first:
                total += 1
                same += int(first[k] == r["selected_id"])
            else:
                first[k] = r["selected_id"]

        status_filter = {"성공": "executed", "보류": "held", "실패": "failed"}.get(filters.get("result", ""))
        recent = []
        for session in [s]:
            base = self.store.get(session, "decision", self.base_id)
            if not base:
                continue
            ex = next((e for e in self.store.list(session, "execution") if e["status"] == "succeeded"), None)
            held = next((e for e in self.store.list(session, "execution") if e["status"] != "succeeded"), None)
            cands = self.store.get(session, "candidates", self.base_id) or []
            status = "executed" if ex else ("held" if held else "open")
            if status_filter and status != status_filter:
                continue
            recent.append({
                "decision_id": base["decision_id"], "incident_id": base["incident_id"],
                "action_label": self._label(cands, (ex or {}).get("action_id") or base["selected_id"]),
                "status": status, "deadline_met": ex["sla"]["met"] if ex else None,
                "session": session, "provider": base["provider"],
            })
            if len(recent) >= 10:
                break

        itype = self.incident.get("type", "열 위험")
        scenario = filters.get("scenario")
        by_type = []
        if not scenario or scenario in ("전체", itype):
            by_type.append({"type": itype, "decisions": len(runs),
                            "missed": sum(1 for e in succeeded if not e["sla"]["met"])})

        def pattern(name: str, count: int, action: str) -> dict | None:
            return {"pattern": name, "count": count, "decision_id": meta["decision_id"], "action": action} if count else None

        patterns = [p for p in (
            pattern("여유 없는 노드로 강제 이동 시도",
                    sum(1 for _, v in validations if v["origin"] == "operator_forced" and "POL-03" in v.get("hard_violations", [])),
                    "입력 단계 경고 추가 · 모두 Safety Gate에서 차단됨"),
            pattern("권한 없는 승인 시도",
                    sum(1 for _, e in events if e["type"] == "blocked" and e["actor"] not in ("system", "model", "simulator")),
                    "역할별 승인 권한 안내 보강 · 모두 서버에서 거부됨"),
            pattern("모델 호출 실패 후 규칙 폴백", sum(1 for _, e in events if e["type"] == "model_error"),
                    "모델 서버 상태 점검 · 규칙 폴백으로 흐름은 유지됨"),
            pattern("모델 제안이 필수 규칙 위반", sum(1 for _, d in decisions if d.get("modified_after_block")),
                    "후보 설명 보강 검토 · 사전 검사에서 차단 후 수정됨"),
            pattern("실행 직전 재검사 실패", sum(1 for _, e in events if e["type"] == "execution_failed"),
                    "승인 후 상태 변화 알림 추가 · 적용하지 않고 보류됨"),
        ) if p]

        return {
            "is_example": False,
            "total_decisions": len(runs),
            "blocked_attempts": blocked,
            "escalation_rate_pct": round(escalated / len(approvals) * 100.0, 1) if approvals else 0.0,
            "deadline_met": {"met": sum(1 for e in succeeded if e["sla"]["met"]), "total": len(succeeded)},
            "consistency": {"same": same, "total": total},
            "results": {"succeeded": len(succeeded),
                        "held": sum(1 for _, e in executions if e["status"] == "held"),
                        "failed": sum(1 for _, e in executions if e["status"] == "failed")},
            "recent": recent,
            "by_type": by_type,
            "patterns": patterns,
            "validations": {"total": len(validations),
                            "blocked": sum(1 for _, v in validations if v["verdict"] == "blocked")},
            "providers": {p: sum(1 for _, r in runs if r["provider"] == p) for p in ("zoro1", "rule", "mock")},
            "filters": filters,
        }

"""경로 → 서비스 메서드 연결. HTTP 프레임워크와 무관한 한 곳(dispatch)에서 처리한다.

    dispatch(service, method, path, query, body, headers) → (status, json)

오류는 모두 계약의 ApiError 형식으로 바꾼다. 예상하지 못한 예외도 500 INTERNAL 로 감싸 서버가 죽지 않게 한다.
"""
from __future__ import annotations

import logging
import re
from typing import Any, Callable

from .config import ConfigError
from .errors import ApiError
from .service import NexteraService

log = logging.getLogger("nextera.api")

_SESSION_RE = re.compile(r"[^A-Za-z0-9_.-]")


def session_of(headers: dict[str, str]) -> str:
    raw = headers.get("x-session") or "default"
    return _SESSION_RE.sub("", raw)[:64] or "default"


Handler = Callable[[NexteraService, dict], Any]
# ctx = {"s": 세션, "role": 역할, "q": 쿼리, "body": 본문, "p": 경로 변수}
ROUTES: list[tuple[str, str, Handler]] = [
    ("GET", r"/api/health", lambda sv, c: sv.health(c["s"])),
    ("POST", r"/api/demo/reset", lambda sv, c: sv.reset(c["s"], c["body"])),
    ("POST", r"/api/demo/fault", lambda sv, c: sv.set_fault(c["s"], c["body"])),
    ("POST", r"/api/demo/drift", lambda sv, c: sv.drift(c["s"], c["body"])),
    ("GET", r"/api/state", lambda sv, c: sv.get_state(c["s"], c["q"].get("snapshot"))),
    ("GET", r"/api/incidents/(?P<id>[^/]+)", lambda sv, c: sv.get_incident(c["s"], c["p"]["id"])),
    ("GET", r"/api/policies", lambda sv, c: sv.get_policies(c["s"], c["q"].get("version"))),
    ("POST", r"/api/decide", lambda sv, c: sv.decide(c["s"], c["body"])),
    ("GET", r"/api/decisions/(?P<id>[^/]+)", lambda sv, c: sv.get_decision(c["s"], c["p"]["id"], c["q"].get("branch"))),
    ("POST", r"/api/experiments", lambda sv, c: sv.create_experiment(c["s"], c["body"], c["role"])),
    ("GET", r"/api/experiments/(?P<id>[^/]+)/compare", lambda sv, c: sv.compare(c["s"], c["p"]["id"])),
    ("POST", r"/api/futures", lambda sv, c: sv.futures(c["s"], c["body"])),
    ("POST", r"/api/validate", lambda sv, c: sv.validate(c["s"], c["body"])),
    ("GET", r"/api/approvals", lambda sv, c: sv.list_approvals(c["s"])),
    ("GET", r"/api/approvals/(?P<id>[^/]+)", lambda sv, c: sv.get_approval(c["s"], c["p"]["id"])),
    ("POST", r"/api/approvals/(?P<id>[^/]+)/comments", lambda sv, c: sv.comment_approval(c["s"], c["p"]["id"], c["body"], c["role"])),
    ("POST", r"/api/approvals/(?P<id>[^/]+)/decision", lambda sv, c: sv.decide_approval(c["s"], c["p"]["id"], c["body"], c["role"])),
    ("POST", r"/api/execute", lambda sv, c: sv.execute(c["s"], c["body"])),
    ("GET", r"/api/receipts", lambda sv, c: sv.list_receipts(c["s"])),
    ("GET", r"/api/receipts/(?P<id>[^/]+)/log", lambda sv, c: sv.get_log(c["s"], c["p"]["id"])),
    ("GET", r"/api/receipts/(?P<id>[^/]+)", lambda sv, c: sv.get_receipt(c["s"], c["p"]["id"])),
    ("GET", r"/api/analytics", lambda sv, c: sv.analytics(c["s"], c["q"])),
    # ---- 다중 작업 버전 (노드 1~6, 일 1~10, 계획 후보, 회차 반복)
    ("POST", r"/api/v2/scenario", lambda sv, c: sv.multi.set_scenario(c["s"], c["body"])),
    ("GET", r"/api/v2/state", lambda sv, c: sv.multi.overview(c["s"])),
    ("POST", r"/api/v2/decide", lambda sv, c: sv.multi.decide(c["s"], c["body"])),
    ("POST", r"/api/v2/validate", lambda sv, c: sv.multi.validate(c["s"], c["body"])),
    ("POST", r"/api/v2/approvals", lambda sv, c: sv.multi.approve(c["s"], c["body"], c["role"])),
    ("POST", r"/api/v2/execute", lambda sv, c: sv.multi.execute(c["s"], c["body"])),
    ("GET", r"/api/v2/receipt", lambda sv, c: sv.multi.receipt(c["s"])),
    ("GET", r"/api/v2/log", lambda sv, c: sv.multi.run_log(c["s"])),
]
_COMPILED = [(m, re.compile(f"^{pattern}$"), h) for m, pattern, h in ROUTES]


def dispatch(service: NexteraService, method: str, path: str, query: dict[str, str] | None,
             body: Any, headers: dict[str, str] | None) -> tuple[int, Any]:
    headers = {k.lower(): v for k, v in (headers or {}).items()}
    path = path.rstrip("/") or "/"
    path_known = False
    try:
        for m, regex, handler in _COMPILED:
            match = regex.match(path)
            if not match:
                continue
            path_known = True
            if m != method.upper():
                continue
            if body is not None and not isinstance(body, dict):
                raise ApiError(400, "INVALID_REQUEST", "요청 본문은 JSON 객체여야 합니다")
            ctx = {"s": session_of(headers), "role": headers.get("x-role"), "q": query or {},
                   "body": body or {}, "p": match.groupdict()}
            return 200, handler(service, ctx)
        if path_known:
            raise ApiError(405, "METHOD_NOT_ALLOWED", f"{method} {path} 는 지원하지 않습니다")
        raise ApiError(404, "NOT_FOUND", f"없는 경로입니다: {path}")
    except ApiError as e:
        return e.status, e.body()
    except ConfigError as e:
        return 400, ApiError(400, "INVALID_REQUEST", str(e)).body()
    except Exception as e:  # 예상하지 못한 오류에도 서버는 계속 동작한다
        log.exception("처리 중 오류: %s %s", method, path)
        return 500, ApiError(500, "INTERNAL", f"서버 내부 오류: {type(e).__name__}: {e}").body()

"""API 오류. 응답 본문은 계약의 ApiError 형식: {"error": {"code", "message", "policy_id"?, "detail"?}}"""
from __future__ import annotations

from typing import Any


class ApiError(Exception):
    def __init__(self, status: int, code: str, message: str, policy_id: str | None = None, detail: Any = None):
        super().__init__(message)
        self.status = status
        self.code = code
        self.message = message
        self.policy_id = policy_id
        self.detail = detail

    def body(self) -> dict:
        err: dict[str, Any] = {"code": self.code, "message": self.message}
        if self.policy_id:
            err["policy_id"] = self.policy_id
        if self.detail is not None:
            err["detail"] = self.detail
        return {"error": err}


def not_found(what: str) -> ApiError:
    return ApiError(404, "NOT_FOUND", what)


def invalid(message: str, detail: Any = None) -> ApiError:
    return ApiError(400, "INVALID_REQUEST", message, detail=detail)

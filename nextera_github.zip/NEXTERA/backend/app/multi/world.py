"""상황 설정 입력 → 기준 상태. 값 검증과 구역 배정, 실행·대기 판정."""
from __future__ import annotations

import copy

PRIO = {"P0": 0, "P1": 1, "P2": 2}


class ScenarioError(ValueError):
    pass


def _num(v, name, lo, hi, integer=False):
    if isinstance(v, bool) or not isinstance(v, (int, float)) or not lo <= v <= hi:
        raise ScenarioError(f"{name} 는 {lo}~{hi} 사이의 숫자여야 합니다 (받은 값: {v!r})")
    if integer and int(v) != v:
        raise ScenarioError(f"{name} 는 정수여야 합니다 (받은 값: {v!r})")
    return int(v) if integer else float(v)


def settle(queues: dict, jobs: dict, gpus_total: int) -> None:
    """노드마다 줄 순서대로, GPU 합이 용량을 넘지 않는 만큼 대기 중인 일을 시작시킨다.
    앞의 일이 못 들어가도 뒤의 작은 일이 빈자리에 들어갈 수 있으면 먼저 시작한다. 이미 실행 중인 일은 계속 실행한다."""
    for q in queues.values():
        free = gpus_total
        for jid in q:
            if jobs[jid]["status"] == "running":
                free -= jobs[jid]["gpus"]
        if free <= 0:
            continue
        for jid in q:
            j = jobs[jid]
            if j["status"] == "waiting" and j["gpus"] <= free:
                j["status"] = "running"
                free -= j["gpus"]


def build_state(scenario: dict, cfg: dict) -> dict:
    """scenario = {"nodes":[{"id","temp_c"}], "zones":[{"id","cooling_level","cooling_max"}], "jobs":[...], "objective"}"""
    if not isinstance(scenario, dict):
        raise ScenarioError("scenario 는 객체여야 합니다")
    lim = cfg["limits"]
    nodes_in = scenario.get("nodes")
    if not isinstance(nodes_in, list) or not 1 <= len(nodes_in) <= lim["max_nodes"]:
        raise ScenarioError(f"nodes 는 1~{lim['max_nodes']}개여야 합니다")
    per_zone = lim["nodes_per_zone"]
    nodes, zones = [], {}
    for i, n in enumerate(nodes_in):
        nid = str(n.get("id") or f"N{i + 1}")
        if any(x["id"] == nid for x in nodes):
            raise ScenarioError(f"노드 id 중복: {nid}")
        zid = f"Z{i // per_zone + 1}"       # 노드 2개당 구역 하나. 노드는 구역을 옮길 수 없다.
        nodes.append({"id": nid, "zone": zid, "temp_c": _num(n.get("temp_c"), f"{nid}.temp_c", 15, 110),
                      "gpus_total": lim["gpus_per_node"], "fan": bool(n.get("fan", n.get("fan_issue", False)))})
        zones.setdefault(zid, {"id": zid, "node_ids": [], "cooling_level": 3, "cooling_max": lim["max_cooling_level"]})
        zones[zid]["node_ids"].append(nid)
    for z in scenario.get("zones") or []:
        zid = z.get("id")
        if zid not in zones:
            raise ScenarioError(f"구역 {zid} 는 노드 수에 맞지 않습니다 (가능: {sorted(zones)})")
        cmax = _num(z.get("cooling_max", lim["max_cooling_level"]), f"{zid}.cooling_max", 1, lim["max_cooling_level"], True)
        lvl = _num(z.get("cooling_level", min(3, cmax)), f"{zid}.cooling_level", 1, cmax, True)
        zones[zid].update(cooling_level=lvl, cooling_max=cmax)
    for z in zones.values():
        z["cooling_level"] = min(z["cooling_level"], z["cooling_max"])

    jobs_in = scenario.get("jobs")
    if not isinstance(jobs_in, list) or not 1 <= len(jobs_in) <= lim["max_jobs"]:
        raise ScenarioError(f"jobs 는 1~{lim['max_jobs']}개여야 합니다")
    node_ids = [n["id"] for n in nodes]
    jobs, queues = {}, {nid: [] for nid in node_ids}
    indexed = sorted(enumerate(jobs_in), key=lambda p: (p[1].get("order", p[0]) if isinstance(p[1].get("order", 0), (int, float)) else p[0], p[0]))
    for i, j in indexed:
        jid = str(j.get("id") or f"J{i + 1}")
        if jid in jobs:
            raise ScenarioError(f"일 id 중복: {jid}")
        node = j.get("node")
        if node not in queues:
            raise ScenarioError(f"{jid}.node 는 {node_ids} 중 하나여야 합니다 (받은 값: {node!r})")
        if len(queues[node]) >= lim["max_jobs_per_node"]:
            raise ScenarioError(f"{node} 에는 일을 {lim['max_jobs_per_node']}개까지만 놓을 수 있습니다")
        prio = j.get("priority", "P1")
        if prio not in PRIO:
            raise ScenarioError(f"{jid}.priority 는 P0·P1·P2 중 하나여야 합니다")
        deadline = j.get("deadline_min")
        jobs[jid] = {
            "id": jid, "gpus": _num(j.get("gpus"), f"{jid}.gpus", 1, lim["gpus_per_node"], True), "priority": prio,
            "deadline_min": None if deadline is None else _num(deadline, f"{jid}.deadline_min", 0.5, 600),
            "remaining_min": _num(j.get("remaining_min"), f"{jid}.remaining_min", 0.1, 600),
            "node": node, "status": "waiting", "defer_until_min": None,
        }
        queues[node].append(jid)
    settle(queues, jobs, lim["gpus_per_node"])
    objective = scenario.get("objective", "balanced")
    if objective not in ("balanced", "energy", "performance"):
        raise ScenarioError("objective 는 balanced·energy·performance 중 하나여야 합니다")
    return {"round": 1, "sim_time": scenario.get("sim_time", "14:00:00"), "objective": objective,
            "nodes": nodes, "zones": list(zones.values()), "jobs": list(jobs.values()), "queues": queues,
            "returns": [], "done_jobs": []}


def view(state: dict, cfg: dict) -> dict:
    """화면·모델에 주는 상태: 노드별 실행 중 GPU, 여유 GPU, 일 목록을 계산해 붙인다."""
    out = copy.deepcopy(state)
    jobs = {j["id"]: j for j in out["jobs"]}
    for n in out["nodes"]:
        q = out["queues"].get(n["id"], [])
        used = sum(jobs[j]["gpus"] for j in q if jobs[j]["status"] == "running")
        n.update(gpus_used=used, gpus_free=n["gpus_total"] - used,
                 running=[j for j in q if jobs[j]["status"] == "running"],
                 waiting=[j for j in q if jobs[j]["status"] == "waiting"])
    return out

"""계획 후보 → Zoro-1 요청 → 선택. 모델 실패 시 규칙 순위로 이어 가고, 안전한 계획이 없으면 사람에게 넘긴다."""
from __future__ import annotations

import copy
import random

from ..engine import FALLBACK_CODE
from ..providers import ProviderContext, ProviderError, get_provider
from .world import view

OBJECTIVE_TEXT = {
    "balanced": "resolve every thermal and deadline problem first, then prefer fewer operations, then lower cooling energy",
    "energy": "resolve every thermal and deadline problem first, then minimize cooling energy",
    "performance": "resolve every thermal and deadline problem first, then keep the largest thermal and deadline margins",
}


def _candidate_text(c: dict, cfg: dict, base: dict) -> str:
    labels = cfg["role_labels"]
    steps = "; ".join(f"({s['index']}) {s['label_en']}" for s in c["steps"])
    roles = ", ".join(labels.get(r, r) for r in c["required_roles"])
    pct = 0.0 if not base["cooling_kwh"] else c["cooling_kwh_delta"] / base["cooling_kwh"] * 100.0
    late = "none" if not c["late_jobs"] else ", ".join(f"{x['job']} ({x['priority']}) by {x['lateness_min']:g} min" for x in c["late_jobs"])
    total = len(c["resolved"]) + len(c["remaining"])
    tail = f"resolves {len(c['resolved'])} of {total} problems"
    if c["remaining"]:
        tail += f", leaves {', '.join(c['remaining'])}"
    if c["new_problems"]:
        tail += f", creates {', '.join(c['new_problems'])}"
    return (f"Strategy: {c['strategies_en'][0]}. Steps: {steps}. Needs approval by {roles}. "
            f"Simulated: peak {c['max_peak_c']:.1f}°C on {c['max_peak_node']} (limit {cfg['limits']['limit_c']:g}°C); "
            f"cooling energy {c['cooling_kwh']:.3f} kWh ({pct:+.1f}% vs no action); deadline misses: {late}; {tail}.")


def offered(gen: dict, cfg: dict) -> list[dict]:
    """Zoro-1 에 선택지로 주는 후보(규칙 순위 상위 max_model_candidates 개). 나머지도 검증된 후보로 화면에는 보인다."""
    return gen["candidates"][: max(1, int(cfg["planner"].get("max_model_candidates", len(gen["candidates"]) or 1)))]


def build_request(state: dict, gen: dict, cfg: dict) -> dict:
    v = view(state, cfg)
    base = gen["no_action"]
    objective = state.get("objective", "balanced")
    return {
        "state": {
            "time": state.get("sim_time"), "round": state.get("round", 1), "objective": objective,
            "thermal_limit_c": cfg["limits"]["limit_c"],
            "nodes": [{"id": n["id"], "zone": n["zone"], "temp_c": n["temp_c"], "fan_issue": bool(n.get("fan")), "gpus_total": n["gpus_total"],
                       "gpus_free": n["gpus_free"], "running": n["running"], "waiting": n["waiting"]} for n in v["nodes"]],
            "zones": [{"id": z["id"], "nodes": z["node_ids"], "cooling_level": z["cooling_level"], "cooling_max": z["cooling_max"]} for z in v["zones"]],
            "jobs": [{"id": j["id"], "priority": j["priority"], "gpus": j["gpus"], "node": j["node"], "status": j["status"],
                      "remaining_min": j["remaining_min"], "deadline_min": j["deadline_min"]} for j in v["jobs"]],
            "problems_if_no_action": [
                {"id": p["id"], "severity": p["severity"],
                 "detail": (f"{p['node']} peaks at {p['peak_c']:.1f}°C, over the limit in {p['time_min']:g} min" if p["kind"] == "overheat"
                            else f"{p['job']} ({p['priority']}) misses its {p['time_min']:g}-min deadline by {p['lateness_min']:g} min")}
                for p in gen["problems"]],
            "no_action": {"peak_c": base["max_peak_c"], "peak_node": base["max_peak_node"], "cooling_kwh": base["cooling_kwh"]},
        },
        "questions": {
            "action": {
                "type": "choice",
                "instructions": ("Choose the single best plan for this round. Each plan is a set of operations applied together after approval. "
                                 "Every plan already passed the hard safety rules in simulation. "
                                 f"Objective priority: {OBJECTIVE_TEXT[objective]}."),
                # 모델에는 규칙 순위 상위 몇 개만 준다. 후보가 많으면 순서에 따라 1위가 흔들렸다(Brev 실측).
                "criteria": {c["id"]: _candidate_text(c, cfg, base) for c in offered(gen, cfg)},
            },
            "risk_level": {"type": "score", "instructions": "How severe is the combined thermal and deadline situation if nothing is done?",
                           "criteria": ["low", "elevated", "critical"]},
        },
    }


def _orders(ids: list[str], votes: int) -> list[tuple[str, list[str]]]:
    """후보를 보여 주는 순서들: 원래 순서, 뒤집은 순서, 그다음은 고정된 씨앗으로 섞은 순서(재현 가능)."""
    out = [("original", list(ids))]
    if votes >= 2 and len(ids) > 1:
        out.append(("reversed", list(reversed(ids))))
    k = 1
    while len(out) < votes and len(ids) > 2 and k <= votes * 3:
        order = list(ids)
        random.Random(1000 + k).shuffle(order)
        if all(order != o for _, o in out):
            out.append((f"shuffle-{k}", order))
        k += 1
    return out


def _rule_rationale(c: dict, n: int) -> str:
    late = "마감 위반 없음" if not c["late_jobs"] else "마감 위반 " + ", ".join(f"{x['job']} {x['lateness_min']:g}분" for x in c["late_jobs"])
    return (f"후보 {n}개 중 '{c['label']}' 계획 ({' → '.join(s['label'] for s in c['steps'])}). "
            f"예측 최고 {c['max_peak_c']:.1f}°C({c['max_peak_node']}) · 냉각 {c['cooling_kwh']:.3f} kWh · {late} · "
            f"문제 {len(c['resolved'])}개 해결" + (f", {len(c['remaining'])}개 남음" if c["remaining"] else ""))


def decide(state: dict, gen: dict, cfg: dict, *, provider_mode: str, decision_cfg: dict, fault_mode: str | None = None) -> dict:
    cands = gen["candidates"]
    rnd = state.get("round", 1)
    out = {
        "decision_id": f"MR-{rnd:02d}", "round": rnd, "status": "decided", "provider": "rule", "decision_mode": "rule_baseline",
        "is_real_model": False, "is_fallback": False, "selected_id": None, "proposed_id": None, "probs": None, "ranking": [],
        "confidence": None, "needs_review": False, "rationale": "", "latency_ms": 0.0, "fallback_reason": None, "model_error": None,
        "escalate": [p["id"] for p in gen["escalate"]], "risk_level": None, "votes": None, "agreement": None, "request": None, "stats": gen.get("stats"),
        "candidate_count": len(cands), "model_candidates": [c["id"] for c in offered(gen, cfg)] if cands else [],
    }
    if not gen["problems"]:
        out.update(status="no_problem", rationale="조치 없이 두어도 열 한계와 마감을 모두 지킵니다. 이번 회차에 할 일이 없습니다.")
        return out
    if not cands:
        out.update(status="handoff", decision_mode="rule_handoff", fallback_reason="NO_FEASIBLE_PLAN",
                   escalate=[p["id"] for p in gen["problems"]],
                   rationale="필수 규칙을 지키면서 상황을 개선하는 계획이 없어 운영자에게 넘깁니다. (" + " · ".join(p["text"] for p in gen["problems"]) + ")")
        return out

    by_id = {c["id"]: c for c in cands}
    rule_pick = cands[0]["id"]                       # 후보는 규칙 순위대로 정렬돼 있다
    request = build_request(state, gen, cfg)
    out["request"] = request
    chosen, error = None, None
    if provider_mode in ("zoro1", "zoro1_local"):
        try:
            provider = get_provider(provider_mode, decision_cfg, fault_mode=fault_mode if fault_mode not in (None, "off") else None)
            ctx = ProviderContext(options=[], sims={}, no_action_sim={}, hard={}, snapshot={}, decision_cfg=decision_cfg)
            # 같은 후보를 보여 주는 순서만 바꿔 여러 번 묻고 확률을 평균한다.
            # (Brev 실측: 순서를 뒤집으면 1위가 바뀌었다. 순서 하나에 기대지 않기 위한 장치다.)
            criteria = request["questions"]["action"]["criteria"]
            votes, total, latency, risk = [], {k: 0.0 for k in criteria}, 0.0, None
            for name, order in _orders(list(criteria), int(cfg["decision"].get("order_votes", 1))):
                req = copy.deepcopy(request)
                req["questions"]["action"]["criteria"] = {k: criteria[k] for k in order}
                res = provider.decide(req, ctx, enable_escalation=False)
                ans = res.answers["action"]
                if ans.get("choice") not in criteria:
                    raise ProviderError("invalid_response", f"후보에 없는 선택: {ans.get('choice')!r}", provider.name)
                p = {k: float(v) for k, v in (ans.get("probabilities") or {}).items() if k in criteria}
                if not p:
                    p = {ans["choice"]: 1.0}
                for k, v in p.items():
                    total[k] += v
                latency += res.latency_ms
                risk = risk or res.answers.get("risk_level")
                votes.append({"order": name, "ids": order, "choice": ans["choice"], "prob": round(p.get(ans["choice"], 0.0), 4)})
            probs = {k: round(v / len(votes), 4) for k, v in total.items()}
            ranking = sorted(probs.items(), key=lambda kv: (-kv[1], kv[0]))
            # 가장 많은 순서에서 1위였던 계획을 고른다. 동률이면 평균 확률, 그래도 같으면 규칙 순위.
            wins = {k: sum(1 for v in votes if v["choice"] == k) for k in criteria}
            chosen = min(criteria, key=lambda k: (-wins[k], -probs[k], k))
            agree = wins[chosen]
            out.update(provider="zoro1", decision_mode="direct" if len(votes) == 1 else "direct_order_averaged", is_real_model=True,
                       probs=probs, ranking=[{"id": k, "prob": v} for k, v in ranking[:5]], confidence=ranking[0][1],
                       latency_ms=round(latency, 2), risk_level=risk, votes=votes, agreement=f"{agree}/{len(votes)}")
            out["confidence"] = probs[chosen]
            if len(ranking) > 1:
                out["needs_review"] = (ranking[0][1] - ranking[1][1] < float(cfg["decision"]["review_margin"])) or agree * 2 <= len(votes) \
                    or ranking[0][0] != chosen
        except ProviderError as e:
            error = e
    if chosen is None:
        chosen = rule_pick
        if provider_mode == "mock":
            out.update(provider="mock", decision_mode="mock")
        elif error is not None:
            out.update(is_fallback=True, decision_mode="rule_fallback", fallback_reason=FALLBACK_CODE.get(error.kind, "ZORO1_ERROR"),
                       model_error=error.to_dict())
        else:
            out["fallback_reason"] = "RULE_MODE"
    c = by_id[chosen]
    out.update(selected_id=chosen, proposed_id=chosen)
    if out["is_real_model"]:
        p = (out["probs"] or {}).get(chosen)
        n_votes = len(out.get("votes") or [])
        how = "" if p is None else (f" (확률 {p:.2f})" if n_votes <= 1 else f" (후보 순서를 바꿔 {n_votes}번 물어 {out['agreement']}번 1위 · 평균 확률 {p:.2f})")
        head = f"Zoro-1 선택{how}: "
        tail = "" if chosen == rule_pick else f" 규칙 순위 1위는 '{by_id[rule_pick]['label']}'({rule_pick})였습니다."
    else:
        head, tail = ("규칙 폴백 선택: " if out["is_fallback"] else "규칙 순위 1위: "), ""
    out["rationale"] = head + _rule_rationale(c, len(cands)) + "." + tail
    if out["escalate"]:
        out["rationale"] += f" 어떤 계획으로도 풀 수 없는 문제({', '.join(out['escalate'])})는 따로 운영자에게 넘깁니다."
    return out

"""다중 작업 버전의 얇은 API 층(/api/v2). 화면 구조가 정해지면 이 파일만 맞추면 된다.

세션마다: 상황 설정 → 회차 1 상태 → [문제 찾기 → 후보 생성 → 판단 → 검사 → 역할별 승인 → 가상 실행 → 다음 회차 상태] 반복.
"""
from __future__ import annotations

import threading
import time
from typing import Any

from ..config import canonical_hash
from ..errors import ApiError, invalid, not_found
from . import load_config
from .decide import decide as run_decide
from .planner import describe_steps, find_problems, generate
from .sim import check_steps, simulate
from .world import ScenarioError, build_state, view

STRIP = ("request",)


class MultiService:
    def __init__(self, store, provider_mode: str, decision_cfg: dict, overrides: dict | None = None):
        self.store, self.provider_mode, self.decision_cfg = store, provider_mode, decision_cfg
        self.cfg = load_config(overrides)
        self._locks: dict[str, threading.RLock] = {}
        self._guard = threading.Lock()

    # ------------------------------------------------------------ 내부
    def _lock(self, s: str) -> threading.RLock:
        with self._guard:
            return self._locks.setdefault(s, threading.RLock())

    def _meta(self, s: str) -> dict:
        meta = self.store.get(s, "m_meta", "meta")
        if meta is None:
            raise ApiError(409, "INVALID_STATE", "상황이 아직 설정되지 않았습니다. 먼저 POST /api/v2/scenario 를 호출하세요.")
        return meta

    def _put_meta(self, s: str, meta: dict) -> None:
        self.store.put(s, "m_meta", "meta", meta)

    def _log(self, s: str, meta: dict, actor: str, type_: str, summary: str, **extra: Any) -> None:
        log = self.store.get(s, "m_log", "log") or {"events": []}
        log["events"].append({"seq": len(log["events"]) + 1, "round": meta["round"], "ts": time.time(), "actor": actor, "type": type_,
                              "summary": summary, **{k: v for k, v in extra.items() if v is not None}})
        self.store.put(s, "m_log", "log", log)

    def _state(self, s: str, rnd: int) -> dict:
        return self.store.get(s, "m_state", str(rnd))

    def _gen(self, s: str, meta: dict) -> dict:
        rnd = meta["round"]
        gen = self.store.get(s, "m_gen", str(rnd))
        if gen is None:
            gen = generate(self._state(s, rnd), self.cfg)
            self.store.put(s, "m_gen", str(rnd), gen)
        return gen

    def _fault(self, s: str) -> str | None:
        return (self.store.get(s, "meta", "meta") or {}).get("fault_mode")

    def _candidate(self, gen: dict, plan_id: str) -> dict:
        c = next((c for c in gen["candidates"] if c["id"] == plan_id), None)
        if c is None:
            raise not_found(f"이번 회차에 계획 {plan_id} 가 없습니다.")
        return c

    @staticmethod
    def _raw_steps(steps: list[dict]) -> list[dict]:
        keep = ("type", "job", "to", "preempt", "minutes", "zone", "level", "return_below_c")
        return [{k: s[k] for k in keep if k in s} for s in steps]

    # ------------------------------------------------------------ 상황·상태
    def set_scenario(self, s: str, body: dict | None) -> dict:
        scenario = (body or {}).get("scenario", body) or {}
        try:
            state = build_state(scenario, self.cfg)
        except ScenarioError as e:
            raise invalid(str(e)) from e
        with self._lock(s):
            meta = {"round": 1, "status": "open", "history": [], "scenario": scenario}
            self._put_meta(s, meta)
            self.store.put(s, "m_log", "log", {"events": []})
            for r in range(1, int(self.cfg["decision"]["max_rounds"]) + 2):      # 이전 시연의 회차 기록을 비운다
                for kind in ("m_gen", "m_decision", "m_approval", "m_exec"):
                    self.store.put(s, kind, str(r), None)
            self.store.put(s, "m_state", "1", state)
            self._log(s, meta, "operator", "scenario_set",
                      f"상황 설정 · 노드 {len(state['nodes'])}개 · 일 {len(state['jobs'])}개 · 구역 {len(state['zones'])}개")
            return self.overview(s)

    def overview(self, s: str) -> dict:
        with self._lock(s):
            meta = self._meta(s)
            state = self._state(s, meta["round"])
            gen = self._gen(s, meta)
            return {"round": meta["round"], "max_rounds": self.cfg["decision"]["max_rounds"], "status": meta["status"],
                    "state": view(state, self.cfg), "problems": gen["problems"], "no_action": gen["no_action"],
                    "history": meta["history"], "limits": self.cfg["limits"], "provider_mode": self.provider_mode}

    # ------------------------------------------------------------ 판단
    def decide(self, s: str, body: dict | None = None) -> dict:
        with self._lock(s):
            meta = self._meta(s)
            rnd = meta["round"]
            if meta["status"] in ("resolved", "handoff", "stalled", "max_rounds"):
                raise ApiError(409, "INVALID_STATE", f"이 시연은 이미 끝났습니다 (상태: {meta['status']}). 상황을 다시 설정하세요.")
            state, gen = self._state(s, rnd), self._gen(s, meta)
            d = run_decide(state, gen, self.cfg, provider_mode=self.provider_mode, decision_cfg=self.decision_cfg, fault_mode=self._fault(s))
            d["state_version"] = canonical_hash(state)
            d["created_at"] = time.time()
            d["problem_ids"] = [p["id"] for p in gen["problems"]]
            d["problem_kinds"] = sorted({p["kind"] for p in gen["problems"]})
            picked = next((c for c in gen["candidates"] if c["id"] == d["selected_id"]), None)
            d["selected_label"] = None if picked is None else f"{picked['label']} · " + " → ".join(st["label"] for st in picked["steps"])
            self.store.put(s, "m_decision", str(rnd), d)
            self.store.put(s, "m_approval", str(rnd), None)
            self._log(s, meta, "system", "candidates_generated",
                      f"문제 {len(gen['problems'])}개 · 검증된 계획 후보 {len(gen['candidates'])}개 (시뮬레이션 {gen['stats']['sims']}회)")
            if d["status"] == "decided":
                self._log(s, meta, d["provider"], "decision_made", f"회차 {rnd} 판단: {d['selected_id']}", provider=d["provider"],
                          data={"probs": d["probs"], "fallback_reason": d["fallback_reason"]})
                if d["escalate"]:
                    self._log(s, meta, "system", "escalated", f"풀 수 없는 문제를 사람에게 넘김: {', '.join(d['escalate'])} (알림 미발송)")
            elif d["status"] == "handoff":
                meta["status"] = "handoff"
                self._put_meta(s, meta)
                self._log(s, meta, "system", "escalated", "안전한 계획이 없어 사람에게 넘김 (알림 미발송)", data={"problems": d["escalate"]})
            else:
                meta["status"] = "resolved"
                self._put_meta(s, meta)
                self._log(s, meta, "system", "resolved", "남은 문제가 없습니다")
            shown = set(d.get("model_candidates") or [])
            return {"decision": {k: v for k, v in d.items() if k not in STRIP},
                    "candidates": [{**c, "offered_to_model": c["id"] in shown} for c in gen["candidates"]],
                    "problems": gen["problems"], "escalate": gen["escalate"], "rejected": gen.get("rejected", []), "request": d["request"] if (body or {}).get("include_request") else None}

    # ------------------------------------------------------------ 검사
    def _checks(self, state: dict, gen: dict, steps: list[dict]) -> tuple[str, list[dict], dict | None]:
        limit = self.cfg["limits"]["limit_c"]
        checks = [{"policy_id": x["policy_id"], "name": "필수 규칙", "result": "fail", "step": x["step"] + 1, "observed": x["message"], "message": x["message"]}
                  for x in check_steps(state, steps, self.cfg)]
        sim = None
        if not checks:
            checks.append({"policy_id": "POL-01·03·09", "name": "용량 · P0 보호 · 중단 조건 · 냉각 상한", "result": "pass", "observed": "위반 없음"})
            sim = simulate(state, steps, self.cfg)
            base = gen["no_action"]
            # 없던 과열을 만들거나 이미 과열될 노드를 더 뜨겁게 하면 차단. 이미 있던 과열을 못 푼 것은 남은 문제로 표시한다.
            already = set(base["thermal_nodes"])
            bad = [n for n in sim["thermal_nodes"] if n not in already or sim["peak_c"][n] > base["peak_c"][n] + 0.05]
            left = [n for n in sim["thermal_nodes"] if n not in bad]
            checks.append({"policy_id": "POL-02", "name": "열 안전 한계", "criterion": f"모든 노드 ≤ {limit:g}°C, 계획이 과열을 만들거나 키우지 않을 것",
                           "observed": f"예측 최고 {sim['max_peak_c']:.1f}°C ({sim['max_peak_node']})"
                           + (f" · 계획 때문에 초과: {', '.join(bad)}" if bad else "")
                           + (f" · 이 계획으로 풀리지 않는 과열: {', '.join(left)} (남은 문제)" if left else ""),
                           "result": "fail" if bad else ("warn" if left else "pass")})
            if sim["late_jobs"]:
                checks.append({"policy_id": "POL-08", "name": "마감", "result": "warn",
                               "observed": "마감 초과 예측: " + ", ".join(sim["late_jobs"])})
            victims = {v for st in steps for v in st.get("preempt", [])}
            newly = [v for v in victims if v in sim["late_jobs"] and v not in {x["job"] for x in base["late_jobs"]}]
            if newly:
                checks.append({"policy_id": "POL-09", "name": "중단된 일의 마감", "result": "fail",
                               "observed": f"중단 때문에 마감을 놓침: {', '.join(newly)}"})
        for c in checks:
            c.setdefault("message", c.get("observed", ""))       # 화면은 message 를 읽는다
        if any(c["result"] == "fail" for c in checks):
            return "blocked", checks, sim
        roles = sorted({self.cfg["approval_roles"][st["type"]] for st in steps})
        checks.append({"policy_id": "POL-04·05·06", "name": "승인", "result": "needs_approval", "observed": "필요 역할: " + ", ".join(roles),
                       "message": "필요 역할: " + ", ".join(roles)})
        return "conditional", checks, sim

    def validate(self, s: str, body: dict | None) -> dict:
        body = body or {}
        with self._lock(s):
            meta = self._meta(s)
            state, gen = self._state(s, meta["round"]), self._gen(s, meta)
            forced = "steps" in body
            if forced:
                if not isinstance(body["steps"], list) or not body["steps"]:
                    raise invalid("steps 는 비어 있지 않은 배열이어야 합니다")
                steps = self._raw_steps(body["steps"])
                label = "운영자 강제 입력"
            else:
                c = self._candidate(gen, body.get("plan_id", ""))
                steps, label = self._raw_steps(c["steps"]), c["id"]
            verdict, checks, sim = self._checks(state, gen, steps)
            self._log(s, meta, "safety_gate", "blocked" if verdict == "blocked" else "validated",
                      f"안전 검사 {label}: {'차단' if verdict == 'blocked' else '통과(승인 필요)'}",
                      data={"origin": "operator_forced" if forced else "model", "steps": steps,
                            "failed": [c["policy_id"] for c in checks if c["result"] == "fail"]})
            return {"plan_id": None if forced else body.get("plan_id"), "origin": "operator_forced" if forced else "model",
                    "verdict": verdict, "checks": checks,
                    "required_roles": sorted({self.cfg["approval_roles"][st["type"]] for st in steps if st.get("type") in self.cfg["approval_roles"]})}

    # ------------------------------------------------------------ 승인
    def approve(self, s: str, body: dict | None, role: str | None) -> dict:
        body = body or {}
        role = role or "operator"
        action = body.get("action", "approve")
        if action not in ("approve", "reject"):
            raise invalid("action 은 approve 또는 reject 여야 합니다")
        with self._lock(s):
            meta = self._meta(s)
            rnd = meta["round"]
            gen = self._gen(s, meta)
            c = self._candidate(gen, body.get("plan_id", ""))
            ap = self.store.get(s, "m_approval", str(rnd))
            if ap is None or ap["plan_id"] != c["id"]:
                ap = {"plan_id": c["id"], "required_roles": c["required_roles"], "approved": {}, "rejected_by": None, "status": "pending"}
            if role not in c["required_roles"]:
                mine = [st["index"] for st in c["steps"]]
                self._log(s, meta, role, "blocked", f"{role} 는 계획 {c['id']} 의 어떤 단계도 승인할 권한이 없음 · 서버 거부")
                self.store.put(s, "m_approval", str(rnd), ap)
                raise ApiError(403, "ROLE_FORBIDDEN", f"{role} 역할은 이 계획(단계 {mine})을 승인할 권한이 없습니다. 필요 역할: {', '.join(c['required_roles'])}")
            if action == "reject":
                ap.update(status="rejected", rejected_by=role)
                self._log(s, meta, role, "rejected", f"{role} 가 계획 {c['id']} 을 반려")
            else:
                ap["approved"][role] = [st["index"] for st in c["steps"] if st["requires_approval_role"] == role]
                ap["status"] = "approved" if set(ap["approved"]) >= set(c["required_roles"]) else "pending"
                self._log(s, meta, role, "approved", f"{role} 가 계획 {c['id']} 의 단계 {ap['approved'][role]} 승인"
                          + ("" if ap["status"] == "approved" else f" · 남은 승인: {', '.join(sorted(set(c['required_roles']) - set(ap['approved'])))}"))
            self.store.put(s, "m_approval", str(rnd), ap)
            return ap

    # ------------------------------------------------------------ 실행 → 다음 회차
    def execute(self, s: str, body: dict | None) -> dict:
        body = body or {}
        with self._lock(s):
            meta = self._meta(s)
            rnd = meta["round"]
            done = self.store.get(s, "m_exec", str(rnd))
            if done is not None:
                return done                                   # 같은 회차를 두 번 실행하지 않는다
            state, gen = self._state(s, rnd), self._gen(s, meta)
            c = self._candidate(gen, body.get("plan_id", ""))
            d = self.store.get(s, "m_decision", str(rnd))
            ap = self.store.get(s, "m_approval", str(rnd))
            if ap is None or ap["plan_id"] != c["id"] or ap["status"] != "approved":
                missing = sorted(set(c["required_roles"]) - set((ap or {}).get("approved", {}))) if ap and ap["plan_id"] == c["id"] else c["required_roles"]
                raise ApiError(409, "APPROVAL_REQUIRED", f"실행하려면 승인이 더 필요합니다: {', '.join(missing)}")
            steps = self._raw_steps(c["steps"])
            recheck = [{"name": "상태", "result": "pass" if not d or d.get("state_version") == canonical_hash(state) else "fail",
                        "observed": "판단 이후 변화 없음" if not d or d.get("state_version") == canonical_hash(state) else "판단 이후 상태가 바뀜"}]
            verdict, checks, _ = self._checks(state, gen, steps)
            recheck.extend(checks)
            if verdict == "blocked" or recheck[0]["result"] == "fail":
                self._log(s, meta, "safety_gate", "blocked", f"실행 직전 재검사 실패 · 계획 {c['id']} 보류")
                why = "; ".join(x.get("observed", "") for x in recheck if x["result"] == "fail")
                raise ApiError(409, "RECHECK_FAILED", f"실행 직전 재검사에서 막혔습니다: {why}", detail={"recheck": recheck})
            self._log(s, meta, "safety_gate", "rechecked", f"실행 직전 재검사 통과 · 계획 {c['id']}")
            after_s = float(self.cfg["physics"]["after_snapshot_s"])
            sim = simulate(state, steps, self.cfg, capture_s=after_s)
            nxt = sim["captured"]
            nxt.pop("elapsed_s", None)
            nxt["round"] = rnd + 1
            before_ids = [p["id"] for p in gen["problems"]]
            left = find_problems(simulate(nxt, [], self.cfg), nxt, self.cfg)
            left_ids = [p["id"] for p in left]
            resolved = [x for x in before_ids if x not in left_ids]
            max_rounds = int(self.cfg["decision"]["max_rounds"])
            if not left_ids:
                status = "resolved"
            elif set(left_ids) == set(before_ids):
                status = "stalled"                             # 진전이 없으면 사람에게 넘긴다
            elif rnd + 1 > max_rounds:
                status = "max_rounds"
            else:
                status = "next_round"
            override = bool(d and d.get("selected_id") and d["selected_id"] != c["id"])
            out = {
                "round": rnd, "plan_id": c["id"], "status": "succeeded", "operator_override": override, "recheck": recheck,
                "deadline_met": not c["late_jobs"], "plan_label": c["label"],
                "steps": c["steps"], "elapsed_min": after_s / 60.0, "escalated": [x for x in (d or {}).get("escalate", []) if x in left_ids],
                "before": view(state, self.cfg), "after": view(nxt, self.cfg),
                "result": {"max_peak_c": sim["max_peak_c"], "max_peak_node": sim["max_peak_node"], "cooling_kwh": sim["cooling_kwh"],
                           "done_jobs": nxt["done_jobs"]},
                "resolved": resolved, "remaining": left, "new_problems": [x for x in left_ids if x not in before_ids],
                "next": {"status": status, "round": rnd + 1 if status == "next_round" else None},
                "note": "가상 실행입니다. 실제 설비는 제어하지 않습니다.",
            }
            self.store.put(s, "m_exec", str(rnd), out)
            self._log(s, meta, "executor", "executed", f"회차 {rnd} 계획 {c['id']} 가상 실행 · 단계 {len(steps)}개"
                      + (" · 운영자가 모델 선택과 다른 계획을 실행" if override else ""))
            meta["history"].append({"round": rnd, "problems": before_ids, "plan_id": c["id"], "resolved": resolved, "remaining": left_ids})
            if status == "next_round":
                meta["round"] = rnd + 1
                self.store.put(s, "m_state", str(rnd + 1), nxt)
                for kind in ("m_gen", "m_decision", "m_approval", "m_exec"):
                    self.store.put(s, kind, str(rnd + 1), None)
                self._put_meta(s, meta)
                self._log(s, meta, "system", "round_started", f"회차 {rnd + 1} 시작 · 남은 문제 {len(left_ids)}개: {', '.join(left_ids)}")
            else:
                meta["status"] = status
                self.store.put(s, "m_state", f"{rnd}-after", nxt)
                self._put_meta(s, meta)
                msg = {"resolved": "모든 문제 해결", "stalled": "진전이 없어 사람에게 넘김 (알림 미발송)", "max_rounds": "최대 회차 도달 · 남은 문제는 사람에게 넘김 (알림 미발송)"}[status]
                self._log(s, meta, "system", "resolved" if status == "resolved" else "escalated", msg, data={"remaining": left_ids})
            return out

    # ------------------------------------------------------------ 영수증
    def receipt(self, s: str) -> dict:
        with self._lock(s):
            meta = self._meta(s)
            rounds = []
            for r in range(1, meta["round"] + 1):
                gen = self.store.get(s, "m_gen", str(r))
                d = self.store.get(s, "m_decision", str(r))
                rounds.append({
                    "round": r, "problems": (gen or {}).get("problems", []),
                    "candidates": [{"id": c["id"], "label": c["label"], "steps": [st["label"] for st in c["steps"]],
                                    "prob": ((d or {}).get("probs") or {}).get(c["id"])} for c in (gen or {}).get("candidates", [])],
                    "decision": None if d is None else {k: v for k, v in d.items() if k not in STRIP},
                    "approval": self.store.get(s, "m_approval", str(r)), "execution": self.store.get(s, "m_exec", str(r)),
                })
            return {"status": meta["status"], "round": meta["round"], "scenario": meta["scenario"], "rounds": rounds,
                    "events": (self.store.get(s, "m_log", "log") or {"events": []})["events"]}

    # ------------------------------------------------------------ 기록·분석 (기존 /api/analytics · /api/receipts 에 합쳐진다)
    @staticmethod
    def _deadline_missed(d: dict, ex: dict | None, nxt: dict | None) -> bool:
        """이 결정에서 마감을 못 지킨 것으로 세는가.

        실행 뒤에도 남아 다음 회차로 넘어간 마감 문제는 그 회차의 결정에서 다시 다루므로,
        그 문제를 마지막으로 다룬 결정에서 한 번만 센다(같은 일을 회차마다 다시 세지 않는다).
        실행하지 못하고 사람에게 넘긴 결정은 그때 걸려 있던 마감 문제를 못 지킨 것으로 센다."""
        if ex is None:
            return d.get("status") == "handoff" and any(x.startswith("LATE-") for x in d.get("problem_ids", []))
        if ex.get("deadline_met", True):
            return False
        left = {p["id"] for p in ex.get("remaining", []) if str(p.get("id", "")).startswith("LATE-")}
        if not left:
            return True
        carried = set(nxt.get("problem_ids", [])) if nxt and nxt.get("status") in ("decided", "handoff") else set()
        return bool(left - carried)

    @staticmethod
    def _missed_late_ids(d: dict, ex: dict | None, nxt: dict | None) -> set[str]:
        """이 결정에서 마감을 못 지킨 것으로 세는 사건(LATE-…)들. 기준은 _deadline_missed 와 같다."""
        if ex is None:
            return {x for x in d.get("problem_ids", []) if x.startswith("LATE-")} if d.get("status") == "handoff" else set()
        if ex.get("deadline_met", True):
            return set()
        left = {p["id"] for p in ex.get("remaining", []) if str(p.get("id", "")).startswith("LATE-")}
        carried = set(nxt.get("problem_ids", [])) if nxt and nxt.get("status") in ("decided", "handoff") else set()
        return left - carried

    def receipt_rows(self, s: str) -> list[dict]:
        """이 세션의 회차별 결정을 기존 영수증 목록 모양으로 돌려준다(분석 화면의 '최근 결정' 표)."""
        meta = self.store.get(s, "m_meta", "meta")
        if meta is None:
            return []
        rows = []
        for r in range(meta["round"], 0, -1):
            d = self.store.get(s, "m_decision", str(r))
            if not d:
                continue
            ex = self.store.get(s, "m_exec", str(r))
            missed = self._deadline_missed(d, ex, self.store.get(s, "m_decision", str(r + 1)))
            sel = d.get("selected_id") or "HANDOFF"
            label = d.get("selected_label") or ("사람에게 넘김" if d["status"] == "handoff" else "조치 불필요")
            rows.append({
                "decision_id": d["decision_id"], "incident_id": ", ".join(d.get("problem_ids", [])) or "—",
                "policy_version": "multi", "snapshot_id": f"R{r}", "provider": d["provider"],
                "status": "executed" if ex else ("held" if d["status"] == "handoff" else "open"),
                "branches": [{"branch_id": "S0", "changes": {}, "selected_id": sel, "provider": d["provider"], "executed": bool(ex)}],
                "candidates": [{"id": sel, "label": label}], "validations": [], "approvals": [], "events": [],
                # 표의 '마감' 칸: 실행한 결정은 준수·미준수, 넘긴 결정은 마감 문제가 걸려 있었으면 미준수
                "execution": ({"status": "succeeded", "sla": {"met": not missed}} if ex
                              else {"status": "held", "sla": {"met": False}} if missed else None),
            })
        return rows

    def analytics(self, filters: dict | None = None, session: str | None = None) -> dict:
        """이 접속자(session)의 현재 시연 기록만 집계한다(실제 기록만). 다른 탭·다른 접속자·이전 접속의 기록은 섞지 않는다.

        숫자의 단위는 결정이 아니라 사건(문제)이다. 한 계획이 사건 3건을 풀면 3건이고, 회차를 넘어 이어진 같은 사건은 한 번만 센다.
          다룬 사건(total_decisions) · 사람 이관률(handed ÷ 다룬 사건) · 마감 준수(마감 위험 사건 중) · 실행 결과(성공 = 해결한 사건, 실패 = 사람에게 넘긴 사건)
        결정 일관성·실패 패턴·차단 건수는 성격상 결정·기록 단위 그대로다. 응답 필드 이름은 화면 계약대로 둔다.
        filters = 화면의 사건 종류(과열 위험·마감 위험)·결과(성공·실패). 기간(period)은 보내면 적용한다."""
        filters = filters or {}

        def own(kind):
            return [(s, x) for s, x in self.store.list_all(kind) if session is None or s == session]

        kind = {"과열 위험": "overheat", "열 위험": "overheat", "마감 위험": "deadline"}.get(filters.get("scenario", ""))
        other_scenario = filters.get("scenario") not in (None, "", "전체") and kind is None
        since = time.time() - {"오늘": 86400.0, "최근 7일": 7 * 86400.0, "최근 30일": 30 * 86400.0}.get(filters.get("period", ""), 1e12)
        result = filters.get("result") if filters.get("result") not in (None, "", "전체") else None
        done = {(s, e["round"]): e for s, e in own("m_exec") if e}
        every = {(s, d["round"]): d for s, d in own("m_decision") if d}

        def in_scope(d):                                   # 사건 종류·기간까지만 본 결정 (결과 필터는 사건에 건다)
            if d["status"] not in ("decided", "handoff") or other_scenario or d.get("created_at", time.time()) < since:
                return False
            return not kind or kind in d.get("problem_kinds", [])

        scope = [(s, d) for (s, _), d in every.items() if in_scope(d)]

        # ---- 사건 단위 집계
        kind_of = lambda pid: "overheat" if pid.startswith("HOT-") else "deadline" if pid.startswith("LATE-") else None
        found: dict[tuple, str] = {}                       # (세션, 사건 id) → 종류
        resolved: set = set()
        handed: set = set()
        missed: set = set()
        for s, d in scope:
            ex, nxt = done.get((s, d["round"])), every.get((s, d["round"] + 1))
            for pid in d.get("problem_ids", []):
                if kind_of(pid):
                    found[(s, pid)] = kind_of(pid)
            if ex:
                resolved |= {(s, x) for x in ex.get("resolved", [])}
                handed |= {(s, x) for x in ex.get("escalated", [])}               # 풀 수 없어 따로 넘긴 사건
                if (ex.get("next") or {}).get("status") in ("stalled", "max_rounds"):
                    handed |= {(s, p["id"]) for p in ex.get("remaining", [])}     # 더 진행하지 못해 넘긴 사건
            elif d["status"] == "handoff":
                handed |= {(s, x) for x in d.get("problem_ids", [])}              # 안전한 계획이 없어 통째로 넘긴 사건
            missed |= {(s, x) for x in self._missed_late_ids(d, ex, nxt)}
        handed -= resolved
        chosen = {k for k, pk in found.items() if not kind or pk == kind}        # 사건 종류 필터
        if result == "성공":
            chosen &= resolved
        elif result == "실패":
            chosen &= handed
        elif result is not None:
            chosen = set()
        deadline_ids = {k for k in chosen if found[k] == "deadline"}
        by_type = []
        for pk, name in (("overheat", "과열 위험"), ("deadline", "마감 위험")):
            ids = {k for k in chosen if found[k] == pk}
            if ids:
                by_type.append({"type": name, "decisions": len(ids), "missed": len(missed & ids) if pk == "deadline" else 0})

        # ---- 결정·기록 단위 (일관성, 실패 패턴, 차단 건수). 결과 필터는 그 사건을 다룬 결정으로 옮겨 건다.
        ids_of = lambda s, d: {(s, x) for x in d.get("problem_ids", [])}
        kept = [(s, d) for s, d in scope if result is None or ids_of(s, d) & chosen]
        keys = {(s, d["round"]) for s, d in kept}
        judged = [d for _, d in kept]
        events = [e for s, log in own("m_log") if log for e in log.get("events", [])
                  if (s, e.get("round")) in keys and e.get("ts", time.time()) >= since]
        first: dict[str, str | None] = {}
        same = total = 0
        for d in judged:
            k = d.get("state_version")
            if k in first:
                total += 1
                same += int(first[k] == d.get("selected_id"))
            else:
                first[k] = d.get("selected_id")
        rep = judged[-1]["decision_id"] if judged else ""

        def pattern(name, count, action):
            return {"pattern": name, "count": count, "decision_id": rep, "action": action} if count else None

        patterns = [p for p in (
            pattern("규칙을 어기는 강제 입력", sum(1 for e in events if e["type"] == "blocked" and e["actor"] == "safety_gate"),
                    "입력 단계 경고 추가 · 모두 Safety Gate에서 차단됨"),
            pattern("권한 없는 승인 시도", sum(1 for e in events if e["type"] == "blocked" and e["actor"] not in ("safety_gate", "system")),
                    "역할별 승인 권한 안내 보강 · 모두 서버에서 거부됨"),
            pattern("모델 호출 실패 후 규칙으로 선택", sum(1 for d in judged if d.get("is_fallback")),
                    "모델 서버 상태 점검 · 규칙 순위로 흐름은 유지됨"),
            pattern("안전한 계획이 없어 사람에게 넘김", sum(1 for d in judged if d["status"] == "handoff"),
                    "냉각 상한 · 여유 자리 확보 검토"),
            pattern("풀 수 없는 문제를 따로 넘김", sum(1 for d in judged if d["status"] == "decided" and d.get("escalate")),
                    "마감·우선순위 정책 검토"),
            pattern("후보 간 차이가 작아 검토 권장", sum(1 for d in judged if d.get("needs_review")),
                    "후보 설명 보강 · 선택지 수 조정 검토"),
        ) if p]
        return {
            "total_decisions": len(chosen), "blocked_attempts": sum(1 for e in events if e["type"] == "blocked"),
            "handed": len(handed & chosen),
            "deadline_met": {"met": len(deadline_ids - missed), "total": len(deadline_ids)},
            "consistency": {"same": same, "total": total},
            # 성공 = 해결한 사건, 실패 = 사람에게 넘긴 사건 (보류 항목은 쓰지 않는다)
            "results": {"succeeded": len(resolved & chosen), "held": 0, "failed": len(handed & chosen)},
            "by_type": by_type, "patterns": patterns,
            "providers": {p: sum(1 for d in judged if d["provider"] == p) for p in ("zoro1", "rule", "mock")},
        }

    def run_log(self, s: str) -> dict:
        """제출용 실행 로그: 회차별 모델 요청·응답까지 포함."""
        with self._lock(s):
            out = self.receipt(s)
            for r in out["rounds"]:
                d = self.store.get(s, "m_decision", str(r["round"]))
                r["zoro1_request"] = (d or {}).get("request")
            return out

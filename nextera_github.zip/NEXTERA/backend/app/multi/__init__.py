"""다중 작업 버전: 노드 1~6개, 일 1~10개, 여러 행동을 묶은 계획 후보, 회차 반복.

기존 단일 사건 흐름(app/engine.py, app/service.py)과 독립적이다. 모델 호출(providers)과 저장소(store)만 함께 쓴다.
"""
from __future__ import annotations

import copy
import json
from pathlib import Path

CONFIG_PATH = Path(__file__).resolve().parents[2] / "data" / "multi_config.json"


def load_config(overrides: dict | None = None) -> dict:
    cfg = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    for section, values in (overrides or {}).items():
        if section not in cfg or not isinstance(cfg[section], dict):
            raise KeyError(f"multi_config 에 없는 섹션: {section}")
        for k, v in values.items():
            if k not in cfg[section]:
                raise KeyError(f"multi_config.{section} 에 없는 키: {k}")
            cfg[section][k] = copy.deepcopy(v)
    return cfg

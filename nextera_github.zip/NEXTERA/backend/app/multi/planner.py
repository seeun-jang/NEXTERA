"""문제 찾기와 계획 후보 생성.

후보 하나 = 행동 여러 개로 이루어진 계획. 전략마다 "가장 급한 문제 → 행동 1개 적용 → 시뮬레이션으로 상태 갱신"을
문제가 없어질 때까지 반복해 계획을 끝까지 만든다. 모든 후보는 필수 규칙 검사와 시뮬레이션을 통과한 것만 남는다.
전수 탐색이 아니므로 결과는 "최적"이 아니라 "검증된 전략안"이다.
"""
from __future__ import annotations

import json
import time

from .sim import apply_step, check_steps, layout_of, simulate, urgency
from .world import PRIO, settle

EPS = 1e-6

# name, 한글 이름, 영어 이름, 행동 종류 우선순서(None = 전부 모아서 고름), 고르는 기준, 옮길 곳 선호, 문제 순서
STRATEGIES = [
    ("cool_first", "냉각 우선", "cooling first", ["cool", "move", "jump", "defer", "evacuate"], "best", "coolest", "severity"),
    ("heat_spread", "열 분산", "spread heat", ["move", "jump", "cool", "defer", "evacuate"], "best", "coolest", "severity"),
    ("deadline_first", "마감 우선", "deadlines first", ["jump", "move", "defer", "cool", "evacuate"], "best", "coolest", "deadline"),
    ("defer_low", "저우선 연기", "defer low priority", ["defer", "cool", "move", "jump", "evacuate"], "best", "coolest", "severity"),
    ("evacuate", "임시 대피", "temporary evacuation", ["evacuate", "jump", "cool", "move", "defer"], "best", "coolest", "severity"),
    ("zone_pack", "구역 몰기", "pack into one zone", ["move", "cool", "jump", "defer", "evacuate"], "best", "pack", "severity"),
    ("energy_min", "에너지 최소", "minimum energy", None, "energy", "coolest", "severity"),
    ("min_ops", "조작 최소", "fewest operations", None, "gain", "coolest", "severity"),
]
STRAT = {s[0]: s for s in STRATEGIES}
HYBRIDS = [("heat_spread", "cool_first"), ("deadline_first", "heat_spread"), ("defer_low", "deadline_first"),
           ("cool_first", "deadline_first"), ("evacuate", "cool_first"), ("zone_pack", "deadline_first"),
           ("deadline_first", "defer_low"), ("cool_first", "defer_low")]
FAMILIES = ("cool", "move", "jump", "defer", "evacuate")


class Evaluator:
    """같은 계획을 두 번 시뮬레이션하지 않도록 결과를 기억한다."""

    def __init__(self, state: dict, cfg: dict):
        self.state, self.cfg = state, cfg
        self.cache: dict[str, dict] = {}
        self.sims = 0
        self.base = self.sim([])

    def sim(self, steps: list[dict]) -> dict:
        key = json.dumps(steps, sort_keys=True)
        hit = self.cache.get(key)
        if hit is None:
            hit = simulate(self.state, steps, self.cfg)
            self.cache[key] = hit
            self.sims += 1
        return hit


def badness(sim: dict, cfg: dict, margin: float = 0.0) -> float:
    """작을수록 좋다. 열 한계 초과 > 마감 위반(우선순위 가중) > 한계 근접(여유 확보 전략에서만)."""
    limit = cfg["limits"]["limit_c"]
    w = cfg["planner"]["late_weight"]
    score = 0.0
    for p in sim["peak_c"].values():
        if p >= limit:
            score += 1e6 + (p - limit) * 1e4
        elif margin and p > limit - margin:
            score += 50.0 + (p - (limit - margin)) * 20.0
    for jid in sim["late_jobs"]:
        j = sim["jobs"][jid]
        score += w[j["priority"]] * (1.0 + j["lateness_s"] / 600.0)
    return score


def find_problems(sim: dict, state: dict, cfg: dict, margin: float = 0.0, order: str = "severity") -> list[dict]:
    """조치 없이(또는 이 계획대로) 두면 생기는 문제. 한계까지 남은 시간이 짧고 우선순위가 높을수록 앞."""
    limit = cfg["limits"]["limit_c"]
    jobs = {j["id"]: j for j in state["jobs"]}
    fans = {n["id"]: n.get("fan") for n in state["nodes"]}
    out = []
    for n, p in sim["peak_c"].items():
        hard = p >= limit
        if not hard and not (margin and p > limit - margin):
            continue
        on = [j for j in jobs.values() if sim["jobs"][j["id"]]["node"] == n]
        prio = min((j["priority"] for j in on), key=lambda x: PRIO[x], default="P2")
        t = sim["reach_limit_s"][n]
        out.append({"id": f"HOT-{n}", "kind": "overheat", "node": n, "job": None, "priority": prio, "hard": hard,
                    "time_min": round((t if t is not None else sim["peak_at_s"][n]) / 60.0, 1), "peak_c": p,
                    "text": ((f"이미 한계 {limit:g}°C 이상 · 조치가 없으면 {cfg['physics'].get('recover_grace_min', 2.0):g}분 안에 내려오지 않음" if t == 0
                              else f"조치가 없으면 약 {t / 60.0:.1f}분 뒤 {'다시 ' if n in sim.get('start_over', []) else ''}{limit:g}°C 도달") if hard and t is not None else "한계 근접")
                    + f" · 예측 최고 {p:.1f}°C" + (" · 팬 이상" if fans.get(n) else "")})
    for jid in sim["late_jobs"]:
        r, j = sim["jobs"][jid], jobs[jid]
        out.append({"id": f"LATE-{jid}", "kind": "deadline", "node": r["node"], "job": jid, "priority": j["priority"], "hard": False,
                    "time_min": round(j["deadline_min"], 1), "lateness_min": round(r["lateness_s"] / 60.0, 1),
                    "text": f"예상 완료 {r['projected_finish_s'] / 60.0:.1f}분 · 마감 {j['deadline_min']:g}분 ({r['lateness_s'] / 60.0:.1f}분 늦음)"})
    for p in out:
        soon = p["time_min"] <= 5
        p["severity"] = "high" if (p["priority"] in ("P0", "P1") and soon) or (p["kind"] == "overheat" and p["hard"] and p["time_min"] <= 3) \
            else ("medium" if p["priority"] in ("P0", "P1") or p["hard"] else "low")
    # 프론트와 같은 순서: 한계까지 남은 시간이 짧을수록, 우선순위가 높을수록(시간에서 보너스를 뺀다) 위
    bonus = cfg["planner"]["priority_bonus_min"]
    key = lambda p: (p["time_min"] - bonus[p["priority"]], PRIO[p["priority"]], p["id"])
    if order == "deadline":
        out.sort(key=lambda p: (p["kind"] != "deadline",) + key(p))
    else:
        out.sort(key=key)
    return out


def _planned_layout(state: dict, steps: list[dict], cfg: dict) -> dict:
    L = layout_of(state)
    for s in steps:
        apply_step(L, s, cfg, 0.0)
        settle(L["queues"], L["jobs"], cfg["limits"]["gpus_per_node"])
    return L


def _free(L: dict, node: str, total: int) -> int:
    return total - sum(L["jobs"][j]["gpus"] for j in L["queues"][node] if L["jobs"][j]["status"] == "running")


def _targets(L: dict, job: dict, cfg: dict, pref: str, only_startable: bool = False, avoid: frozenset = frozenset()) -> list[str]:
    lim = cfg["limits"]
    total = lim["gpus_per_node"]
    out = []
    for n, q in L["queues"].items():
        if n == job["node"] or n in avoid or len(q) >= lim["max_jobs_per_node"]:
            continue                              # 과열이 예측되는 노드로는 일을 보내지 않는다
        can_start = _free(L, n, total) >= job["gpus"]
        if only_startable and not can_start:
            continue
        z = L["zone_of"][n]
        headroom = L["zone_max"][z] - L["levels"][z]
        key = (-headroom, not can_start, L["temps"][n]) if pref == "pack" else (not can_start, L["temps"][n], -headroom)
        out.append((key, n))
    out.sort()
    return [n for _, n in out[: cfg["planner"]["targets_per_job"]]]


def _victims(L: dict, node: str, job: dict, total: int) -> list[str] | None:
    """job 이 node 에서 바로 돌려면 멈춰야 하는 일(덜 급한 것부터). 불가능하면 None."""
    need = job["gpus"] - _free(L, node, total)
    if need <= 0:
        return []
    cand = [L["jobs"][x] for x in L["queues"][node]
            if L["jobs"][x]["status"] == "running" and x != job["id"] and L["jobs"][x]["priority"] != "P0"
            and urgency(job) < urgency(L["jobs"][x])]
    cand.sort(key=lambda v: (-urgency(v)[0], -urgency(v)[1]))
    chosen = []
    for vic in cand:
        chosen.append(vic["id"])
        need -= vic["gpus"]
        if need <= 0:
            return chosen
    return None


def _with_cool(steps: list[dict], zone: str, level: int) -> list[dict]:
    out = [s for s in steps if not (s["type"] == "cool" and s["zone"] == zone)]
    out.append({"type": "cool", "zone": zone, "level": level})
    return out


def _moves_for(problem: dict, state: dict, steps: list[dict], cfg: dict, pref: str, avoid: frozenset = frozenset()) -> dict[str, list[list[dict]]]:
    """문제 하나를 풀 수 있는 다음 행동들. 종류별로 '행동을 더한 계획'을 돌려준다."""
    L = _planned_layout(state, steps, cfg)
    jobs, queues = L["jobs"], L["queues"]
    total = cfg["limits"]["gpus_per_node"]
    used = {s["job"] for s in steps if s["type"] != "cool"} | {v for s in steps for v in s.get("preempt", [])}
    out: dict[str, list[list[dict]]] = {f: [] for f in FAMILIES}

    def cool(node):
        z = L["zone_of"][node]
        if L["levels"][z] < L["zone_max"][z]:
            out["cool"].append(_with_cool(steps, z, L["levels"][z] + 1))

    node = problem["node"]
    if problem["kind"] == "overheat":
        cool(node)
        here = [jobs[x] for x in queues.get(node, []) if x not in used and jobs[x]["priority"] != "P0"]
        running = sorted((j for j in here if j["status"] == "running"), key=lambda j: (-j["gpus"], j["id"]))
        deferable = here                                  # P0 만 아니면 연기할 수 있다(낮은 우선순위부터 시도)
        for j in running:
            for y in _targets(L, j, cfg, pref, avoid=avoid):
                out["move"].append(steps + [{"type": "move", "job": j["id"], "to": y}])
                out["evacuate"].append(steps + [{"type": "evacuate", "job": j["id"], "to": y}])
        for j in sorted(deferable, key=lambda j: (-PRIO[j["priority"]], j["status"] != "running", j["id"])):
            out["defer"].append(steps + [{"type": "defer", "job": j["id"], "minutes": cfg["physics"]["defer_min"]}])
        return out

    j = jobs.get(problem["job"])
    if j is None or j["status"] not in ("running", "waiting"):
        return out
    node = j["node"]
    if L["temps"][node] >= cfg["limits"]["throttle_c"] - 3:
        cool(node)                                   # 스로틀로 느려지는 것을 막는다
    if j["id"] in used:
        return out
    if j["status"] == "waiting":
        q = queues[node]
        if q.index(j["id"]) != next((i for i, x in enumerate(q) if jobs[x]["status"] != "running"), 0):
            out["jump"].append(steps + [{"type": "jump", "job": j["id"], "to": node}])
        vic = _victims(L, node, j, total)
        if vic and not set(vic) & used:
            out["jump"].append(steps + [{"type": "jump", "job": j["id"], "to": node, "preempt": vic}])
        if j["priority"] != "P0":
            for y in _targets(L, j, cfg, pref, only_startable=True, avoid=avoid):
                out["move"].append(steps + [{"type": "move", "job": j["id"], "to": y}])
            for y in _targets(L, j, cfg, pref, avoid=avoid):
                vic = _victims(L, y, j, total)
                if vic and not set(vic) & used:
                    out["jump"].append(steps + [{"type": "jump", "job": j["id"], "to": y, "preempt": vic}])
        ahead = [jobs[x] for x in q if jobs[x]["status"] == "running" and x not in used and jobs[x]["priority"] != "P0"
                 and urgency(j) < urgency(jobs[x])]
        for vct in sorted(ahead, key=lambda v: (-PRIO[v["priority"]], v["id"])):
            out["defer"].append(steps + [{"type": "defer", "job": vct["id"], "minutes": cfg["physics"]["defer_min"]}])
            if vct["priority"] != "P0":
                for y in _targets(L, vct, cfg, pref, only_startable=True, avoid=avoid)[:1]:
                    out["move"].append(steps + [{"type": "move", "job": vct["id"], "to": y}])
    return out


def _victim_rule_ok(ev: Evaluator, steps: list[dict], sim: dict) -> bool:
    """중단당한 일이 그 때문에 마감을 놓치면 안 된다."""
    base_late = set(ev.base["late_jobs"])
    for s in steps:
        for vic in s.get("preempt", []):
            if vic in sim["late_jobs"] and vic not in base_late:
                return False
    return True


def _acceptable(ev: Evaluator, steps: list[dict]) -> dict | None:
    if check_steps(ev.state, steps, ev.cfg):
        return None
    sim = ev.sim(steps)
    if sim["skipped"] or not _victim_rule_ok(ev, steps, sim):
        return None
    return sim


def build_plan(ev: Evaluator, sequence: list[str], margin: float = 0.0, alt: int = 0) -> list[dict]:
    """sequence = 단계마다 쓸 전략 이름(마지막 것이 반복된다). alt = 첫 단계에서 고를 순위(0 = 최선, 1 = 차선 …)."""
    cfg = ev.cfg
    steps: list[dict] = []
    cur = ev.base
    cur_bad = badness(cur, cfg, margin)
    for i in range(cfg["planner"]["max_steps"]):
        if cur_bad <= EPS:
            break
        _, _, _, fams, pick, pref, order = STRAT[sequence[min(i, len(sequence) - 1)]]
        probs = find_problems(cur, ev.state, cfg, margin, order)[: cfg["planner"]["problems_per_step"]]
        avoid = frozenset(ev.base["thermal_nodes"]) | frozenset(cur["thermal_nodes"])
        pools = [_moves_for(p, ev.state, steps, cfg, pref, avoid) for p in probs]
        groups = [[f] for f in fams] if fams else [list(FAMILIES)]
        chosen = None
        for group in groups:
            ranked = []
            seen = set()
            for pool in pools:
                for fam in group:
                    for cand in pool[fam]:
                        key = json.dumps(cand, sort_keys=True)
                        if key in seen:
                            continue
                        seen.add(key)
                        sim = _acceptable(ev, cand)
                        if sim is None:
                            continue
                        b = badness(sim, cfg, margin)
                        if b >= cur_bad - EPS:
                            continue
                        if pick == "energy":
                            rank = (sim["cooling_kwh"], b, len(cand))
                        else:
                            rank = (b, sim["cooling_kwh"], len(cand))
                        ranked.append((rank, key, cand, sim, b))
            if ranked:
                ranked.sort(key=lambda r: (r[0], r[1]))
                want = alt if i == 0 else 0
                if want >= len(ranked):
                    return []                      # 이 전략에는 그만큼의 대안이 없다
                r = ranked[want]
                chosen = (r[0], r[2], r[3], r[4])
                break
        if chosen is None:
            break
        _, steps, cur, cur_bad = chosen
    return _prune(ev, steps, margin)


def _prune(ev: Evaluator, steps: list[dict], margin: float) -> list[dict]:
    """빼도 결과가 나빠지지 않는 단계는 뺀다."""
    if not steps:
        return steps
    cfg = ev.cfg
    cur_bad = badness(ev.sim(steps), cfg, margin)
    changed = True
    while changed and steps:
        changed = False
        for i in range(len(steps) - 1, -1, -1):
            trial = steps[:i] + steps[i + 1:]
            sim = _acceptable(ev, trial) if trial else ev.base
            if sim is not None and badness(sim, cfg, margin) <= cur_bad + EPS:
                steps, changed = trial, True
                break
    return steps


# ------------------------------------------------------------------ 표시용 문구

def describe_steps(state: dict, steps: list[dict], cfg: dict) -> list[dict]:
    """단계마다 화면용(ko)·모델용(en) 문구와 필요한 승인 역할을 붙인다."""
    L = layout_of(state)
    roles = cfg["approval_roles"]
    out = []
    for i, s in enumerate(steps):
        t = s["type"]
        if t == "cool":
            cur = L["levels"].get(s["zone"])
            ko = f"{s['zone']} 냉각 {cur} → {s['level']}"
            en = f"raise cooling of zone {s['zone']} from level {cur} to {s['level']} (max {L['zone_max'].get(s['zone'])})"
        else:
            j = L["jobs"].get(s["job"], {})
            tag = f"{s['job']} ({j.get('priority')}, {j.get('gpus')} GPUs)"
            src = j.get("node")
            if t == "move":
                ko, en = f"{s['job']}을 {src} → {s['to']}로 이동", f"move {tag} from {src} to {s['to']}"
            elif t == "evacuate":
                below = s.get("return_below_c", cfg["physics"]["evacuate_return_c"])
                ko = f"{s['job']}을 {s['to']}로 임시 대피 ({src}가 {below:g}°C 이하로 식으면 복귀)"
                en = f"temporarily move {tag} from {src} to {s['to']}, returning when {src} cools below {below:g}°C"
            elif t == "defer":
                ko, en = f"{s['job']}을 {s.get('minutes', cfg['physics']['defer_min']):g}분 연기", \
                    f"pause {tag} on {src} for {s.get('minutes', cfg['physics']['defer_min']):g} min"
            else:
                vic = s.get("preempt") or []
                where = f"{s['to']} 대기열 맨 앞으로" if s["to"] == src else f"{src} → {s['to']}로 옮겨 맨 앞에 세움"
                ko = f"{s['job']}을 {where}" + (f" ({', '.join(vic)} 중단)" if vic else "")
                en = (f"put {tag} at the front of the queue on {s['to']}" if s["to"] == src else f"move {tag} from {src} to the front of the queue on {s['to']}") \
                    + (f", pausing {', '.join(vic)}" if vic else "")
        out.append({"index": i + 1, **s, "label": ko, "label_en": en, "requires_approval_role": roles[t]})
        apply_step(L, s, cfg, 0.0)
        settle(L["queues"], L["jobs"], cfg["limits"]["gpus_per_node"])
    return out


def _metrics(ev: Evaluator, steps: list[dict], base_problems: list[dict]) -> dict:
    cfg, sim, base = ev.cfg, ev.sim(steps), ev.base
    probs = find_problems(sim, ev.state, cfg)
    left = {p["id"] for p in probs}
    before = {p["id"] for p in base_problems}
    return {
        "max_peak_c": sim["max_peak_c"], "max_peak_node": sim["max_peak_node"], "peak_c": sim["peak_c"],
        "cooling_kwh": sim["cooling_kwh"], "cooling_kwh_delta": round(sim["cooling_kwh"] - base["cooling_kwh"], 4),
        "late_jobs": [{"job": j, "priority": sim["jobs"][j]["priority"], "lateness_min": round(sim["jobs"][j]["lateness_s"] / 60.0, 1)} for j in sim["late_jobs"]],
        "thermal_nodes": sim["thermal_nodes"],
        "job_finish_min": {j: round(r["projected_finish_s"] / 60.0, 1) for j, r in sim["jobs"].items()},
        "temps": sim["temps"],
        "resolved": sorted(before - left), "remaining": sorted(left & before), "new_problems": sorted(left - before),
        "badness": round(badness(sim, cfg), 3), "horizon_min": round(sim["end_s"] / 60.0, 1),
    }


def generate(state: dict, cfg: dict) -> dict:
    """상태 → 문제 목록과 검증된 계획 후보(최대 max_candidates 개)."""
    t0 = time.perf_counter()
    ev = Evaluator(state, cfg)
    problems = find_problems(ev.base, state, cfg)
    result = {"problems": problems, "candidates": [], "escalate": [], "rejected": [], "no_action": _no_action(ev)}
    if not problems:
        result["stats"] = {"sims": ev.sims, "gen_ms": round((time.perf_counter() - t0) * 1000, 1), "raw_plans": 0,
                           "strategies": 0, "built": 0, "merged": 0, "safe": 0, "pareto": 0, "sent": 0}
        return result

    margin = float(cfg["physics"]["risk_margin_c"])
    recipes: list[tuple[list[str], float, int, str, str]] = []
    for name, ko, en, *_ in STRATEGIES:
        recipes.append(([name], 0.0, 0, ko, en))
    for name, ko, en, *_ in STRATEGIES:
        recipes.append(([name], margin, 0, f"{ko} (여유 확보)", f"{en}, with safety margin"))
    for a, b in HYBRIDS:
        recipes.append(([a, b], 0.0, 0, f"{STRAT[a][1]} → {STRAT[b][1]}", f"{STRAT[a][2]}, then {STRAT[b][2]}"))
    for k in range(1, int(cfg["planner"].get("alternates", 2)) + 1):      # 첫 수를 차선·차차선으로 바꾼 대안
        for name, ko, en, *_ in STRATEGIES:
            recipes.append(([name], 0.0, k, f"{ko} (대안 {k + 1})", f"{en}, alternative {k + 1}"))

    merged: dict[str, dict] = {}
    raw = 0
    for seq, m, alt, ko, en in recipes:
        steps = build_plan(ev, seq, m, alt)
        if not steps:
            continue
        raw += 1
        key = json.dumps(sorted(steps, key=lambda s: json.dumps(s, sort_keys=True)), sort_keys=True)
        entry = merged.setdefault(key, {"steps": steps, "names": [], "names_en": []})
        if ko not in entry["names"]:
            entry["names"].append(ko)
            entry["names_en"].append(en)

    def reject(entry, reason, policy=None):
        result["rejected"].append({"strategy": entry["names"][0], "reason": reason, "policy": policy,
                                   "steps": [s["label"] for s in describe_steps(state, entry["steps"], cfg)]})

    base_hot = set(ev.base["thermal_nodes"])
    plans = []
    for entry in merged.values():
        sim = ev.sim(entry["steps"])
        hot = set(sim["thermal_nodes"])
        if not hot <= base_hot:                                   # 없던 과열을 만드는 계획은 버린다
            reject(entry, f"없던 과열을 만듦 ({', '.join(sorted(hot - base_hot))})", "POL-02")
            continue
        if any(sim["peak_c"][n] > ev.base["peak_c"][n] + 0.05 for n in hot):
            reject(entry, "과열될 노드를 더 뜨겁게 함", "POL-02")
            continue
        plans.append({**entry, "sim": sim, "hot": hot})
    if plans:
        fewest = min(len(p["hot"]) for p in plans)
        for p in plans:
            if len(p["hot"]) != fewest:
                reject(p, f"다른 계획이 푸는 과열을 남김 ({', '.join(sorted(p['hot']))})", "POL-02")
        plans = [p for p in plans if len(p["hot"]) == fewest]     # 풀 수 있는 과열은 반드시 푸는 계획만

    objective = state.get("objective", "balanced")
    for p in plans:
        p["metrics"] = _metrics(ev, p["steps"], problems)
    # 문제를 하나도 풀지 못하고 상황도 나아지지 않는 계획은 후보가 아니다(여유만 조금 늘리는 계획 등)
    base_bad = badness(ev.base, cfg)
    for p in plans:
        if not p["metrics"]["resolved"] and p["metrics"]["badness"] >= base_bad - EPS:
            reject(p, "남은 문제를 하나도 풀지 못함")
    plans = [p for p in plans if p["metrics"]["resolved"] or p["metrics"]["badness"] < base_bad - EPS]
    # 없던 P0·P1 마감 위반을 새로 만드는 계획은, 그렇지 않은 계획이 있으면 후보에서 뺀다
    def regress(p):
        return any(x.startswith("LATE-") and ev.base["jobs"][x[5:]]["priority"] in ("P0", "P1") for x in p["metrics"]["new_problems"])
    if any(not regress(p) for p in plans):
        for p in plans:
            if regress(p):
                reject(p, "없던 P0·P1 마감 위반을 만듦 (" + ", ".join(x[5:] for x in p["metrics"]["new_problems"]) + ")", "POL-08")
        plans = [p for p in plans if not regress(p)]
    n_safe = len(plans)
    for p in plans:
        b = p["metrics"]["badness"]
        kwh, n = p["metrics"]["cooling_kwh"], len(p["steps"])
        p["rule_key"] = (b, kwh, n, p["metrics"]["max_peak_c"]) if objective == "energy" \
            else (b, p["metrics"]["max_peak_c"], n, kwh) if objective == "performance" else (b, n, kwh, p["metrics"]["max_peak_c"])
    plans.sort(key=lambda p: (p["rule_key"], json.dumps(p["steps"], sort_keys=True)))

    cap = int(cfg["planner"]["max_candidates"])
    if len(plans) > cap:                                          # 넘칠 때만: 모든 면에서 뒤지는 계획부터 버린다
        def dominated(a):
            ma = a["metrics"]
            for b_ in plans:
                if b_ is a:
                    continue
                mb = b_["metrics"]
                le = (mb["badness"] <= ma["badness"] and mb["cooling_kwh"] <= ma["cooling_kwh"]
                      and len(b_["steps"]) <= len(a["steps"]) and mb["max_peak_c"] <= ma["max_peak_c"])
                lt = (mb["badness"] < ma["badness"] or mb["cooling_kwh"] < ma["cooling_kwh"]
                      or len(b_["steps"]) < len(a["steps"]) or mb["max_peak_c"] < ma["max_peak_c"])
                if le and lt:
                    return True
            return False
        keep = [p for p in plans if not dominated(p)]
        plans = (keep + [p for p in plans if p not in keep])[:cap]
        plans.sort(key=lambda p: (p["rule_key"], json.dumps(p["steps"], sort_keys=True)))

    if plans:
        # 어떤 계획으로도 못 푸는 문제(과열·마감)는 계획과 별개로 사람에게 넘긴다
        common = set.intersection(*[set(p["metrics"]["remaining"]) for p in plans])
        result["escalate"] = [p for p in problems if p["id"] in common]
    for i, p in enumerate(plans):
        steps = describe_steps(state, p["steps"], cfg)
        roles = sorted({s["requires_approval_role"] for s in steps})
        result["candidates"].append({
            "id": f"P{i + 1:02d}", "rule_rank": i + 1, "strategies": p["names"], "strategies_en": p["names_en"],
            "label": p["names"][0] + (f" 외 {len(p['names']) - 1}" if len(p["names"]) > 1 else ""),
            "steps": steps, "required_roles": roles, **p["metrics"],
        })
    n = len(result["candidates"])
    result["stats"] = {"sims": ev.sims, "gen_ms": round((time.perf_counter() - t0) * 1000, 1), "raw_plans": raw,
                       "distinct_plans": len(merged), "candidates": n,
                       # 화면의 후보 깔때기: 전략 → 연쇄 계획 → 정리·합치기 → Safety Gate → 열위 제거 → Zoro-1 전달
                       "strategies": len(recipes), "built": raw, "merged": len(merged), "safe": n_safe, "pareto": n,
                       "sent": min(n, int(cfg["planner"].get("max_model_candidates", n) or n))}
    return result


def _no_action(ev: Evaluator) -> dict:
    sim = ev.base
    return {"max_peak_c": sim["max_peak_c"], "max_peak_node": sim["max_peak_node"], "peak_c": sim["peak_c"],
            "reach_limit_min": {n: (None if t is None else round(t / 60.0, 1)) for n, t in sim["reach_limit_s"].items()},
            "cooling_kwh": sim["cooling_kwh"], "thermal_nodes": sim["thermal_nodes"],
            "recovering": {n: round(t / 60.0, 1) for n, t in sim["recovered_s"].items() if t is not None and n not in sim["thermal_nodes"]},
            "late_jobs": [{"job": j, "lateness_min": round(sim["jobs"][j]["lateness_s"] / 60.0, 1)} for j in sim["late_jobs"]],
            "job_finish_min": {j: round(r["projected_finish_s"] / 60.0, 1) for j, r in sim["jobs"].items()},
            "temps": sim["temps"], "horizon_min": round(sim["end_s"] / 60.0, 1)}

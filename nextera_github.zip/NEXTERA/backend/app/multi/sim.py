"""다중 작업 시뮬레이터 (30초 틱, 결정적).

- 노드의 일은 줄 순서대로 처리한다. GPU 합이 용량 이하이면 동시에 돌고, 넘는 일은 그 노드에서 기다린다.
- 온도는 평형 온도(실행 GPU 수가 많을수록, 팬 이상이면 더 높고, 구역 냉각 레벨이 높을수록 낮다)를 향해 움직인다. 프론트 엔진과 같은 식이다.
- 설정한 현재 온도는 출발점이다.
- 계획의 단계는 승인 대기(approval_wait_s) 뒤 같은 시각에 순서대로 적용한다. 임시 대피의 복귀만 조건부로 나중에 일어난다.
"""
from __future__ import annotations

import copy
import math

from .world import PRIO, settle

INF = float("inf")
JOB_STEPS = ("move", "jump", "evacuate", "defer")
STEP_TYPES = JOB_STEPS + ("cool",)


def urgency(job: dict) -> tuple:
    """작을수록 급하다: 우선순위가 높을수록, 같은 우선순위면 마감이 빠를수록."""
    d = job.get("deadline_min")
    return (PRIO[job["priority"]], INF if d is None else d)


def layout_of(state: dict) -> dict:
    """상태 → 시뮬레이션용 가변 구조."""
    jobs = {}
    for j in state["jobs"]:
        x = dict(j)
        x["remaining"] = float(j["remaining_min"])
        x["defer_until_s"] = None if j.get("defer_until_min") is None else float(j["defer_until_min"]) * 60.0
        jobs[j["id"]] = x
    zone_of = {n["id"]: n["zone"] for n in state["nodes"]}
    return {
        "jobs": jobs,
        "queues": {nid: list(q) for nid, q in state["queues"].items()},
        "temps": {n["id"]: float(n["temp_c"]) for n in state["nodes"]},
        "levels": {z["id"]: int(z["cooling_level"]) for z in state["zones"]},
        "zone_max": {z["id"]: int(z["cooling_max"]) for z in state["zones"]},
        "zone_of": zone_of,
        "returns": [dict(r) for r in state.get("returns", [])],
    }


def _front_index(L: dict, node: str) -> int:
    q, jobs = L["queues"][node], L["jobs"]
    for i, jid in enumerate(q):
        if jobs[jid]["status"] != "running":
            return i
    return len(q)


def apply_step(L: dict, step: dict, cfg: dict, t_s: float = 0.0, dry: bool = False) -> list[dict]:
    """단계 하나를 구조에 적용한다. 필수 규칙 위반이 있으면 적용하지 않고 위반 목록을 돌려준다."""
    lim, ph = cfg["limits"], cfg["physics"]
    jobs, queues = L["jobs"], L["queues"]
    v: list[dict] = []

    def bad(pid, msg):
        v.append({"policy_id": pid, "message": msg})

    typ = step.get("type")
    if typ not in STEP_TYPES:
        bad("INVALID", f"알 수 없는 행동 {typ!r}")
        return v

    if typ == "cool":
        z, lvl = step.get("zone"), step.get("level")
        if z not in L["levels"]:
            bad("INVALID", f"구역 {z} 가 없습니다")
        elif not isinstance(lvl, int) or lvl < 1:
            bad("INVALID", "냉각 레벨은 1 이상의 정수여야 합니다")
        elif lvl > L["zone_max"][z]:
            bad("COOL-MAX", f"{z} 냉각 상한은 {L['zone_max'][z]} 입니다 (요청 {lvl})")
        elif lvl == L["levels"][z]:
            bad("INVALID", f"{z} 는 이미 레벨 {lvl} 입니다")
        if not v and not dry:
            L["levels"][z] = lvl
        return v

    j = jobs.get(step.get("job"))
    if j is None:
        bad("INVALID", f"일 {step.get('job')} 이 없습니다")
        return v
    if j["status"] not in ("running", "waiting"):
        bad("INVALID", f"{j['id']} 는 지금 조작할 수 없는 상태입니다 ({j['status']})")
        return v
    restart = float(ph["restart_cost_min"])

    if typ == "defer":
        minutes = step.get("minutes", ph["defer_min"])
        if j["priority"] == "P0":
            bad("POL-01", f"{j['id']} 는 P0 라서 연기할 수 없습니다")
        if not isinstance(minutes, (int, float)) or minutes <= 0:
            bad("INVALID", "연기 시간은 0보다 커야 합니다")
        if not v and not dry:
            queues[j["node"]].remove(j["id"])
            if j["status"] == "running":
                j["remaining"] += restart
            j["status"], j["defer_until_s"] = "deferred", t_s + float(minutes) * 60.0
        return v

    to = step.get("to")
    if to not in queues:
        bad("INVALID", f"노드 {to} 가 없습니다")
        return v
    src = j["node"]
    relocating = to != src
    victims = [jobs.get(x) for x in (step.get("preempt") or [])] if typ == "jump" else []
    if typ in ("move", "evacuate") and not relocating:
        bad("INVALID", f"{j['id']} 는 이미 {to} 에 있습니다")
    if typ == "jump" and not relocating and j["status"] == "running" and not victims:
        bad("INVALID", f"{j['id']} 는 이미 실행 중입니다")
    if relocating:
        if j["priority"] == "P0":
            bad("POL-01", f"{j['id']} 는 P0 라서 옮길 수 없습니다")
        if len(queues[to]) >= lim["max_jobs_per_node"]:
            bad("POL-03", f"{to} 에는 일을 더 놓을 수 없습니다 (최대 {lim['max_jobs_per_node']}개)")
    if j["gpus"] > lim["gpus_per_node"]:
        bad("POL-03", f"{j['id']} 는 GPU {j['gpus']}장이 필요해 어느 노드에도 들어가지 않습니다")
    for vic in victims:
        if vic is None or vic["node"] != to or vic["status"] != "running" or vic["id"] == j["id"]:
            bad("INVALID", f"중단 대상은 {to} 에서 실행 중인 다른 일이어야 합니다")
        elif vic["priority"] == "P0":
            bad("POL-01", f"{vic['id']} 는 P0 라서 중단할 수 없습니다")
        elif not urgency(j) < urgency(vic):
            bad("POL-09", f"{j['id']} 가 {vic['id']} 보다 급하지 않아 중단시킬 수 없습니다")
    if v or dry:
        return v

    queues[src].remove(j["id"])
    if j["status"] == "running":
        j["remaining"] += restart            # 실행 중이던 일은 다시 시작하는 비용을 치른다
    j["status"], j["node"] = "waiting", to
    if typ == "jump":
        at = _front_index(L, to)
        for vic in victims:                    # 멈춘 일은 끼어든 일 바로 뒤, 대기열 맨 앞으로
            queues[to].remove(vic["id"])
            vic["status"] = "waiting"
            vic["remaining"] += restart
        at = min(at, _front_index(L, to))
        queues[to].insert(at, j["id"])
        for k, vic in enumerate(victims):
            queues[to].insert(at + 1 + k, vic["id"])
    else:
        queues[to].append(j["id"])
        if typ == "evacuate":
            below = step.get("return_below_c")
            if below is None:
                below = ph["evacuate_return_c"]
            L["returns"].append({"job": j["id"], "src": src, "dst": to, "below_c": float(below)})
    return v


def check_steps(state: dict, steps: list[dict], cfg: dict) -> list[dict]:
    """계획의 단계를 순서대로 가상 적용해 필수 규칙(용량·P0 보호·중단 조건·냉각 상한)을 검사한다."""
    L = layout_of(state)
    out, seen_jobs, seen_zones = [], set(), set()
    for i, s in enumerate(steps):
        key = s.get("job") if s.get("type") != "cool" else None
        if key is not None and key in seen_jobs:
            out.append({"step": i, "policy_id": "INVALID", "message": f"{key} 에 대한 단계가 두 번 들어 있습니다"})
            continue
        if s.get("type") == "cool" and s.get("zone") in seen_zones:
            out.append({"step": i, "policy_id": "INVALID", "message": f"{s.get('zone')} 냉각 단계가 두 번 들어 있습니다"})
            continue
        for x in apply_step(L, s, cfg, 0.0):
            out.append({"step": i, **x})
        if key is not None:
            seen_jobs.add(key)
        if s.get("type") == "cool":
            seen_zones.add(s.get("zone"))
        settle(L["queues"], L["jobs"], cfg["limits"]["gpus_per_node"])
    return out


def _snapshot(L: dict, state: dict, t_s: float, done: list[str]) -> dict:
    jobs = []
    for j in L["jobs"].values():
        if j["status"] == "done":
            continue
        d = j.get("deadline_min")
        jobs.append({"id": j["id"], "gpus": j["gpus"], "priority": j["priority"],
                     "deadline_min": None if d is None else round(d - t_s / 60.0, 3),
                     "remaining_min": round(max(j["remaining"], 0.001), 3), "node": j["node"], "status": j["status"],
                     "defer_until_min": None if j["defer_until_s"] is None or j["status"] != "deferred"
                     else round((j["defer_until_s"] - t_s) / 60.0, 3)})
    return {
        "round": state.get("round", 1), "sim_time": state.get("sim_time"), "objective": state.get("objective", "balanced"),
        "nodes": [{**n, "temp_c": round(L["temps"][n["id"]], 2)} for n in state["nodes"]],
        "zones": [{**z, "cooling_level": L["levels"][z["id"]]} for z in state["zones"]],
        "jobs": jobs, "queues": {nid: list(q) for nid, q in L["queues"].items()},
        "returns": [dict(r) for r in L["returns"]], "done_jobs": list(state.get("done_jobs", [])) + done,
        "elapsed_s": t_s,
    }


def simulate(state: dict, steps: list[dict] | None, cfg: dict, *, capture_s: float | None = None) -> dict:
    ph, lim = cfg["physics"], cfg["limits"]
    dt = float(ph["dt_s"])
    step_min = dt / 60.0
    eq_base, eq_gpu, eq_lvl, eq_min = float(ph["eq_base_c"]), float(ph["eq_per_gpu_c"]), float(ph["eq_per_level_c"]), float(ph["eq_min_c"])
    fan_factor, alpha = float(ph["fan_factor"]), 1.0 - math.exp(-step_min / float(ph["tau_min"]))
    kw_per_level = float(ph["cooling_kw_per_level"])
    limit, throttle_c, slow = float(lim["limit_c"]), float(lim["throttle_c"]), float(ph["throttle_speed_factor"])
    total = int(lim["gpus_per_node"])
    steps = steps or []
    apply_tick = int(round(float(ph["approval_wait_s"]) / dt)) if steps else -1
    cap_tick = None if capture_s is None else int(round(capture_s / dt))
    ticks = max(int(ph["ticks"]), (cap_tick or 0) + 1)       # 모든 계획을 같은 길이로 본다(에너지·최고 온도 비교가 공정하도록)

    L = layout_of(state)
    jobs, queues, temps, levels, zone_of = L["jobs"], L["queues"], L["temps"], L["levels"], L["zone_of"]
    fan = {n["id"]: bool(n.get("fan")) for n in state["nodes"]}
    node_ids = list(temps)
    series = {n: [round(temps[n], 2)] for n in node_ids}
    peak = {n: (temps[n], 0.0) for n in node_ids}
    reach = {n: (0.0 if temps[n] >= limit else None) for n in node_ids}
    # 시작부터 한계 이상인 노드: 유예 시간 안에 한계 아래로 내려오면 그때부터 다시 본다(그 뒤 다시 넘으면 과열)
    grace_ticks = max(1, int(round(float(ph.get("recover_grace_min", 2.0)) * 60.0 / dt)))
    recovering = {n: temps[n] >= limit for n in node_ids}
    start_over = [n for n in node_ids if recovering[n]]
    recovered = {n: None for n in start_over}
    info = {jid: {"finish_s": None, "first_run_s": 0.0 if j["status"] == "running" else None} for jid, j in jobs.items()}
    skipped, done_ids, captured = [], [], None
    cooling_kwh = 0.0
    end_s = 0.0

    for tick in range(ticks):
        t = tick * dt
        if tick == apply_tick:
            for i, s in enumerate(steps):
                for x in apply_step(L, s, cfg, t):
                    skipped.append({"step": i, **x})
        for j in jobs.values():                               # 연기했던 일의 복귀
            if j["status"] == "deferred" and j["defer_until_s"] is not None and j["defer_until_s"] <= t:
                j["status"] = "waiting"
                queues[j["node"]].append(j["id"])
        if L["returns"]:                                      # 임시 대피한 일은 원래 노드가 식으면 그 노드 대기열 맨 앞으로 돌아온다
            for r in list(L["returns"]):
                j = jobs.get(r["job"])
                if j is None or j["status"] not in ("running", "waiting") or j["node"] != r["dst"]:
                    L["returns"].remove(r)
                elif temps[r["src"]] < r["below_c"] and len(queues[r["src"]]) < lim["max_jobs_per_node"]:
                    queues[r["dst"]].remove(j["id"])
                    if j["status"] == "running":
                        j["remaining"] += float(ph["restart_cost_min"])
                    j["status"], j["node"] = "waiting", r["src"]
                    queues[r["src"]].insert(_front_index(L, r["src"]), j["id"])
                    L["returns"].remove(r)
        settle(queues, jobs, total)
        if tick == cap_tick:
            captured = _snapshot(L, state, t, done_ids)

        for n in node_ids:
            q = queues[n]
            T = temps[n]
            rate = slow if T >= throttle_c else 1.0
            run_gpus = 0
            finished = None
            for jid in q:
                j = jobs[jid]
                if j["status"] != "running":
                    continue
                run_gpus += j["gpus"]
                if info[jid]["first_run_s"] is None:
                    info[jid]["first_run_s"] = t
                work = step_min * rate
                if j["remaining"] <= work:
                    info[jid]["finish_s"] = round(t + dt * (j["remaining"] / work), 1)
                    j["remaining"], j["status"] = 0.0, "done"
                    (finished := finished or []).append(jid)
                else:
                    j["remaining"] -= work
            if finished:
                for jid in finished:
                    q.remove(jid)
                    done_ids.append(jid)
            eq = max(eq_min, eq_base + eq_gpu * run_gpus * (fan_factor if fan[n] else 1.0) - eq_lvl * levels[zone_of[n]])
            T = T + (eq - T) * alpha
            temps[n] = T
            series[n].append(round(T, 2))
            if recovering[n]:
                if T < limit:                                  # 한계 아래로 복귀: 여기서부터 최고 온도를 다시 잰다
                    recovering[n] = False
                    recovered[n] = t + dt
                    peak[n], reach[n] = (T, t + dt), None
                elif tick + 1 >= grace_ticks:                  # 유예 시간 안에 못 내려옴
                    recovering[n] = False
                continue
            if T > peak[n][0]:
                peak[n] = (T, t + dt)
            if reach[n] is None and T >= limit:
                reach[n] = t + dt
        cooling_kwh += sum(levels.values()) * kw_per_level * dt / 3600.0
        end_s = t + dt

    tol = float(ph.get("late_tolerance_min", 0.05)) * 60.0
    job_out, late = {}, []
    for jid, j in jobs.items():
        fin = info[jid]["finish_s"]
        proj = fin
        if fin is None:
            # 예측 구간 안에 못 끝난 일: 구간 끝 + 남은 작업 시간 (+ 연기 중이면 남은 연기 시간)
            wait = max(0.0, (j["defer_until_s"] or 0.0) - end_s) if j["status"] == "deferred" else 0.0
            proj = round(end_s + j["remaining"] * 60.0 + wait, 1)
        d = j.get("deadline_min")
        lateness = 0.0
        if d is not None and proj > d * 60.0 + tol:
            lateness = round(proj - d * 60.0, 1)
        if lateness > 0:
            late.append(jid)
        job_out[jid] = {"status": j["status"], "node": j["node"], "priority": j["priority"], "gpus": j["gpus"],
                        "finish_s": fin, "projected_finish_s": proj, "first_run_s": info[jid]["first_run_s"],
                        "deadline_s": None if d is None else d * 60.0, "lateness_s": lateness}
    hot = [n for n in node_ids if peak[n][0] >= limit]
    top = max(node_ids, key=lambda n: peak[n][0])
    return {
        "end_s": end_s, "temps": series,
        "peak_c": {n: round(peak[n][0], 2) for n in node_ids}, "peak_at_s": {n: peak[n][1] for n in node_ids},
        "reach_limit_s": reach, "max_peak_c": round(peak[top][0], 2), "max_peak_node": top,
        "cooling_kwh": round(cooling_kwh, 4), "jobs": job_out,
        "thermal_nodes": hot, "late_jobs": late, "skipped": skipped, "captured": captured,
        "start_over": start_over, "recovered_s": recovered,
        "final_levels": dict(levels),
    }

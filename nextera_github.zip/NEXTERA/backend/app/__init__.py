"""NEXTERA backend — 계약(shared/contracts/types.ts) 1.0.0 구현.

응답에는 계약에 없는 선택 필드(decision_mode, diagnostics, review …)가 더 들어 있다. 프론트는 모르는 필드를 무시한다.
"""

CONTRACT_VERSION = "1.0.0"

"""30초 단위 열·작업 시뮬레이터 (결정론적, 난수 없음).

    다음 온도 = 현재 온도 + dt × (발열 kW − 제거 열량 kW) ÷ 열용량(kJ/°C)
    발열 kW   = 유휴 발열 + 그 노드에서 도는 작업들의 발열
    제거 열량 = k × 냉각 레벨 계수 × (현재 온도 − 외기)
    냉각 전력 = 제거 열량 ÷ COP,   에너지(kWh) = 전력 × dt ÷ 3600

보정(calibrate) — 스냅샷의 관측값에서 노드별 상수를 정한다.
- 작업 발열: 노드 관측 전력에서 유휴 발열을 뺀 값을 그 노드의 작업들이 GPU 수 비율로 나눠 가진다.
  작업이 이동하면 발열도 같이 옮겨 간다.
- 제거 계수 k: 온도가 안정된 노드는 "발열 = 제거"인 평형에서 구한다.
  상승 중("rising") 노드는 같은 구역 안정 노드의 중앙값 × 효율(팬 이상 등)로 둔다.
- 냉각 레벨 계수 = 1 + gain × (레벨 − 스냅샷 시점 레벨)

행동은 승인 대기(approval_wait_s) 뒤 첫 tick 에 적용된다.
- cooling_change: 구역 냉각 레벨 변경      - job_migrate: 작업 이동, 재시작 비용 동안 진행 정지
- job_defer    : 지정 분 동안 작업 정지      - 그 밖(None, 정보 요청, 이관): 변화 없음

rollout 안에 끝나지 않은 작업의 완료 시각은 정상 속도 기준 추정이며 finish_projected=True 로 표시한다.
"""
from __future__ import annotations

from statistics import median
from typing import Any

PHYSICAL_TYPES = ("cooling_change", "job_migrate", "job_defer")


def node_map(snap: dict) -> dict[str, dict]:
    return {n["id"]: n for n in snap["nodes"]}


def job_map(snap: dict) -> dict[str, dict]:
    return {j["id"]: j for j in snap["jobs"]}


def policy_limits(policy: dict) -> tuple[float, float]:
    """(안전 한계, 스로틀 온도) — 정책 POL-02 의 params 에서 읽는다."""
    for p in policy["policies"]:
        params = p.get("params") or {}
        if "limit_c" in params:
            return float(params["limit_c"]), float(params.get("throttle_c", params["limit_c"]))
    raise ValueError("정책에 온도 한계(limit_c)가 없음")


def calibrate(snap: dict, physics: dict) -> dict:
    ambient = float(physics["ambient_temp_c"])
    idle = float(physics["idle_heat_kw"])
    jobs = job_map(snap)

    job_kw: dict[str, float] = {}
    job_util: dict[str, float] = {}
    for n in snap["nodes"]:
        running = [jobs[j] for j in n["job_ids"] if jobs[j]["status"] == "running"]
        total_gpus = sum(j["gpus"] for j in running) or 1
        load_kw = max(0.0, float(n["power_kw"]) - idle)
        for j in running:
            share = j["gpus"] / total_gpus
            job_kw[j["id"]] = load_kw * share
            job_util[j["id"]] = float(n["gpu_util_pct"]) * share

    steady_k: dict[str, float] = {}
    for n in snap["nodes"]:
        if "rising" in n["flags"]:
            continue
        delta = float(n["temp_c"]) - ambient
        steady_k[n["id"]] = float(n["power_kw"]) / delta if delta > 1.0 else float(physics["default_removal_kw_per_c"])

    k: dict[str, float] = {}
    for n in snap["nodes"]:
        if n["id"] in steady_k:
            k[n["id"]] = steady_k[n["id"]]
            continue
        peers = [steady_k[m["id"]] for m in snap["nodes"] if m["zone_id"] == n["zone_id"] and m["id"] in steady_k]
        ref = median(peers) if peers else float(physics["default_removal_kw_per_c"])
        if "cooling_efficiency" in n:
            eff = float(n["cooling_efficiency"])
        elif "fan_issue" in n["flags"]:
            eff = float(physics["fan_issue_efficiency"])
        else:
            eff = float(physics["rising_efficiency"])
        k[n["id"]] = ref * eff

    return {
        "job_kw": job_kw,
        "job_util": job_util,
        "k": k,
        "zone_level0": {z["id"]: int(z["cooling_level"]) for z in snap["zones"]},
    }


def simulate(
    snap: dict,
    physics: dict,
    policy: dict,
    action: dict | None = None,
    *,
    capture_s: float | None = None,
) -> dict[str, Any]:
    """action = Candidate 형태({"id","type","params"}) 또는 None(조치 없음)."""
    a_type = action["type"] if action else None
    params = (action or {}).get("params") or {}
    physical = a_type in PHYSICAL_TYPES

    dt = float(physics["dt_s"])
    ticks = int(physics["rollout_ticks"])
    ambient = float(physics["ambient_temp_c"])
    cap = float(physics["thermal_capacity_kj_per_c"])
    idle = float(physics["idle_heat_kw"])
    idle_util = float(physics["idle_util_pct"])
    gain = float(physics["cooling_gain_per_level"])
    limit_c, throttle_c = policy_limits(policy)
    throttle_factor = float(physics["throttle_speed_factor"])
    apply_at = float(physics["approval_wait_s"]) if physical else 0.0

    cal = calibrate(snap, physics)
    nodes = node_map(snap)
    temps = {nid: float(n["temp_c"]) for nid, n in nodes.items()}
    levels = dict(cal["zone_level0"])

    jobs: dict[str, dict] = {}
    for j in snap["jobs"]:
        rem = float(j["remaining_min"]) * 60.0
        active = j["status"] == "running" and j["node_id"] is not None
        jobs[j["id"]] = {
            "id": j["id"], "priority": j["priority"], "node": j["node_id"], "gpus": int(j["gpus"]),
            "remaining": rem,
            "deadline": float(j["deadline_min"]) * 60.0 if j.get("deadline_min") is not None else None,
            "restart_s": float(j.get("restart_cost_min") or 0.0) * 60.0,
            "resume_at": 0.0 if active else float("inf"),
            "status": j["status"],
            "done": j["status"] == "done" or rem <= 0.0,
            "finish_s": 0.0 if (j["status"] == "done" or rem <= 0.0) else None,
            "completed": 0.0, "throttled_s": 0.0,
        }

    def cop_of(zone_id: str) -> float:
        drop = float(physics["cop_drop_per_level"]) * (levels[zone_id] - cal["zone_level0"][zone_id])
        return max(float(physics["cop_min"]), float(physics["cop_base"]) - drop)

    def level_factor(zone_id: str) -> float:
        return max(0.1, 1.0 + gain * (levels[zone_id] - cal["zone_level0"][zone_id]))

    series: dict[str, list[float]] = {nid: [temps[nid]] for nid in nodes}
    peak = {nid: temps[nid] for nid in nodes}
    peak_time = {nid: 0.0 for nid in nodes}
    reach_limit_s: float | None = None
    reach_throttle_s: float | None = None
    cooling_kwh = it_kwh = 0.0
    zone_cooling_kwh = {z["id"]: 0.0 for z in snap["zones"]}
    peak_total_kw = 0.0
    applied_at: float | None = None
    captured: dict | None = None

    def capture(t: float) -> dict:
        node_state = {}
        for nid, n in nodes.items():
            running = [j for j in jobs.values() if j["node"] == nid and not j["done"] and j["resume_at"] <= t]
            present = [j for j in jobs.values() if j["node"] == nid and not j["done"]]
            heat = idle + sum(cal["job_kw"].get(j["id"], 0.0) for j in running)
            util = sum(cal["job_util"].get(j["id"], 0.0) for j in running) or idle_util
            prev = series[nid][-2] if len(series[nid]) >= 2 else series[nid][-1]
            node_state[nid] = {
                "temp_c": temps[nid], "power_kw": heat, "gpu_util_pct": util,
                "gpus_used": sum(j["gpus"] for j in present),
                "job_ids": [j["id"] for j in present],
                "rising": temps[nid] - prev >= float(physics["rising_flag_delta_c"]),
            }
        job_state = {
            j["id"]: {
                "node": None if (j["resume_at"] > t and j["status"] == "deferred") else j["node"],
                "remaining_s": j["remaining"],
                "status": "done" if j["done"] else ("running" if j["resume_at"] <= t else j["status"]),
            }
            for j in jobs.values()
        }
        return {"t_s": t, "nodes": node_state, "jobs": job_state, "levels": dict(levels)}

    for tick in range(ticks):
        t = tick * dt
        if physical and applied_at is None and t >= apply_at:
            applied_at = t
            if a_type == "cooling_change":
                levels[params["zone"]] = int(params["to"])
            elif a_type == "job_migrate":
                job = jobs[params["job"]]
                if not job["done"]:
                    job["node"] = params["to"]
                    job["resume_at"] = t + job["restart_s"]
                    job["status"] = "queued"
            elif a_type == "job_defer":
                job = jobs[params["job"]]
                if not job["done"]:
                    job["resume_at"] = t + float(params.get("minutes", 0)) * 60.0
                    job["status"] = "deferred"

        if capture_s is not None and captured is None and t >= capture_s:
            captured = capture(t)

        tick_total_kw = 0.0
        next_temps: dict[str, float] = {}
        for nid, n in nodes.items():
            running = [j for j in jobs.values() if j["node"] == nid and not j["done"] and j["resume_at"] <= t]
            temp = temps[nid]
            zone = n["zone_id"]
            heat_kw = idle + sum(cal["job_kw"].get(j["id"], 0.0) for j in running)
            removed_kw = max(0.0, cal["k"][nid] * level_factor(zone) * (temp - ambient))
            cooling_kw = removed_kw / cop_of(zone)

            it_kwh += heat_kw * dt / 3600.0
            cooling_kwh += cooling_kw * dt / 3600.0
            zone_cooling_kwh[zone] += cooling_kw * dt / 3600.0
            tick_total_kw += heat_kw + cooling_kw

            throttled = temp >= throttle_c
            speed = throttle_factor if throttled else 1.0
            for j in running:
                j["status"] = "running"
                work = dt * speed
                if throttled:
                    j["throttled_s"] += min(dt, j["remaining"] / speed)
                if j["remaining"] <= work:
                    j["finish_s"] = t + j["remaining"] / speed
                    j["completed"] += j["remaining"]
                    j["remaining"] = 0.0
                    j["done"] = True
                    j["status"] = "done"
                else:
                    j["remaining"] -= work
                    j["completed"] += work
            next_temps[nid] = temp + dt * (heat_kw - removed_kw) / cap

        peak_total_kw = max(peak_total_kw, tick_total_kw)
        temps = next_temps
        for nid, temp in temps.items():
            series[nid].append(temp)
            if temp > peak[nid]:
                peak[nid], peak_time[nid] = temp, t + dt
            if reach_limit_s is None and temp > limit_c:
                reach_limit_s = t + dt
            if reach_throttle_s is None and temp >= throttle_c:
                reach_throttle_s = t + dt

    horizon = ticks * dt
    if capture_s is not None and captured is None:
        captured = capture(horizon)

    job_out: dict[str, dict] = {}
    for j in jobs.values():
        if j["done"]:
            finish, projected = j["finish_s"], False
        elif j["resume_at"] == float("inf"):
            finish, projected = None, True
        else:
            finish = max(horizon, j["resume_at"]) + j["remaining"]
            projected = True
        lateness = max(0.0, finish - j["deadline"]) if (finish is not None and j["deadline"] is not None) else 0.0
        job_out[j["id"]] = {
            "priority": j["priority"], "node": j["node"], "gpus": j["gpus"],
            "finish_s": finish, "finish_projected": projected,
            "deadline_s": j["deadline"],
            "deadline_met": lateness <= 1e-9,
            "lateness_s": lateness,
            "slack_s": (j["deadline"] - finish) if (finish is not None and j["deadline"] is not None) else None,
            "completed_in_rollout": j["done"],
            "completed_work_s": j["completed"], "remaining_s": j["remaining"],
            "throttled_s": j["throttled_s"], "status": j["status"],
        }

    hottest = max(peak, key=lambda nid: peak[nid])
    cap_kw = (snap.get("site") or {}).get("power_cap_kw")
    return {
        "action_id": action["id"] if action else None,
        "action_type": a_type,
        "applied_at_s": applied_at,
        "ticks": ticks, "dt_s": dt, "horizon_s": horizon,
        "limit_c": limit_c, "throttle_c": throttle_c,
        "series": series,
        "peak_by_node": peak, "peak_time_by_node": peak_time,
        "peak_temp_c": peak[hottest], "peak_node": hottest, "peak_time_s": peak_time[hottest],
        "reach_limit_s": reach_limit_s, "reach_throttle_s": reach_throttle_s,
        "violates_limit": peak[hottest] > limit_c,
        "throttle_job_s": sum(j["throttled_s"] for j in jobs.values()),
        "cooling_kwh": cooling_kwh, "zone_cooling_kwh": zone_cooling_kwh,
        "it_kwh": it_kwh, "total_kwh": cooling_kwh + it_kwh,
        "peak_total_kw": peak_total_kw,
        "power_cap_kw": cap_kw,
        "power_cap_excess_kw": max(0.0, peak_total_kw - cap_kw) if cap_kw else 0.0,
        "jobs": job_out,
        "deadline_misses": [jid for jid, j in job_out.items() if not j["deadline_met"]],
        "total_lateness_s": sum(j["lateness_s"] for j in job_out.values()),
        "jobs_completed": sum(1 for j in job_out.values() if j["completed_in_rollout"]),
        "completed_work_gpu_s": sum(j["completed_work_s"] * j["gpus"] for j in job_out.values()),
        "remaining_work_gpu_s": sum(j["remaining_s"] * j["gpus"] for j in job_out.values()),
        "captured": captured,
    }

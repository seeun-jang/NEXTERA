"""Zoro-1 어댑터.

- Zoro1HttpAdapter : trida-stack `serve.py --mode decide` 서버 (POST /v1/decide)
- Zoro1LocalAdapter: 단일 파일 zoro_decide.py 의 Decider("trillionlabs/Zoro-1") 를 프로세스 안에서 1회 로드

두 어댑터는 같은 request 형식({"state", "questions"})과 같은 검증·에스컬레이션 로직(_Zoro1Base)을 쓴다.
전송 방식(_call)만 다르므로 SGLang 서버에 문제가 생기면 provider 이름만 바꿔 교체할 수 있다.
"""
from __future__ import annotations

import copy
import inspect
import json
import os
import socket
import sys
import threading
import time
import urllib.error
import urllib.request
from typing import Any

from .base import (
    DecisionProvider,
    DecisionResult,
    ProviderContext,
    ProviderError,
    answer_confidence,
    validate_answers,
)

_REASONING_KEYS = ("reasoning", "thinking", "reasoning_text", "reasoning_content")


def extract_reasoning_text(raw: Any) -> str | None:
    """응답 어디에 있든 추론 텍스트(<think>…)를 찾아 문자열로 모은다. 없으면 None."""
    found: list[str] = []

    def visit(obj: Any, key: str = "") -> None:
        if isinstance(obj, str):
            if key in _REASONING_KEYS or "<think>" in obj:
                if obj.strip():
                    found.append(obj)
        elif isinstance(obj, dict):
            for k, v in obj.items():
                visit(v, k)
        elif isinstance(obj, list):
            for v in obj:
                visit(v, key)

    visit(raw)
    return "\n\n".join(found) if found else None


class _Zoro1Base(DecisionProvider):
    name = "zoro1"

    def __init__(self, decision_cfg: dict, fault_mode: str | None = None):
        self.cfg = decision_cfg["zoro1"]
        self.tol = float(decision_cfg["prob_sum_tolerance"])
        # 에스컬레이션을 걸 질문. 비어 있으면 모든 질문(공식 패턴). 기본은 행동 선택만:
        # 실측에서 score 질문은 확률이 자주 갈려 매번 30초대 추론 재호출을 유발했다.
        self.escalation_questions = list(decision_cfg.get("escalation_questions") or [])
        # 시연용 장애 주입: "timeout" | "invalid" | "unreachable". 모델을 부르지 않고 해당 오류를 낸다.
        self.fault_mode = fault_mode

    # 하위 클래스가 구현: 원본 응답 dict 와 경고 목록을 반환, 실패 시 ProviderError
    def _call(self, request: dict, *, reasoning: bool, max_reasoning_tokens: int,
              temperature: float | None) -> tuple[dict, list[str]]:
        raise NotImplementedError

    def _timed_call(self, request: dict, **kw) -> tuple[dict, list[str], float]:
        t0 = time.perf_counter()
        raw, warnings = self._call(request, **kw)
        return raw, warnings, round((time.perf_counter() - t0) * 1000.0, 2)

    def decide(self, request: dict, ctx: ProviderContext, *, enable_escalation: bool = False,
               escalation_threshold: float = 0.7, temperature: float | None = None) -> DecisionResult:
        questions = request["questions"]
        if self.fault_mode:
            kind = {"timeout": "timeout", "invalid": "invalid_response", "unreachable": "unreachable"}.get(self.fault_mode, "timeout")
            raise ProviderError(kind, f"시연용 장애 주입({self.fault_mode}): 모델을 호출하지 않았습니다", self.name)
        if temperature is None:
            temperature = self.cfg.get("temperature")  # None 이면 서버 기본 보정 온도 사용
        max_tokens = int(self.cfg["max_reasoning_tokens"])
        call_kw = {"max_reasoning_tokens": max_tokens, "temperature": temperature}

        # ---- 1) 직접 모드 1회 호출
        raw, warnings, latency = self._timed_call(request, reasoning=False, **call_kw)
        if not isinstance(raw, dict) or "answers" not in raw:
            raise ProviderError("invalid_response", "응답에 'answers' 키가 없음", self.name)
        problems, v_warnings = validate_answers(questions, raw["answers"], self.tol)
        if problems:
            detail = "; ".join(msg for msgs in problems.values() for msg in msgs)
            raise ProviderError("invalid_response", detail, self.name)

        answers = {qid: copy.deepcopy(raw["answers"][qid]) for qid in questions}
        direct_conf = {qid: answer_confidence(a) for qid, a in answers.items()}
        result = DecisionResult(
            provider=self.name,
            decision_mode="direct",
            is_real_model=True,
            answers=answers,
            direct_answers=copy.deepcopy(answers),
            confidences=dict(direct_conf),
            direct_confidences=dict(direct_conf),
            latency_ms=latency,
            latency_breakdown_ms={"direct": latency},
            raw_extra_fields={"direct": {k: v for k, v in raw.items() if k != "answers"}},
            reasoning_text=extract_reasoning_text(raw),
            warnings=warnings + v_warnings,
            request_options={
                "enable_escalation": enable_escalation,
                "escalation_threshold": escalation_threshold,
                "temperature": temperature if temperature is not None else "server_default",
                "max_reasoning_tokens": max_tokens,
            },
        )

        # ---- 2) 신뢰도 기반 에스컬레이션 (공식 패턴: 전체 요청을 추론 모드로 1회 재호출, 불확실한 답만 교체)
        watched = self.escalation_questions or list(direct_conf)
        unsure = [qid for qid, c in direct_conf.items() if qid in watched and c is not None and c < escalation_threshold]
        if not (enable_escalation and unsure):
            return result
        try:
            raw2, warnings2, latency2 = self._timed_call(request, reasoning=True, **call_kw)
        except ProviderError as e:
            result.errors.append({"stage": "escalation", **e.to_dict()})
            result.warnings.append("에스컬레이션 호출 실패: 직접 모드 답변 유지")
            return result

        result.latency_breakdown_ms["escalated"] = latency2
        result.latency_ms = round(latency + latency2, 2)
        result.warnings.extend(warnings2)
        if isinstance(raw2, dict):
            result.raw_extra_fields["escalated"] = {k: v for k, v in raw2.items() if k != "answers"}
            result.reasoning_text = extract_reasoning_text(raw2) or result.reasoning_text
        answers2 = raw2.get("answers") if isinstance(raw2, dict) else None
        problems2, _ = validate_answers(questions, answers2, self.tol, only=unsure)
        updated = [qid for qid in unsure if qid not in problems2 and "_response" not in problems2]
        for qid in updated:
            result.answers[qid] = copy.deepcopy(answers2[qid])
            result.confidences[qid] = answer_confidence(answers2[qid])
        if problems2:
            detail = "; ".join(msg for msgs in problems2.values() for msg in msgs)
            result.errors.append({"stage": "escalation", "kind": "invalid_response", "detail": detail, "source": self.name})
        if updated:
            result.decision_mode = "escalated_reasoned"
            result.escalated_questions = updated
        return result


class Zoro1HttpAdapter(_Zoro1Base):
    name = "zoro1_http"

    def __init__(self, decision_cfg: dict, url: str | None = None, fault_mode: str | None = None):
        super().__init__(decision_cfg, fault_mode=fault_mode)
        self.url = url or os.environ.get("ZORO1_URL") or self.cfg["url"]
        # 내부 서버 호출이므로 환경의 HTTP 프록시를 타지 않게 한다
        self._opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))

    def _call(self, request, *, reasoning, max_reasoning_tokens, temperature):
        payload: dict[str, Any] = {
            "request": request,
            "reasoning": bool(reasoning),
            "max_reasoning_tokens": int(max_reasoning_tokens),
        }
        if temperature is not None:
            payload["temperature"] = float(temperature)
        timeout = float(self.cfg["reasoning_timeout_s"] if reasoning else self.cfg["timeout_s"])
        req = urllib.request.Request(
            self.url,
            data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with self._opener.open(req, timeout=timeout) as resp:
                body = resp.read()
        except urllib.error.HTTPError as e:
            text = e.read().decode("utf-8", "replace")[:300]
            raise ProviderError("http_error", f"HTTP {e.code} from {self.url}: {text}", self.name) from e
        except urllib.error.URLError as e:
            if isinstance(e.reason, (socket.timeout, TimeoutError)):
                raise ProviderError("timeout", f"{timeout}s 안에 응답 없음: {self.url}", self.name) from e
            raise ProviderError("unreachable", f"{self.url} 접속 실패: {e.reason}", self.name) from e
        except (socket.timeout, TimeoutError) as e:
            raise ProviderError("timeout", f"{timeout}s 안에 응답 없음: {self.url}", self.name) from e
        except OSError as e:
            raise ProviderError("unreachable", f"{self.url} 접속 실패: {e}", self.name) from e
        try:
            return json.loads(body.decode("utf-8")), []
        except (UnicodeDecodeError, json.JSONDecodeError) as e:
            raise ProviderError("bad_json", f"JSON 파싱 실패: {e}", self.name) from e


class Zoro1LocalAdapter(_Zoro1Base):
    """zoro_decide.py 의 Decider 를 프로세스당 1회 로드해 재사용한다.

    zoro_decide.py 가 import 경로에 없으면 환경변수 ZORO1_SNAPSHOT_DIR(모델 스냅샷 폴더)를 sys.path 에 추가한다.
    공식 호출 형태: Decider("trillionlabs/Zoro-1").decide(request, image=None, reasoning=...)
    """
    name = "zoro1_local"
    _decider = None
    _lock = threading.Lock()

    def _get_decider(self):
        cls = type(self)
        with cls._lock:
            if cls._decider is None:
                snap = os.environ.get("ZORO1_SNAPSHOT_DIR")
                if snap and snap not in sys.path:
                    sys.path.insert(0, snap)
                try:
                    from zoro_decide import Decider  # type: ignore
                    # ZORO1_MODEL 로 저장소 ID 대신 로컬 스냅샷 경로를 줄 수 있다
                    cls._decider = Decider(os.environ.get("ZORO1_MODEL") or self.cfg["model_id"])
                except Exception as e:  # ImportError, 가중치 로드 실패 등
                    raise ProviderError("load_error", f"Decider 로드 실패: {type(e).__name__}: {e}", self.name) from e
            return cls._decider

    def preload(self) -> None:
        """서버 시작 때 모델을 미리 올린다(첫 판단이 느려지지 않게)."""
        self._get_decider()

    def _call(self, request, *, reasoning, max_reasoning_tokens, temperature):
        decider = self._get_decider()
        warnings: list[str] = []
        kwargs: dict[str, Any] = {"reasoning": bool(reasoning)}
        params = inspect.signature(decider.decide).parameters
        accepts_any = any(p.kind is inspect.Parameter.VAR_KEYWORD for p in params.values())
        for key, value in (("max_reasoning_tokens", max_reasoning_tokens if reasoning else None),
                           ("temperature", temperature)):
            if value is None:
                continue
            if key in params or accepts_any:
                kwargs[key] = value
            else:
                warnings.append(f"Decider.decide 가 '{key}' 인자를 받지 않아 전달하지 않음")
        try:
            with type(self)._lock:
                out = decider.decide(request, **kwargs)
        except Exception as e:
            raise ProviderError("runtime_error", f"Decider.decide 실패: {type(e).__name__}: {e}", self.name) from e
        if isinstance(out, dict) and "answers" not in out:
            out = {"answers": out}
        return out, warnings

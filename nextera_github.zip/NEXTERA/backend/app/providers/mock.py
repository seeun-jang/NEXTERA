"""MockDecisionProvider — 모델 없이 통합 개발을 이어 가기 위한 모의 응답.

선택은 규칙 기준선과 같은 논리로 고르되, 결과는 반드시 provider "mock"·fallback_reason "MOCK_MODE" 로 표시된다.
실제 Zoro-1 호출로 보고되는 일이 없도록 is_real_model 은 항상 False 다.
"""
from __future__ import annotations

from .base import DecisionProvider, DecisionResult, ProviderContext
from .rule_baseline import RuleBaselineProvider


class MockDecisionProvider(DecisionProvider):
    name = "mock"

    def __init__(self, decision_cfg: dict):
        self._rule = RuleBaselineProvider(decision_cfg, mode="mock")

    def decide(self, request: dict, ctx: ProviderContext, *, enable_escalation: bool = False,
               escalation_threshold: float = 0.7, temperature: float | None = None) -> DecisionResult:
        result = self._rule.decide(request, ctx)
        result.provider = self.name
        result.decision_mode = "mock"
        result.is_mock = True
        result.is_fallback = False
        result.is_real_model = False
        return result

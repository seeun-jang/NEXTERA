"""규칙 기준선(RuleBaseline). 모델이 없거나 실패했을 때의 폴백이자, 평가에서 Zoro-1 과 비교하는 기준이다.

순서(C1): Safety Gate 통과(필수 규칙 위반 0) → 정책 목표 순서(decision_config.rule_baseline.objective_orders).
기본(balanced): 마감 준수 → 전력 상한 초과 → 스로틀 시간 → 완료 작업량 → 냉각 kWh → 최고 온도.
확률은 모델 확률이 아니라 1.0/0.0 으로 채운 값이며 synthetic=True 로 표시한다.
"""
from __future__ import annotations

import time

from .base import DecisionProvider, DecisionResult, ProviderContext, ProviderError


def objective_metrics(sim: dict, ctx_cfg: dict, primary_job: str | None) -> dict[str, float]:
    weights = ctx_cfg["rule_baseline"]["priority_weights"]
    miss = sum(weights.get(sim["jobs"][jid]["priority"], 1) for jid in sim["deadline_misses"])
    primary = sim["jobs"].get(primary_job) if primary_job else None
    return {
        "deadline_miss_weighted": float(miss),
        "total_lateness_s": sim["total_lateness_s"],
        "power_cap_excess_kw": sim["power_cap_excess_kw"],
        "throttle_job_s": sim["throttle_job_s"],
        "neg_completed_work_gpu_s": -sim["completed_work_gpu_s"],
        "cooling_kwh": sim["cooling_kwh"],
        "peak_temp_c": sim["peak_temp_c"],
        "primary_finish_s": primary["finish_s"] if primary and primary["finish_s"] is not None else float("inf"),
    }


def objective_key(sim: dict, hard: list[str], decision_cfg: dict, objective: str, primary_job: str | None) -> tuple:
    orders = decision_cfg["rule_baseline"]["objective_orders"]
    order = orders.get(objective) or orders["balanced"]
    m = objective_metrics(sim, decision_cfg, primary_job)
    return (len(hard),) + tuple(round(m[k], 4) for k in order)


def rank(ctx: ProviderContext) -> list[tuple[str, tuple]]:
    keyed = [
        (c["id"], objective_key(ctx.sims[c["id"]], ctx.hard.get(c["id"], []), ctx.decision_cfg, ctx.objective, ctx.primary_job))
        for c in ctx.options
    ]
    return sorted(keyed, key=lambda x: (x[1], x[0]))


def explain(ctx: ProviderContext, chosen: str) -> str:
    rejected = [c["id"] for c in ctx.options if ctx.hard.get(c["id"])]
    if ctx.hard.get(chosen):
        return f"규칙 기준선: 필수 규칙을 지키는 실행 후보가 없습니다 (위반: {', '.join(rejected)})."
    sim = ctx.sims[chosen]
    label = next(c["label"] for c in ctx.options if c["id"] == chosen)
    parts = [f"예측 최고 {sim['peak_temp_c']:.1f}°C", f"냉각 {sim['cooling_kwh']:.3f} kWh"]
    primary = sim["jobs"].get(ctx.primary_job) if ctx.primary_job else None
    if primary and primary["finish_s"] is not None:
        parts.append(f"{ctx.primary_job} 완료 {primary['finish_s'] / 60.0:.1f}분")
    tail = f" 필수 규칙 위반으로 제외: {', '.join(rejected)}." if rejected else ""
    return f"규칙 기준선: 필수 규칙을 지키는 후보 중 정책 목표 순서({ctx.objective})로 '{label}'을(를) 골랐습니다 ({' · '.join(parts)}).{tail}"


class RuleBaselineProvider(DecisionProvider):
    name = "rule_baseline"

    def __init__(self, decision_cfg: dict, mode: str = "rule_baseline"):
        self.cfg = decision_cfg
        self.mode = mode  # "rule_baseline"(직접 실행) | "rule_fallback"(모델 실패 후)

    def decide(self, request: dict, ctx: ProviderContext, *, enable_escalation: bool = False,
               escalation_threshold: float = 0.7, temperature: float | None = None) -> DecisionResult:
        t0 = time.perf_counter()
        if not ctx.options:
            raise ProviderError("invalid_response", "선택할 후보가 없음", self.name)
        ranked = rank(ctx)
        chosen = ranked[0][0]
        answers: dict[str, dict] = {}
        for qid, q in request["questions"].items():
            if q["type"] == "choice":
                answers[qid] = {
                    "type": "choice", "choice": chosen, "confidence": 1.0, "synthetic": True,
                    "probabilities": {cid: (1.0 if cid == chosen else 0.0) for cid in q["criteria"]},
                    "ranking": [cid for cid, _ in ranked],
                }
            elif q["type"] == "noul":
                keywords = self.cfg["rule_baseline"]["memo_risk_keywords"]
                text = " ".join(n.get("text", "") for n in ctx.snapshot.get("notes", [])).lower()
                hit = any(k.lower() in text for k in keywords)
                answers[qid] = {"type": "noul", "noul": 1.0 if hit else 0.0, "synthetic": True}
            elif q["type"] == "score":
                levels = q["criteria"]
                base = ctx.no_action_sim
                idx = 2 if (base["violates_limit"] or base["deadline_misses"]) else (1 if base["throttle_job_s"] > 0 else 0)
                idx = min(idx, len(levels) - 1)
                answers[qid] = {
                    "type": "score", "score": float(idx), "legend": list(levels), "synthetic": True,
                    "probabilities": {lv: (1.0 if i == idx else 0.0) for i, lv in enumerate(levels)},
                }
        latency = round((time.perf_counter() - t0) * 1000.0, 2)
        return DecisionResult(
            provider=self.name, decision_mode=self.mode, answers=answers,
            is_fallback=self.mode == "rule_fallback",
            confidences={qid: None for qid in answers},
            latency_ms=latency, latency_breakdown_ms={"rule": latency},
            request_options={"objective": ctx.objective},
        )

"""Decision Provider 어댑터.

    zoro1        Zoro1HttpAdapter   (trida-stack serve.py --mode decide, POST /v1/decide)
    zoro1_local  Zoro1LocalAdapter  (zoro_decide.py 의 Decider 를 프로세스 안에서 로드)
    rule         RuleBaselineProvider
    mock         MockDecisionProvider
"""
from __future__ import annotations

from .base import DecisionProvider, DecisionResult, ProviderContext, ProviderError
from .mock import MockDecisionProvider
from .rule_baseline import RuleBaselineProvider
from .zoro1 import Zoro1HttpAdapter, Zoro1LocalAdapter

PROVIDER_NAMES = ("zoro1", "zoro1_local", "rule", "mock")


def get_provider(name: str, decision_cfg: dict, fault_mode: str | None = None) -> DecisionProvider:
    if name == "zoro1":
        return Zoro1HttpAdapter(decision_cfg, fault_mode=fault_mode)
    if name == "zoro1_local":
        return Zoro1LocalAdapter(decision_cfg, fault_mode=fault_mode)
    if name == "rule":
        return RuleBaselineProvider(decision_cfg, mode="rule_baseline")
    if name == "mock":
        return MockDecisionProvider(decision_cfg)
    raise ValueError(f"알 수 없는 provider '{name}'. 사용 가능: {PROVIDER_NAMES}")


__all__ = [
    "DecisionProvider", "DecisionResult", "ProviderContext", "ProviderError",
    "Zoro1HttpAdapter", "Zoro1LocalAdapter", "RuleBaselineProvider", "MockDecisionProvider",
    "get_provider", "PROVIDER_NAMES",
]

"""DecisionProvider 인터페이스, 결과 객체, 응답 검증, 신뢰도 계산."""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import asdict, dataclass, field
from typing import Any

DECISION_MODES = ("direct", "escalated_reasoned", "rule_fallback", "rule_baseline", "mock")

# 계약의 Provider 값(zoro1 | mock | rule)으로의 대응
CONTRACT_PROVIDER = {"direct": "zoro1", "escalated_reasoned": "zoro1", "rule_fallback": "rule", "rule_baseline": "rule",
                     "rule_handoff": "rule", "mock": "mock"}

BADGES = {
    "direct": "ZORO-1",
    "escalated_reasoned": "ZORO-1 · REASONED",
    "rule_fallback": "FALLBACK · RULE",
    "rule_baseline": "RULE",
    "mock": "MOCK",
}


class ProviderError(Exception):
    """모델 호출 실패. kind: unreachable | timeout | http_error | bad_json | invalid_response | load_error | not_configured"""

    def __init__(self, kind: str, detail: str, source: str = ""):
        super().__init__(f"[{kind}] {detail}")
        self.kind = kind
        self.detail = detail
        self.source = source

    def to_dict(self) -> dict:
        return {"kind": self.kind, "detail": self.detail, "source": self.source}


@dataclass
class ProviderContext:
    """규칙 기반 provider 가 쓰는 부가 정보. Zoro-1 어댑터는 request 만 사용한다."""
    options: list[dict]                 # 선택 대상 후보(Candidate)
    sims: dict[str, dict]               # 후보별 시뮬레이션
    no_action_sim: dict                 # 조치 없음 시뮬레이션
    hard: dict[str, list[str]]          # 후보별 필수 규칙 위반 목록(Safety Gate)
    snapshot: dict
    decision_cfg: dict
    objective: str = "balanced"
    primary_job: str | None = None


@dataclass
class DecisionResult:
    provider: str
    decision_mode: str
    answers: dict[str, dict]
    is_fallback: bool = False
    is_mock: bool = False
    is_real_model: bool = False
    direct_answers: dict[str, dict] | None = None
    escalated_questions: list[str] = field(default_factory=list)
    confidences: dict[str, float | None] = field(default_factory=dict)
    direct_confidences: dict[str, float | None] = field(default_factory=dict)
    latency_ms: float = 0.0
    latency_breakdown_ms: dict[str, float] = field(default_factory=dict)
    raw_extra_fields: dict[str, Any] = field(default_factory=dict)
    reasoning_text: str | None = None
    errors: list[dict] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    request_options: dict[str, Any] = field(default_factory=dict)

    @property
    def badge(self) -> str:
        return BADGES.get(self.decision_mode, self.decision_mode.upper())

    def to_dict(self) -> dict:
        d = asdict(self)
        d["badge"] = self.badge
        return d


class DecisionProvider(ABC):
    name: str = "base"

    @abstractmethod
    def decide(
        self,
        request: dict,
        ctx: ProviderContext,
        *,
        enable_escalation: bool = False,
        escalation_threshold: float = 0.7,
        temperature: float | None = None,
    ) -> DecisionResult:
        """request = {"state": ..., "questions": ...}. 실패 시 ProviderError 를 던진다."""


# ---------------------------------------------------------------- 신뢰도

def _prob_values(probs: Any) -> list[float] | None:
    if isinstance(probs, dict):
        return list(probs.values())
    if isinstance(probs, (list, tuple)):
        return list(probs)
    return None


def answer_confidence(answer: dict) -> float | None:
    """공식 패턴: noul 은 max(p, 1-p), choice·score 는 max(probabilities)."""
    if "noul" in answer and isinstance(answer["noul"], (int, float)):
        p = float(answer["noul"])
        return max(p, 1.0 - p)
    vals = _prob_values(answer.get("probabilities"))
    if vals:
        return float(max(vals))
    return None


# ------------------------------------------------------------------ 검증

def _is_num(x: Any) -> bool:
    return isinstance(x, (int, float)) and not isinstance(x, bool) and x == x  # NaN 제외


def _criteria_ids(question: dict) -> list[str]:
    crit = question.get("criteria")
    if isinstance(crit, dict):
        return list(crit.keys())
    return []


def validate_answer(qid: str, question: dict, answer: Any, tol: float) -> tuple[list[str], list[str]]:
    """(errors, warnings). errors 가 비어 있어야 유효."""
    errors: list[str] = []
    warnings: list[str] = []
    qtype = question["type"]
    if not isinstance(answer, dict):
        return [f"{qid}: 답변이 객체가 아님"], warnings

    def check_probs(vals: list, label: str) -> None:
        if not vals or not all(_is_num(v) for v in vals):
            errors.append(f"{qid}: {label} 확률 값이 숫자가 아님")
            return
        if any(v < 0.0 or v > 1.0 for v in vals):
            errors.append(f"{qid}: {label} 확률이 [0,1] 범위를 벗어남")
        total = sum(vals)
        if abs(total - 1.0) > tol:
            errors.append(f"{qid}: {label} 확률 합 {total:.4f} (허용 오차 ±{tol})")

    if qtype == "choice":
        ids = _criteria_ids(question)
        choice = answer.get("choice")
        probs = answer.get("probabilities")
        if choice not in ids:
            errors.append(f"{qid}: 선택 ID {choice!r} 가 후보 목록에 없음")
        if not isinstance(probs, dict):
            errors.append(f"{qid}: probabilities 누락 또는 형식 오류")
        else:
            missing = [i for i in ids if i not in probs]
            unknown = [k for k in probs if k not in ids]
            if missing:
                errors.append(f"{qid}: 확률 누락 ID {missing}")
            if unknown:
                errors.append(f"{qid}: 알 수 없는 ID {unknown}")
            if not missing and not unknown:
                check_probs(list(probs.values()), "choice")
                if not errors and probs[choice] < max(probs.values()) - 1e-6:
                    errors.append(f"{qid}: choice {choice!r} 가 최고 확률 후보가 아님")
    elif qtype == "noul":
        p = answer.get("noul")
        if not _is_num(p) or not 0.0 <= p <= 1.0:
            errors.append(f"{qid}: noul 값 {p!r} 가 [0,1] 범위의 숫자가 아님")
    elif qtype == "score":
        s = answer.get("score")
        levels = question.get("criteria") or []
        n = len(levels)
        if not _is_num(s) or s < -1e-6 or (n and s > (n - 1) + 1e-6):
            errors.append(f"{qid}: score 값 {s!r} 가 [0,{max(n - 1, 0)}] 범위의 숫자가 아님")
        vals = _prob_values(answer.get("probabilities"))
        if vals is None:
            warnings.append(f"{qid}: score 답변에 probabilities 없음 (신뢰도 계산 불가)")
        else:
            if n and len(vals) != n:
                errors.append(f"{qid}: score 확률 개수 {len(vals)} ≠ 등급 수 {n}")
            check_probs(vals, "score")
    else:
        errors.append(f"{qid}: 알 수 없는 질문 유형 {qtype!r}")
    return errors, warnings


def validate_answers(questions: dict, answers: Any, tol: float, only: list[str] | None = None) -> tuple[dict[str, list[str]], list[str]]:
    """질문별 오류 목록과 경고를 반환한다. 반환 dict 가 비어 있으면 전부 유효."""
    problems: dict[str, list[str]] = {}
    warnings: list[str] = []
    if not isinstance(answers, dict):
        return {"_response": ["answers 가 객체가 아님"]}, warnings
    for qid in (only if only is not None else questions.keys()):
        if qid not in answers:
            problems[qid] = [f"{qid}: 답변 누락"]
            continue
        errs, warns = validate_answer(qid, questions[qid], answers[qid], tol)
        warnings.extend(warns)
        if errs:
            problems[qid] = errs
    return problems, warnings

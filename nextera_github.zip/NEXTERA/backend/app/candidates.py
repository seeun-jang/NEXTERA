"""후보 행동 생성 + 정책 필터.

사건 정의(incidents.json)의 대상에서 후보를 만들고, 정적 필수 규칙으로 거른다.
- POL-01: 보호 우선순위(P0) 작업의 이동·연기
- POL-03: 이동 대상 노드의 여유 GPU 부족
탈락 후보도 목록에 남긴다(filtered_out=True, filter_reason=정책 ID). 예측 온도(POL-02)는 Safety Gate 가 판정한다.
"""
from __future__ import annotations

from .simulator import job_map, node_map

EXECUTABLE_TYPES = ("cooling_change", "job_migrate", "job_defer")
APPROVAL_POLICY = {"job_migrate": "POL-04", "cooling_change": "POL-05", "job_defer": "POL-06"}
P0 = "P0"


def approval_role(policy: dict, action_type: str) -> str | None:
    pid = APPROVAL_POLICY.get(action_type)
    for p in policy["policies"]:
        if p["id"] == pid:
            return (p.get("params") or {}).get("role")
    return None


def build_candidates(snap: dict, incident: dict, policy: dict) -> list[dict]:
    nodes, jobs = node_map(snap), job_map(snap)
    spec = incident["candidates"]
    zones = {z["id"]: z for z in snap["zones"]}
    out: list[dict] = []
    blocked_tail: list[dict] = []

    def cand(cid, ctype, label, params, role, reason=None):
        return {
            "id": cid, "type": ctype, "label": label, "params": params,
            "requires_approval_role": None if reason else role,
            "filtered_out": reason is not None, "filter_reason": reason, "origin": "generated",
        }

    for zid in spec.get("cooling_zones", []):
        z = zones[zid]
        if z["cooling_level"] < z["cooling_max"]:
            lv = z["cooling_level"]
            out.append(cand(f"A-COOL-{zid}-UP", "cooling_change", f"{zid} 냉각 강화 (레벨 {lv} → {lv + 1})",
                            {"zone": zid, "from": lv, "to": lv + 1}, approval_role(policy, "cooling_change")))

    for m in spec.get("migrate", []):
        job = jobs[m["job"]]
        for target in m["targets"]:
            free = nodes[target]["gpus_free"]
            reason = "POL-01" if job["priority"] == P0 else ("POL-03" if free < job["gpus"] else None)
            c = cand(f"A-MIG-{job['id']}-{target}", "job_migrate", f"{job['id']}을 {target}로 이동",
                     {"job": job["id"], "to": target, "gpus": job["gpus"]}, approval_role(policy, "job_migrate"), reason)
            # 탈락해도 승인 역할 정보는 남긴다(강제 입력 검사 화면에서 사용)
            c["requires_approval_role"] = approval_role(policy, "job_migrate")
            (blocked_tail if reason else out).append(c)

    for d in spec.get("defer", []):
        job = jobs[d["job"]]
        minutes = d.get("minutes")
        if job["priority"] == P0:
            blocked_tail.append(cand(f"A-DEF-{job['id']}", "job_defer", f"{job['id']}({job['priority']}) 연기",
                                     {"job": job["id"]}, None, "POL-01"))
        else:
            out.append(cand(f"A-DEF-{job['id']}-{minutes}", "job_defer", f"{job['id']}({job['priority']}) {minutes}분 연기",
                            {"job": job["id"], "minutes": minutes}, approval_role(policy, "job_defer")))

    out.append(cand("A-INFO", "request_info", "추가 정보 요청", {}, None))
    out.append(cand("A-ESC", "escalate", "운영자 호출 (이관)", {}, None))
    return out + blocked_tail


def executable(candidates: list[dict]) -> list[dict]:
    """정책 필터를 통과했고 실제 상태를 바꾸는 후보."""
    return [c for c in candidates if not c["filtered_out"] and c["type"] in EXECUTABLE_TYPES]


def find(candidates: list[dict], action_id: str) -> dict | None:
    return next((c for c in candidates if c["id"] == action_id), None)

"""ASGI 앱. 실행: uvicorn app.main:app --host 0.0.0.0 --port 8000   (backend/ 폴더에서)

- /api/*  : 계약 v1 API (api.dispatch)
- 그 밖   : 빌드된 프론트(frontend/dist) 정적 파일. 없는 경로는 index.html 로 돌려 새로고침해도 화면이 열린다.

FastAPI 가 설치되어 있으면 FastAPI 앱으로, 없으면 같은 코드가 Starlette 앱으로 뜬다(FastAPI 는 Starlette 위에 있다).

환경변수
  NEXTERA_PROVIDER   zoro1(기본) | zoro1_local | rule | mock
  ZORO1_URL          Zoro-1 서버 주소 (기본 http://localhost:30001/v1/decide)
  NEXTERA_DB         SQLite 파일 경로 (기본 backend/nextera.db)
  NEXTERA_DIST       프론트 빌드 폴더 (기본 ../frontend/dist)
  NEXTERA_CORS       허용 출처, 쉼표 구분 (기본 *). 같은 서버에서 프론트를 서빙하면 필요 없다.
"""
from __future__ import annotations

import json
import logging
import os
import threading
from pathlib import Path

from starlette.concurrency import run_in_threadpool
from starlette.middleware.cors import CORSMiddleware
from starlette.requests import Request
from starlette.responses import FileResponse, JSONResponse, Response

from . import CONTRACT_VERSION, api
from .config import REPO_DIR
from .service import NexteraService

try:  # FastAPI 가 있으면 FastAPI 로, 없으면 Starlette 로
    from fastapi import FastAPI as _App

    _app_kwargs = {"title": "NEXTERA API", "version": CONTRACT_VERSION, "docs_url": "/api/docs", "openapi_url": "/api/openapi.json"}
except ImportError:  # pragma: no cover - 설치 환경에 따라
    from starlette.applications import Starlette as _App

    _app_kwargs = {}

logging.basicConfig(level=os.environ.get("NEXTERA_LOG", "INFO"))
log = logging.getLogger("nextera")

DIST = Path(os.environ.get("NEXTERA_DIST") or REPO_DIR / "frontend" / "dist")

app = _App(**_app_kwargs)
app.add_middleware(
    CORSMiddleware,
    allow_origins=[o.strip() for o in os.environ.get("NEXTERA_CORS", "*").split(",") if o.strip()],
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["Content-Type", "X-Role", "X-Session"],
)

_service: NexteraService | None = None
_service_lock = threading.Lock()


def get_service() -> NexteraService:
    global _service
    with _service_lock:
        if _service is None:
            _service = NexteraService()
            log.info("NEXTERA 서비스 시작: provider=%s incident=%s", _service.provider_mode, _service.incident["id"])
        return _service


async def api_endpoint(request: Request) -> Response:
    body = None
    if request.method == "POST":
        raw = await request.body()
        if raw.strip():
            try:
                body = json.loads(raw)
            except (ValueError, UnicodeDecodeError):
                return JSONResponse({"error": {"code": "INVALID_REQUEST", "message": "본문이 올바른 JSON이 아닙니다"}}, status_code=400)
    # 모델 호출·SQLite 가 동기 코드이므로 스레드풀에서 실행한다
    status, payload = await run_in_threadpool(
        api.dispatch, get_service(), request.method, request.url.path, dict(request.query_params), body, dict(request.headers))
    return JSONResponse(payload, status_code=status)


async def spa_endpoint(request: Request) -> Response:
    rel = request.path_params.get("path", "")
    target = (DIST / rel).resolve()
    if rel and target.is_file() and DIST.resolve() in target.parents:
        return FileResponse(target)
    index = DIST / "index.html"
    if index.is_file():
        return FileResponse(index)
    return JSONResponse({"error": {"code": "NOT_FOUND", "message": "프론트 빌드(frontend/dist)가 없습니다. API는 /api 아래에 있습니다."}}, status_code=404)


def _warm_up() -> None:
    """서비스를 만들고, 로컬 Decider 방식이면 모델을 미리 GPU에 올린다. 실패해도 서버는 뜬다(규칙 폴백)."""
    try:
        service = get_service()
        if service.provider_mode == "zoro1_local":
            from .providers import Zoro1LocalAdapter

            log.info("Zoro-1 모델을 미리 로드합니다…")
            Zoro1LocalAdapter(service.decision_cfg).preload()
            log.info("Zoro-1 모델 로드 완료")
    except Exception as e:  # noqa: BLE001
        log.warning("미리 로드 실패(판단 시 다시 시도, 실패하면 규칙 폴백): %s", e)


if os.environ.get("NEXTERA_PRELOAD", "1") != "0":
    threading.Thread(target=_warm_up, daemon=True).start()

app.router.add_route("/api/{path:path}", api_endpoint, methods=["GET", "POST"])
app.router.add_route("/{path:path}", spa_endpoint, methods=["GET"])

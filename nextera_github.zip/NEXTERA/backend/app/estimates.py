"""시뮬레이터 결과 → 계약의 Estimate 객체. 모든 수치는 시뮬레이터가 계산한 값이다."""
from __future__ import annotations


def _r(x: float | None, nd: int = 1) -> float | None:
    return None if x is None else round(float(x), nd)


def to_estimate(sim: dict, baseline: dict, physics: dict, focus_jobs: list[str] | None = None) -> dict:
    """baseline = 같은 스냅샷의 "조치 없음" 시뮬레이션 (냉각 에너지 증감률 기준).

    focus_jobs 를 주면 job_finish_min·deadline_slack_min 에는 그 작업들과, 이 행동 때문에 조치 없음보다
    늦어진 작업만 넣는다. 전체 작업의 값은 all_job_finish_min 에 있다.
    """
    dt_min = sim["dt_s"] / 60.0
    limit_c = sim["limit_c"]
    margin_c = float(physics["risk_margin_c"])

    temp_series = [
        {"node_id": nid, "points": [{"t_min": round(i * dt_min, 2), "temp_c": round(v, 1)} for i, v in enumerate(vals)]}
        for nid, vals in sim["series"].items()
    ]
    all_finish = {jid: _r(j["finish_s"] / 60.0, 1) for jid, j in sim["jobs"].items() if j["finish_s"] is not None}

    def shown(jid: str) -> bool:
        if focus_jobs is None or jid in focus_jobs:
            return True
        base = baseline["jobs"].get(jid, {}).get("finish_s")
        mine = sim["jobs"][jid]["finish_s"]
        return base is not None and mine is not None and mine - base > 3.0  # 이 행동으로 늦어진 작업

    job_finish = {jid: v for jid, v in all_finish.items() if shown(jid)}
    slack = {jid: _r(j["slack_s"] / 60.0, 1) for jid, j in sim["jobs"].items() if j["slack_s"] is not None and shown(jid)}

    violations: list[str] = []
    if sim["violates_limit"]:
        violations.append("POL-02")
    if sim["deadline_misses"]:
        violations.append("DEADLINE_MISS")

    base_cool = baseline["cooling_kwh"]
    delta_pct = round((sim["cooling_kwh"] - base_cool) / base_cool * 100.0, 1) if base_cool > 0 else 0.0
    throttle_min = round(sim["throttle_job_s"] / 60.0, 1)
    peak = sim["peak_temp_c"]
    headroom = limit_c - peak

    if sim["violates_limit"]:
        risk = "high"
        when = sim["reach_limit_s"]
        note = f"약 {when / 60.0:.1f}분 뒤 안전 한계 {limit_c:g}°C 초과" if when is not None else f"안전 한계 {limit_c:g}°C 초과"
    elif sim["deadline_misses"]:
        risk = "high"
        note = "마감 초과: " + ", ".join(f"{jid} {sim['jobs'][jid]['lateness_s'] / 60.0:.1f}분" for jid in sim["deadline_misses"])
    elif throttle_min > 0 or headroom < margin_c:
        risk = "medium"
        note = f"한계까지 {headroom:.1f}°C" + (f" · 스로틀 {throttle_min}분" if throttle_min > 0 else "")
    else:
        risk = "low"
        note = f"최고 {peak:.1f}°C · 한계까지 {headroom:.1f}°C"

    return {
        "action_id": sim["action_id"],
        "horizon_ticks": sim["ticks"],
        "peak_temp_c": {nid: round(v, 1) for nid, v in sim["peak_by_node"].items()},
        "temp_series": temp_series,
        "cooling_kwh": round(sim["cooling_kwh"], 3),
        "cooling_kwh_delta_pct": delta_pct,
        "total_kwh": round(sim["total_kwh"], 3),
        "job_finish_min": job_finish,
        "deadline_slack_min": slack,
        "throttle_min": throttle_min,
        "completed_work": round(sim["completed_work_gpu_s"] / 60.0, 1),   # GPU·분
        "remaining_work": round(sim["remaining_work_gpu_s"] / 60.0, 1),   # GPU·분
        "risk": risk,
        "risk_note": note,
        "violations": violations,
        "source": "sim_estimate",
        # ---- 계약 v1.1 선택 필드
        "peak_node": sim["peak_node"],
        "peak_time_min": round(sim["peak_time_s"] / 60.0, 1),
        "projected_jobs": [jid for jid, j in sim["jobs"].items() if j["finish_projected"]],
        "all_job_finish_min": all_finish,
        "zone_cooling_kwh": {z: round(v, 3) for z, v in sim["zone_cooling_kwh"].items()},
        "peak_total_kw": round(sim["peak_total_kw"], 2),
    }

"""Safety Gate — 순수 Python 결정론적 검증.

원칙
- 모델 출력(확률·신뢰도)은 전혀 보지 않는다. 입력은 행동, 상태, 정책, 물리 상수뿐이다.
- 호출자가 넘긴 예측값을 믿지 않고 여기서 직접 다시 시뮬레이션한다.
- 모델 제안, 규칙 폴백, 운영자 강제 입력 모두 같은 함수를 통과한다.
- 판정할 수 없는 행동(알 수 없는 유형·대상)은 차단한다(fail-closed).

결과는 계약의 Check 형식이다: result = pass | fail | needs_approval | warn
- fail            : 필수 규칙(hard) 위반 → verdict "blocked". 승인으로 해제할 수 없다.
- needs_approval  : 권한자 승인 필요 → verdict "conditional"
- warn            : 목표(objective) 정책 미달 또는 상태를 바꾸지 않는 행동의 위험 고지. 차단하지 않는다.
"""
from __future__ import annotations

from .candidates import APPROVAL_POLICY, EXECUTABLE_TYPES, P0
from .simulator import job_map, node_map, policy_limits, simulate

ROLE_NAME = {"cooling_A": "냉각 운영", "gpu_B": "GPU 운영"}
KNOWN_TYPES = EXECUTABLE_TYPES + ("request_info", "escalate")


def _check(policy_id: str, name: str, criterion: str, observed: str, result: str) -> dict:
    return {"policy_id": policy_id, "name": name, "criterion": criterion, "observed": observed, "result": result}


def _fmt_min(seconds: float) -> str:
    return f"{seconds / 60.0:.1f}분"


def check_action(action: dict, snap: dict, policy: dict, physics: dict, *, include_approval: bool = True) -> dict:
    """반환: {"checks": [...], "verdict": allowed|conditional|blocked, "hard_violations": [...], "sim": {...}|None}"""
    checks: list[dict] = []
    nodes, jobs = node_map(snap), job_map(snap)
    zones = {z["id"]: z for z in snap["zones"]}
    a_type = action.get("type")
    params = action.get("params") or {}
    limit_c, _ = policy_limits(policy)

    # ---- 구조 검사: 알 수 없으면 차단
    problem = None
    if a_type not in KNOWN_TYPES:
        problem = f"알 수 없는 행동 유형 {a_type!r}"
    elif a_type == "cooling_change" and (params.get("zone") not in zones or not isinstance(params.get("to"), int)):
        problem = f"알 수 없는 냉각 구역 또는 레벨: {params}"
    elif a_type in ("job_migrate", "job_defer") and params.get("job") not in jobs:
        problem = f"알 수 없는 작업 {params.get('job')!r}"
    elif a_type == "job_migrate" and params.get("to") not in nodes:
        problem = f"알 수 없는 대상 노드 {params.get('to')!r}"
    if problem:
        checks.append(_check("-", "행동 형식", "정의된 행동과 대상", problem, "fail"))
        return {"checks": checks, "verdict": "blocked", "hard_violations": ["INVALID_ACTION"], "sim": None}

    job = jobs.get(params.get("job")) if a_type in ("job_migrate", "job_defer") else None
    p0_jobs = [j["id"] for j in snap["jobs"] if j["priority"] == P0]

    # ---- POL-03 대상 노드 용량
    if a_type == "job_migrate":
        target = nodes[params["to"]]
        need = int(job["gpus"])
        free = int(target["gpus_free"])
        checks.append(_check("POL-03", "대상 노드 용량", f"요청 GPU {need} ≤ 여유",
                             f"{target['id']} 여유 {free}", "pass" if free >= need else "fail"))

    # ---- POL-01 P0 작업 보호
    touches_p0 = job is not None and job["priority"] == P0
    if touches_p0:
        verb = "이동" if a_type == "job_migrate" else "연기"
        observed = f"{job['id']}({job['priority']}) {verb} 요청"
    else:
        observed = f"{', '.join(p0_jobs)} 영향 없음" if p0_jobs else "P0 작업 없음"
    checks.append(_check("POL-01", "P0 작업 보호", "P0 작업 중단·이동 없음", observed, "fail" if touches_p0 else "pass"))

    # ---- 냉각 상한 (구역 최대 레벨)
    if a_type == "cooling_change":
        z = zones[params["zone"]]
        ok = int(params["to"]) <= int(z["cooling_max"])
        checks.append(_check("-", "냉각 용량", f"요청 레벨 ≤ 최대 {z['cooling_max']}",
                             f"{z['id']} 레벨 {z['cooling_level']} → {params['to']}", "pass" if ok else "fail"))

    static_fail = any(c["result"] == "fail" for c in checks)

    # ---- POL-02 열 안전 한계: 정적 검사를 통과한 행동만 직접 재시뮬레이션
    sim = None
    if static_fail:
        # 실행 자체가 불가능한 행동이라 예측 검사는 하지 않는다.
        pass
    else:
        sim = simulate(snap, physics, policy, action)
        peak = sim["peak_temp_c"]
        observed = f"{peak:.1f}°C ({sim['peak_node']}, {_fmt_min(sim['peak_time_s'])} 뒤 · 추정)"
        if a_type in EXECUTABLE_TYPES:
            result = "pass" if peak <= limit_c else "fail"
        else:
            # 상태를 바꾸지 않는 행동: 막지는 않되, 위험이 해소되지 않음을 알린다.
            result = "pass" if peak <= limit_c else "warn"
            if result == "warn":
                observed += " · 조치 없이는 한계 초과"
        checks.append(_check("POL-02", "열 안전 한계", f"예측 최고 ≤ {limit_c:g}°C", observed, result))

        # ---- POL-08 목표: 마감 준수 (차단하지 않음)
        late = [(jid, j) for jid, j in sim["jobs"].items() if not j["deadline_met"]]
        if a_type in EXECUTABLE_TYPES:
            if late:
                text = ", ".join(f"{jid} {_fmt_min(j['lateness_s'])} 초과" for jid, j in late)
                checks.append(_check("POL-08", "마감 준수 (목표)", "모든 작업이 마감 안에 완료", text, "warn"))
            else:
                slacks = [(jid, j["slack_s"]) for jid, j in sim["jobs"].items() if j["slack_s"] is not None]
                tight = min(slacks, key=lambda x: x[1]) if slacks else None
                text = f"가장 빠듯한 작업 {tight[0]} 여유 {_fmt_min(tight[1])}" if tight else "마감이 있는 작업 없음"
                checks.append(_check("POL-08", "마감 준수 (목표)", "모든 작업이 마감 안에 완료", text, "pass"))

    # ---- 승인 요건
    hard = [c["policy_id"] for c in checks if c["result"] == "fail"]
    role = required_role(action, policy)
    if include_approval and role and not hard:
        checks.append(_check(APPROVAL_POLICY[a_type], "승인 권한", f"{ROLE_NAME.get(role, role)} 승인", "아직 없음", "needs_approval"))

    verdict = "blocked" if hard else ("conditional" if any(c["result"] == "needs_approval" for c in checks) else "allowed")
    return {"checks": checks, "verdict": verdict, "hard_violations": hard, "sim": sim}


def required_role(action: dict, policy: dict) -> str | None:
    """이 행동을 승인할 수 있는 역할. 정책(승인 요건)에서 읽는다. 후보 객체의 값을 믿지 않는다."""
    pid = APPROVAL_POLICY.get(action.get("type"))
    if not pid:
        return None
    for p in policy["policies"]:
        if p["id"] == pid:
            return (p.get("params") or {}).get("role")
    return None


def check_approval(action: dict, role: str | None, policy: dict, roles: list[dict]) -> dict:
    """승인 권한 검사. 반환 {"ok", "policy_id", "required_role", "message"}. 서버에서 반드시 호출한다."""
    a_type = action.get("type")
    pid = APPROVAL_POLICY.get(a_type)
    need = required_role(action, policy)
    role_def = next((r for r in roles if r["id"] == role), None)
    can = bool(role_def and a_type in role_def.get("can_approve", []))
    ok = need is not None and role == need and can
    return {
        "ok": ok, "policy_id": pid, "required_role": need,
        "message": "권한 확인" if ok else f"현재 역할({role})은 이 행동을 결정할 권한이 없습니다 ({pid or '권한'}).",
    }

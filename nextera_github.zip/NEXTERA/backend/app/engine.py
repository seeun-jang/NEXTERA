"""판단 파이프라인 (저장소·HTTP 와 무관한 순수 로직). API 서비스와 eval_runner 가 같은 함수를 쓴다.

    관측·정책 고정 → 후보 생성·정책 필터 → 후보별 시뮬레이션 → Safety Gate 사전 검사(필수 규칙)
    → Zoro-1 판단(choice + noul + score) → 응답 검증 → (실패 시 규칙 폴백)
    → 제안이 필수 규칙을 어기면 차단 후 확률 차순위로 수정 → 신뢰도 낮음 플래그
"""
from __future__ import annotations

import copy
from dataclasses import dataclass, field
from typing import Any

from . import candidates as cand_mod
from . import context_builder, safety_gate
from .config import canonical_hash, snapshot_version
from .providers import DecisionProvider, ProviderContext, ProviderError, RuleBaselineProvider
from .providers.base import CONTRACT_PROVIDER, answer_confidence
from .providers.rule_baseline import explain as rule_explain
from .simulator import job_map, node_map, simulate

EXPERIMENT_KEYS = ("deadline_min", "cooling_max", "n2_gpus_free", "j07_priority", "objective",
                   "approval_delay_min", "without_notes", "n4_temp_c")
# 상황 설정(01) 값 가운데 스냅샷이 아니라 물리 설정·운영 목표에 들어가는 것
SCENARIO_RUNTIME_KEYS = ("objective", "approval_delay_min")
OBJECTIVES = ("energy", "balanced", "performance")
FALLBACK_CODE = {
    "timeout": "TIMEOUT", "invalid_response": "INVALID_OUTPUT", "bad_json": "INVALID_OUTPUT",
    "unreachable": "ZORO1_UNREACHABLE", "http_error": "ZORO1_HTTP_ERROR",
    "load_error": "ZORO1_NOT_CONFIGURED", "not_configured": "ZORO1_NOT_CONFIGURED",
    "runtime_error": "ZORO1_ERROR",
}


class ChangeError(ValueError):
    pass


def _add_minutes(hhmmss: str, minutes: float) -> str:
    h, m, s = (int(x) for x in hhmmss.split(":"))
    total = int(round(h * 3600 + m * 60 + s + minutes * 60))
    return f"{total // 3600 % 24:02d}:{total % 3600 // 60:02d}:{total % 60:02d}"


def apply_changes(snap: dict, incident: dict, physics: dict, changes: dict | None) -> tuple[dict, dict, str]:
    """조건 실험: 스냅샷 복사본에 바뀐 조건만 적용한다. (snapshot, physics, objective) 를 돌려준다."""
    changes = changes or {}
    unknown = set(changes) - set(EXPERIMENT_KEYS)
    if unknown:
        raise ChangeError(f"알 수 없는 실험 조건: {sorted(unknown)}. 허용: {list(EXPERIMENT_KEYS)}")
    snap = copy.deepcopy(snap)
    physics = copy.deepcopy(physics)
    objective = incident.get("default_objective", "balanced")
    jobs, nodes = job_map(snap), node_map(snap)
    primary = jobs.get((incident.get("job_ids") or [None])[0])

    def num(key, lo, hi):
        v = changes[key]
        if not isinstance(v, (int, float)) or isinstance(v, bool) or not lo <= v <= hi:
            raise ChangeError(f"{key} 는 {lo}~{hi} 사이의 숫자여야 합니다 (받은 값: {v!r})")
        return v

    if "deadline_min" in changes and primary:
        v = num("deadline_min", 0.5, 240)
        primary["deadline_min"] = v
        primary["deadline_at"] = _add_minutes(snap["sim_time"], v)
    if "j07_priority" in changes and primary:
        if changes["j07_priority"] not in ("P0", "P1", "P2"):
            raise ChangeError("j07_priority 는 P0·P1·P2 중 하나여야 합니다")
        primary["priority"] = changes["j07_priority"]
    if "n2_gpus_free" in changes:
        node = nodes.get(incident.get("spare_node"))
        if node:
            node["gpus_free"] = int(num("n2_gpus_free", 0, node["gpus_total"]))
    if "cooling_max" in changes:
        zid = (incident["candidates"].get("cooling_zones") or [None])[0]
        zone = next((z for z in snap["zones"] if z["id"] == zid), None)
        if zone:
            zone["cooling_max"] = int(num("cooling_max", 1, 10))
    if "approval_delay_min" in changes:
        physics["approval_wait_s"] = float(num("approval_delay_min", 0, 30)) * 60.0
    if "objective" in changes:
        if changes["objective"] not in OBJECTIVES:
            raise ChangeError(f"objective 는 {OBJECTIVES} 중 하나여야 합니다")
        objective = changes["objective"]
    if changes.get("without_notes"):
        snap["notes"] = []
    if "n4_temp_c" in changes:
        # 사건 노드(N4)의 현재 온도. 지난 관측 이력도 같은 만큼 옮겨 상승 추세는 그대로 둔다.
        node = nodes.get((incident.get("node_ids") or [None])[0])
        if node:
            v = float(num("n4_temp_c", 30, 120))
            off = v - float(node["temp_c"])
            node["temp_c"] = int(v) if v == int(v) else v
            for h in snap.get("history", []):
                if h["node_id"] == node["id"]:
                    for p in h["points"]:
                        p["temp_c"] = round(p["temp_c"] + off, 1)
    return snap, physics, objective


@dataclass
class Prepared:
    snap: dict
    incident: dict
    policy: dict
    physics: dict
    decision_cfg: dict
    objective: str
    candidates: list[dict]
    options: list[dict]
    no_action_sim: dict
    sims: dict[str, dict]
    gates: dict[str, dict]
    hard: dict[str, list[str]]
    primary_job: str | None
    trace: list[dict] = field(default_factory=list)

    def versions(self) -> dict:
        return {
            "state_version": snapshot_version(self.snap),
            "policy_version": self.policy["version"],
            "physics_version": self.physics["version"],
            "physics_hash": canonical_hash(self.physics),
            "decision_config_version": self.decision_cfg["version"],
            "decision_config_hash": canonical_hash(self.decision_cfg),
            "horizon_ticks": int(self.physics["rollout_ticks"]),
        }


def _sim_brief(sim: dict, primary_job: str | None) -> dict:
    out = {
        "peak_temp_c": round(sim["peak_temp_c"], 2), "peak_node": sim["peak_node"],
        "violates_limit": sim["violates_limit"],
        "throttle_job_s": round(sim["throttle_job_s"], 1),
        "cooling_kwh": round(sim["cooling_kwh"], 4), "total_kwh": round(sim["total_kwh"], 4),
        "deadline_misses": sim["deadline_misses"],
        "completed_work_gpu_s": round(sim["completed_work_gpu_s"], 1),
        "remaining_work_gpu_s": round(sim["remaining_work_gpu_s"], 1),
    }
    job = sim["jobs"].get(primary_job) if primary_job else None
    if job and job["finish_s"] is not None:
        out["primary_job_finish_s"] = round(job["finish_s"], 1)
        out["primary_job_slack_s"] = None if job["slack_s"] is None else round(job["slack_s"], 1)
    return out


def prepare(snap: dict, incident: dict, policy: dict, physics: dict, decision_cfg: dict, objective: str = "balanced") -> Prepared:
    cands = cand_mod.build_candidates(snap, incident, policy)
    if decision_cfg.get("choice_set") == "all_passed":
        options = [c for c in cands if not c["filtered_out"]]
    else:
        options = cand_mod.executable(cands)
    primary_job = (incident.get("job_ids") or [None])[0]

    no_action = simulate(snap, physics, policy, None)
    sims: dict[str, dict] = {}
    gates: dict[str, dict] = {}
    hard: dict[str, list[str]] = {}
    for c in options:
        gate = safety_gate.check_action(c, snap, policy, physics, include_approval=False)
        gates[c["id"]] = gate
        hard[c["id"]] = gate["hard_violations"]
        sims[c["id"]] = gate["sim"] or simulate(snap, physics, policy, c)

    prep = Prepared(snap=snap, incident=incident, policy=policy, physics=physics, decision_cfg=decision_cfg,
                    objective=objective, candidates=cands, options=options, no_action_sim=no_action,
                    sims=sims, gates=gates, hard=hard, primary_job=primary_job)
    prep.trace.append({"step": "observe", **prep.versions(), "snapshot_id": snap["snapshot_id"],
                       "incident_id": incident["id"], "objective": objective, "notes": len(snap.get("notes", []))})
    prep.trace.append({"step": "candidates", "total": len(cands),
                       "passed": [c["id"] for c in cands if not c["filtered_out"]],
                       "filtered": [{"id": c["id"], "reason": c["filter_reason"]} for c in cands if c["filtered_out"]],
                       "choice_set": [c["id"] for c in options]})
    prep.trace.append({"step": "simulate", "no_action": _sim_brief(no_action, primary_job),
                       "candidates": {cid: _sim_brief(s, primary_job) for cid, s in sims.items()},
                       "hard_violations": {cid: v for cid, v in hard.items() if v}})
    return prep


def _review(probs: dict | None, decision_cfg: dict, modified: bool) -> dict:
    out: dict[str, Any] = {"needs_review": False, "reasons": [], "top1": None, "margin": None,
                           "review_threshold": decision_cfg["review_threshold"], "review_margin": decision_cfg["review_margin"]}
    if probs:
        ordered = sorted(probs.values(), reverse=True)
        top1 = ordered[0]
        margin = top1 - (ordered[1] if len(ordered) > 1 else 0.0)
        out["top1"], out["margin"] = round(top1, 4), round(margin, 4)
        if top1 < float(decision_cfg["review_threshold"]):
            out["reasons"].append(f"1위 확률 {top1:.2f} < 기준 {decision_cfg['review_threshold']}")
        if len(ordered) > 1 and margin < float(decision_cfg["review_margin"]):
            out["reasons"].append(f"1·2위 차 {margin:.2f} < 기준 {decision_cfg['review_margin']}")
    if modified:
        out["reasons"].append("모델 제안이 Safety Gate 사전 검사에서 차단되어 수정됨")
    out["needs_review"] = bool(out["reasons"])
    if out["needs_review"]:
        out["message"] = "신뢰도 낮음 → Decision Lab 조건 비교 및 권한자 검토 권장"
    return out


def _diagnostics(answers: dict) -> dict:
    out: dict[str, Any] = {}
    memo = answers.get("memo_thermal_risk")
    if memo and "noul" in memo:
        out["memo_thermal_risk"] = {"p": round(float(memo["noul"]), 4), "confidence": answer_confidence(memo),
                                    "synthetic": bool(memo.get("synthetic"))}
    risk = answers.get("risk_level")
    if risk and "score" in risk:
        legend = risk.get("legend") or []
        idx = int(round(float(risk["score"])))
        out["risk_level"] = {
            "score": round(float(risk["score"]), 4),
            "label": legend[idx] if 0 <= idx < len(legend) else None,
            "legend": legend, "probs": risk.get("probabilities"),
            "confidence": answer_confidence(risk), "synthetic": bool(risk.get("synthetic")),
        }
    return out


def sim_explanation(prep: Prepared, action_id: str) -> str | None:
    """선택 행동에 대한 시뮬레이터 수치 요약. 모델이 쓴 문장이 아니다."""
    sim = prep.sims.get(action_id)
    if not sim:
        return None
    base = prep.no_action_sim["cooling_kwh"]
    delta = (sim["cooling_kwh"] - base) / base * 100.0 if base > 0 else 0.0
    parts = [f"예측 최고 {sim['peak_temp_c']:.1f}°C({sim['peak_node']})",
             f"냉각 {sim['cooling_kwh']:.3f} kWh(조치 없음 대비 {delta:+.1f}%)"]
    job = sim["jobs"].get(prep.primary_job) if prep.primary_job else None
    if job and job["finish_s"] is not None:
        text = f"{prep.primary_job} 완료 {job['finish_s'] / 60.0:.1f}분"
        if job["deadline_s"] is not None:
            text += f"(마감 {job['deadline_s'] / 60.0:g}분, " + (f"{job['lateness_s'] / 60.0:.1f}분 초과)" if job["lateness_s"] > 0 else f"여유 {job['slack_s'] / 60.0:.1f}분)")
        parts.append(text)
    if sim["throttle_job_s"] > 0:
        parts.append(f"스로틀 {sim['throttle_job_s'] / 60.0:.1f}분")
    return "시뮬레이터 추정: " + " · ".join(parts)


def sim_explanation_no_action(prep: Prepared) -> str:
    """설비를 그대로 뒀을 때의 시뮬레이터 수치 요약 (사람에게 넘긴 경우 표시)."""
    sim = prep.no_action_sim
    parts = [f"조치 없음 예측 최고 {sim['peak_temp_c']:.1f}°C({sim['peak_node']})"]
    if sim["reach_limit_s"] is not None:
        parts.append(f"약 {sim['reach_limit_s'] / 60.0:.1f}분 뒤 한계 {sim['limit_c']:g}°C 초과")
    return "시뮬레이터 추정: " + " · ".join(parts)


def decide(
    prep: Prepared,
    provider: DecisionProvider,
    *,
    strategy_version: str | None = None,
    lang: str | None = None,
    enable_escalation: bool | None = None,
    escalation_threshold: float | None = None,
    temperature: float | None = None,
    allow_fallback: bool = True,
) -> dict:
    cfg = prep.decision_cfg
    strategy_version = strategy_version or cfg["strategy_version"]
    lang = lang or cfg["lang"]
    enable_escalation = cfg["enable_escalation"] if enable_escalation is None else enable_escalation
    escalation_threshold = cfg["escalation_threshold"] if escalation_threshold is None else escalation_threshold
    trace = list(prep.trace)
    meta = {**prep.versions(), "strategy_version": strategy_version, "lang": lang, "objective": prep.objective}
    esc = next((c for c in prep.candidates if c["type"] == "escalate" and not c["filtered_out"]), None)

    # ---- 선택할 후보가 없으면 모델을 부르지 않고 이관
    if not prep.options:
        selected = esc["id"] if esc else None
        trace.append({"step": "select", "selected_id": selected, "reason": "NO_EXECUTABLE_CANDIDATE"})
        return {
            "request": None, "provider": "rule", "decision_mode": "rule_fallback", "is_fallback": True, "is_real_model": False,
            "proposed_id": selected, "selected_id": selected, "modified_after_block": False, "blocked": None,
            "probs": None, "direct_probs": None, "escalated_questions": [], "latency_ms": 0.0,
            "fallback_reason": "NO_EXECUTABLE_CANDIDATE", "model_error": None,
            "rationale": "정책을 통과한 실행 가능한 후보가 없어 운영자에게 이관합니다.",
            "sim_explanation": None, "review": _review(None, cfg, False), "diagnostics": {},
            "raw_extra_fields": {}, "reasoning_text": None, "answers": {}, "direct_answers": None,
            "warnings": [], "errors": [], "meta": meta, "trace": trace,
        }

    # ---- 사람에게 넘김: 필수 규칙과 마감을 함께 지키는 설비 조작이 하나도 없으면 무리해서 고르지 않는다.
    #      (모델에 실행 가능한 후보만 주는 방식에서의 시스템 규칙. 모델을 부르지 않으므로 출처는 규칙이다.)
    handoff_on = bool((cfg.get("handoff") or {}).get("when_no_feasible_action", True)) and cfg.get("choice_set") != "all_passed"
    feasible = [c["id"] for c in prep.options if not prep.hard.get(c["id"]) and not prep.sims[c["id"]]["deadline_misses"]]
    if handoff_on and esc and not feasible:
        why = []
        for c in prep.options:
            sim = prep.sims[c["id"]]
            if prep.hard.get(c["id"]):
                why.append(f"{c['label']}: {', '.join(prep.hard[c['id']])} 위반")
            else:
                late = ", ".join(f"{jid} 마감 {sim['jobs'][jid]['lateness_s'] / 60.0:.1f}분 초과" for jid in sim["deadline_misses"])
                why.append(f"{c['label']}: {late}")
        rationale = "마감과 열 한계를 함께 지키는 허용 후보가 없어 운영자에게 넘깁니다. (" + " · ".join(why) + ")"
        trace.append({"step": "handoff", "selected_id": esc["id"], "reason": "NO_FEASIBLE_ACTION", "candidates": why})
        return {
            "request": None, "provider": "rule", "decision_mode": "rule_handoff", "is_fallback": False, "is_real_model": False,
            "proposed_id": esc["id"], "selected_id": esc["id"], "modified_after_block": False, "blocked": None,
            "probs": None, "direct_probs": None, "escalated_questions": [], "latency_ms": 0.0,
            "fallback_reason": "NO_FEASIBLE_ACTION", "model_error": None,
            "rationale": rationale, "sim_explanation": sim_explanation_no_action(prep),
            "review": _review(None, cfg, False), "diagnostics": {},
            "raw_extra_fields": {}, "reasoning_text": None, "answers": {}, "direct_answers": None,
            "warnings": [], "errors": [], "meta": meta, "trace": trace,
        }

    request = context_builder.build_request(
        snap=prep.snap, incident=prep.incident, policy=prep.policy, options=prep.options, sims=prep.sims,
        no_action_sim=prep.no_action_sim, strategy_version=strategy_version, lang=lang,
        objective=prep.objective, include_diagnostics=bool(cfg.get("include_diagnostics", True)),
    )
    ctx = ProviderContext(options=prep.options, sims=prep.sims, no_action_sim=prep.no_action_sim, hard=prep.hard,
                          snapshot=prep.snap, decision_cfg=cfg, objective=prep.objective, primary_job=prep.primary_job)
    trace.append({"step": "build_request", "strategy_version": strategy_version, "lang": lang,
                  "questions": list(request["questions"]), "options": list(request["questions"]["action"]["criteria"]),
                  "request_hash": canonical_hash(request)})

    model_error = None
    fallback_reason = None
    try:
        result = provider.decide(request, ctx, enable_escalation=enable_escalation,
                                 escalation_threshold=escalation_threshold, temperature=temperature)
        trace.append({"step": "provider_call", "provider": result.provider, "decision_mode": result.decision_mode,
                      "latency_ms": result.latency_ms, "is_real_model": result.is_real_model,
                      "escalated_questions": result.escalated_questions, "validation": "pass"})
    except ProviderError as e:
        if not allow_fallback:
            raise
        model_error = e.to_dict()
        fallback_reason = FALLBACK_CODE.get(e.kind, "ZORO1_ERROR")
        trace.append({"step": "provider_call", "provider": provider.name, "error": model_error, "validation": "fail"})
        result = RuleBaselineProvider(cfg, mode="rule_fallback").decide(request, ctx)
        result.errors.append({"stage": "direct", **model_error})
        trace.append({"step": "fallback", "to": "rule_baseline", "fallback_reason": fallback_reason,
                      "latency_ms": result.latency_ms})

    if result.decision_mode == "mock":
        fallback_reason = "MOCK_MODE"
    elif result.decision_mode == "rule_baseline":
        fallback_reason = "RULE_MODE"

    action = result.answers["action"]
    proposed = action["choice"]
    real = result.is_real_model
    probs = {k: round(float(v), 6) for k, v in action["probabilities"].items()} if real else None
    direct_probs = None
    if real and result.direct_answers:
        direct_probs = {k: round(float(v), 6) for k, v in result.direct_answers["action"]["probabilities"].items()}

    # ---- 차단 후 수정 (C3): 제안이 필수 규칙을 어기면 확률 차순위 중 통과하는 후보로
    selected = proposed
    blocked = None
    if prep.hard.get(proposed):
        blocked = {"action_id": proposed, "violations": prep.hard[proposed],
                   "checks": [c for c in prep.gates[proposed]["checks"] if c["result"] == "fail"]}
        order_src = action["probabilities"] if real else None
        if order_src:
            order = sorted(order_src, key=lambda k: -order_src[k])
        else:
            order = action.get("ranking") or [c["id"] for c in prep.options]
        selected = next((cid for cid in order if cid != proposed and not prep.hard.get(cid)), None)
        if selected is None:
            selected = esc["id"] if esc else proposed
        trace.append({"step": "gate_precheck", "proposed_id": proposed, "blocked_by": prep.hard[proposed],
                      "modified_to": selected})
    else:
        trace.append({"step": "gate_precheck", "proposed_id": proposed, "blocked_by": []})
    modified = selected != proposed

    review = _review(probs, cfg, modified)
    if result.decision_mode in ("rule_fallback", "rule_baseline", "mock"):
        rationale = rule_explain(ctx, proposed) + (" (모의 응답)" if result.decision_mode == "mock" else "")
    else:
        rationale = None  # 직접 모드에서는 모델이 글을 쓰지 않는다. 추론 모드의 원문은 reasoning_text 로 따로 전달한다
    if modified:
        note = f"제안 '{proposed}'은(는) 필수 규칙({', '.join(blocked['violations'])}) 위반으로 차단되어 '{selected}'(으)로 수정했습니다."
        rationale = f"{rationale} {note}" if rationale else note

    trace.append({"step": "select", "proposed_id": proposed, "selected_id": selected, "modified_after_block": modified,
                  "probs": probs, "review": review})
    return {
        "request": request,
        "provider": CONTRACT_PROVIDER.get(result.decision_mode, "rule"),
        "decision_mode": result.decision_mode,
        "is_fallback": result.is_fallback, "is_real_model": real,
        "proposed_id": proposed, "selected_id": selected, "modified_after_block": modified, "blocked": blocked,
        "probs": probs, "direct_probs": direct_probs,
        "escalated_questions": result.escalated_questions,
        "latency_ms": result.latency_ms, "latency_breakdown_ms": result.latency_breakdown_ms,
        "fallback_reason": fallback_reason, "model_error": model_error,
        "rationale": rationale, "sim_explanation": sim_explanation(prep, selected),
        "review": review, "diagnostics": _diagnostics(result.answers),
        "raw_extra_fields": result.raw_extra_fields, "reasoning_text": result.reasoning_text,
        "answers": result.answers, "direct_answers": result.direct_answers,
        "confidences": result.confidences,
        "warnings": result.warnings, "errors": result.errors,
        "request_options": result.request_options,
        "meta": meta, "trace": trace,
    }

#!/usr/bin/env python3
"""일괄 비교 평가 러너.

시나리오 3종 × 조건 변형 × (언어·전략) 에 대해 같은 조건에서
    RuleBaseline  vs  Zoro-1 (direct)  vs  Zoro-1 (auto-escalate)
를 실행하고 표(터미널·Markdown)와 JSON 을 남긴다. 시나리오별 전체 흐름(판단→안전 검사→승인→실행→영수증)은
제출용 실행 로그로 저장한다.

예)
    python eval_runner.py                                  # 전체 매트릭스, Zoro-1 은 http://localhost:30001
    python eval_runner.py --quick                          # 기준 조건만
    python eval_runner.py --zoro-backend mock              # 모델 없이 배선 확인 (결과에 MOCK 표시)
    python eval_runner.py --override physics.fan_issue_efficiency=0.5 decision.review_threshold=0.6

모든 수치는 이 실행에서 계산된 값이다. 모델에 접속하지 못하면 규칙 폴백으로 표시되며 Zoro-1 결과로 집계하지 않는다.
"""
from __future__ import annotations

import argparse
import copy
import datetime as dt
import json
import sys
from pathlib import Path

from app import config, engine
from app.candidates import EXECUTABLE_TYPES
from app.providers import get_provider
from app.providers.rule_baseline import objective_key, objective_metrics
from app.service import NexteraService

BACKEND = Path(__file__).resolve().parent
PROVIDER_LABEL = {"rule": "RuleBaseline", "zoro_direct": "Zoro-1 (direct)", "zoro_escalate": "Zoro-1 (auto-escalate)"}


def parse_overrides(items: list[str]) -> dict:
    out: dict = {}
    for item in items or []:
        if "=" not in item or "." not in item.split("=", 1)[0]:
            raise SystemExit(f"--override 형식 오류: '{item}' (예: physics.rollout_ticks=16)")
        key, raw = item.split("=", 1)
        section, path = key.split(".", 1)
        try:
            value = json.loads(raw)
        except ValueError:
            value = raw
        out.setdefault(section, {})[path] = value
    unknown = set(out) - {"physics", "decision"}
    if unknown:
        raise SystemExit(f"--override 섹션은 physics, decision 만 가능합니다: {sorted(unknown)}")
    return out


def build_case(incident: dict, base_snap: dict, variant: dict) -> tuple[dict, dict]:
    """변형을 적용한 (스냅샷, ExperimentChanges)."""
    snap = copy.deepcopy(base_snap)
    changes = dict(variant.get("changes") or {})
    primary = next((j for j in snap["jobs"] if j["id"] == (incident.get("job_ids") or [None])[0]), None)
    if "deadline_scale" in variant and primary and primary.get("deadline_min") is not None:
        changes["deadline_min"] = round(primary["deadline_min"] * variant["deadline_scale"], 1)
    if "spare_free_delta" in variant:
        spare = next(n for n in snap["nodes"] if n["id"] == incident["spare_node"])
        changes["n2_gpus_free"] = max(0, min(spare["gpus_total"], spare["gpus_free"] + variant["spare_free_delta"]))
    if variant.get("snapshot_overrides"):
        for hot in incident["node_ids"]:
            config.apply_overrides(snap, {k.format(hot_node=hot): v for k, v in variant["snapshot_overrides"].items()})
    return snap, changes


def outcome_row(prep: engine.Prepared, out: dict) -> dict:
    selected = out["selected_id"]
    cand = next((c for c in prep.candidates if c["id"] == selected), None)
    physical = bool(cand) and cand["type"] in EXECUTABLE_TYPES
    sim = prep.sims.get(selected) if physical else None
    if sim is None:
        sim = prep.no_action_sim
    proposed_hard = prep.hard.get(out["proposed_id"], [])
    final_hard = prep.hard.get(selected, []) if physical else (["POL-02(미해소)"] if sim["violates_limit"] else [])
    primary = sim["jobs"].get(prep.primary_job) if prep.primary_job else None
    probs = out["probs"] or {}
    return {
        "selected_id": selected, "proposed_id": out["proposed_id"], "modified_after_block": out["modified_after_block"],
        "provider": out["provider"], "decision_mode": out["decision_mode"], "is_real_model": out["is_real_model"],
        "is_fallback": out["is_fallback"], "fallback_reason": out["fallback_reason"],
        "top_prob": round(max(probs.values()), 4) if probs else None, "probs": out["probs"],
        "direct_probs": out["direct_probs"], "escalated_questions": out["escalated_questions"],
        "latency_ms": out["latency_ms"], "needs_review": out["review"]["needs_review"],
        "diagnostics": out["diagnostics"],
        "hard_violations_proposed": proposed_hard, "hard_violations_final": final_hard,
        "peak_temp_c": round(sim["peak_temp_c"], 2), "peak_node": sim["peak_node"],
        "throttle_s": round(sim["throttle_job_s"], 1),
        "cooling_kwh": round(sim["cooling_kwh"], 4), "total_kwh": round(sim["total_kwh"], 4),
        "peak_total_kw": round(sim["peak_total_kw"], 2), "power_cap_excess_kw": round(sim["power_cap_excess_kw"], 2),
        "deadline_met": not sim["deadline_misses"], "deadline_misses": sim["deadline_misses"],
        "lateness_s": round(sim["total_lateness_s"], 1),
        "primary_job": prep.primary_job,
        "primary_finish_s": None if not primary or primary["finish_s"] is None else round(primary["finish_s"], 1),
        "completed_work_gpu_s": round(sim["completed_work_gpu_s"], 1),
        "remaining_work_gpu_s": round(sim["remaining_work_gpu_s"], 1),
        "_key": objective_key(sim, final_hard, prep.decision_cfg, prep.objective, prep.primary_job),
        "_metrics": objective_metrics(sim, prep.decision_cfg, prep.primary_job),
    }


def versus_rule(row: dict, rule: dict, order: list[str]) -> tuple[str, str]:
    if not row["is_real_model"]:
        return "N/A", f"모델 미사용 ({row['fallback_reason'] or row['decision_mode']})"
    if row["hard_violations_proposed"]:
        return "패", f"제안 {row['proposed_id']}이(가) Safety Gate에서 차단됨 ({', '.join(row['hard_violations_proposed'])})"
    if row["selected_id"] == rule["selected_id"] or row["_key"] == rule["_key"]:
        return "무", "같은 행동" if row["selected_id"] == rule["selected_id"] else "지표 동일"
    names = ["hard_violations"] + order
    for name, a, b in zip(names, row["_key"], rule["_key"]):
        if a != b:
            return ("승" if a < b else "패"), f"{name}: {a:g} vs 규칙 {b:g}"
    return "무", "지표 동일"


def run_matrix(args, overrides: dict) -> list[dict]:
    physics = config.load_physics(overrides.get("physics"))
    cfg = config.load_decision_cfg(overrides.get("decision"))
    policy = config.load_policy()
    variants = [v for v in json.loads((config.DATA_DIR / "eval_variants.json").read_text(encoding="utf-8"))["variants"]
                if args.variants == ["all"] or v["id"] in args.variants]
    if args.quick:
        variants = [v for v in variants if v["id"] == "base"]
    langs = [cfg["lang"]] if args.quick else args.langs
    strategies = [cfg["strategy_version"]] if args.quick else args.strategies
    rows: list[dict] = []
    for iid in args.scenarios:
        incident = config.load_incident(iid)
        base_snap = config.load_snapshot(incident["snapshot"])
        for variant in variants:
            snap, changes = build_case(incident, base_snap, variant)
            snap2, physics2, objective = engine.apply_changes(snap, incident, physics, changes)
            prep = engine.prepare(snap2, incident, policy, physics2, cfg, objective)
            order = cfg["rule_baseline"]["objective_orders"].get(objective) or cfg["rule_baseline"]["objective_orders"]["balanced"]
            rule_row = outcome_row(prep, engine.decide(prep, get_provider("rule", cfg)))
            common = {"scenario": iid, "variant": variant["id"], "variant_label": variant.get("label", variant["id"]),
                      "changes": changes, "objective": objective, **prep.versions()}
            if "rule" in args.providers:
                rows.append({**common, "provider_config": "rule", "lang": "-", "strategy_version": "-",
                             **rule_row, "vs_rule": "기준", "vs_rule_reason": ""})
            for lang in langs:
                for strategy in strategies:
                    for pc in [p for p in args.providers if p != "rule"]:
                        out = engine.decide(prep, get_provider(args.zoro_backend, cfg), strategy_version=strategy, lang=lang,
                                            enable_escalation=(pc == "zoro_escalate"),
                                            escalation_threshold=args.escalation_threshold, temperature=args.temperature)
                        row = outcome_row(prep, out)
                        verdict, reason = versus_rule(row, rule_row, order)
                        rows.append({**common, "provider_config": pc, "lang": lang, "strategy_version": strategy,
                                     **row, "vs_rule": verdict, "vs_rule_reason": reason})
                        print(".", end="", flush=True)
    print()
    for r in rows:
        r.pop("_key", None)
        r.pop("_metrics", None)
    return rows


def badge(row: dict) -> str:
    if row["provider_config"] == "rule":
        return "RULE"
    if row["decision_mode"] == "mock":
        return "MOCK"
    if row["is_fallback"]:
        return f"FALLBACK({row['fallback_reason']})"
    return "ZORO-1·REASONED" if row["decision_mode"] == "escalated_reasoned" else "ZORO-1"


def to_markdown(rows: list[dict], header: dict) -> str:
    lines = ["# NEXTERA 평가 결과", "",
             f"- 실행 시각: {header['generated_at']}", f"- 명령: `{header['command']}`",
             f"- Zoro-1 백엔드: `{header['zoro_backend']}` · 실제 모델 응답 {header['real_model_rows']}건 / 모델 요청 {header['model_rows']}건",
             f"- physics `{header['physics_version']}` ({header['physics_hash']}) · rollout {header['horizon_ticks']} ticks", ""]
    if header["model_rows"] and not header["real_model_rows"]:
        lines += ["> **주의: 이 실행에서는 실제 Zoro-1 응답이 한 건도 없습니다.** 아래 Zoro-1 행은 폴백 또는 MOCK 결과입니다.", ""]
    cols = ["시나리오", "변형", "판단 주체", "언어", "전략", "출처", "선택 행동", "1위 확률", "지연(ms)", "필수 위반(제안)",
            "최고 온도", "스로틀(s)", "냉각 kWh", "총 kWh", "마감", "지각(s)", "완료 GPU·s", "잔여 GPU·s", "규칙 대비", "원인"]
    lines += ["| " + " | ".join(cols) + " |", "|" + "---|" * len(cols)]
    for r in rows:
        lines.append("| " + " | ".join(str(x) for x in [
            r["scenario"], r["variant_label"], PROVIDER_LABEL[r["provider_config"]], r["lang"], r["strategy_version"], badge(r),
            r["selected_id"] + (" (수정됨)" if r["modified_after_block"] else ""),
            "-" if r["top_prob"] is None else f"{r['top_prob']:.2f}", f"{r['latency_ms']:.1f}",
            len(r["hard_violations_proposed"]), f"{r['peak_temp_c']:.1f}", f"{r['throttle_s']:.0f}",
            f"{r['cooling_kwh']:.3f}", f"{r['total_kwh']:.3f}", "준수" if r["deadline_met"] else "미준수",
            f"{r['lateness_s']:.0f}", f"{r['completed_work_gpu_s']:.0f}", f"{r['remaining_work_gpu_s']:.0f}",
            r["vs_rule"], r["vs_rule_reason"]]) + " |")
    model_rows = [r for r in rows if r["provider_config"] != "rule"]
    if model_rows:
        lines += ["", "## 요약 (규칙 대비)", "", "| 판단 주체 | 언어 | 전략 | 승 | 무 | 패 | N/A | 필수 위반 제안 수 |", "|---|---|---|---|---|---|---|---|"]
        groups: dict[tuple, list[dict]] = {}
        for r in model_rows:
            groups.setdefault((r["provider_config"], r["lang"], r["strategy_version"]), []).append(r)
        for (pc, lang, strat), rs in sorted(groups.items()):
            cnt = {k: sum(1 for r in rs if r["vs_rule"] == k) for k in ("승", "무", "패", "N/A")}
            lines.append(f"| {PROVIDER_LABEL[pc]} | {lang} | {strat} | {cnt['승']} | {cnt['무']} | {cnt['패']} | {cnt['N/A']} | "
                         f"{sum(1 for r in rs if r['hard_violations_proposed'])} |")
    return "\n".join(lines) + "\n"


def print_table(rows: list[dict]) -> None:
    fmt = "{:<9} {:<15} {:<22} {:<3} {:<18} {:<24} {:<14} {:>5} {:>8} {:>3} {:>6} {:>5} {:>7} {:<5} {:<3}"
    print(fmt.format("시나리오", "변형", "판단 주체", "언어", "전략", "출처", "선택", "확률", "지연ms", "위반", "최고°C", "스로틀", "냉각kWh", "마감", "대비"))
    for r in rows:
        print(fmt.format(r["scenario"], r["variant"], PROVIDER_LABEL[r["provider_config"]], r["lang"], r["strategy_version"],
                         badge(r), r["selected_id"], "-" if r["top_prob"] is None else f"{r['top_prob']:.2f}",
                         f"{r['latency_ms']:.1f}", len(r["hard_violations_proposed"]), f"{r['peak_temp_c']:.1f}",
                         f"{r['throttle_s']:.0f}", f"{r['cooling_kwh']:.3f}", "준수" if r["deadline_met"] else "미준수", r["vs_rule"]))


def run_flow_log(iid: str, backend: str, overrides: dict, out_dir: Path, command: str) -> Path:
    """시나리오 하나의 전체 에이전트 흐름을 실행해 제출용 로그로 저장한다. 승인 역할은 스크립트가 대행한다."""
    sv = NexteraService(db_path=":memory:", provider_mode=backend, incident_id=iid, overrides=overrides)
    s = "eval"
    did = sv._decision_id(s)
    steps: list[dict] = []

    def step(name: str, fn, *a):
        try:
            result = fn(*a)
            steps.append({"step": name, "ok": True})
            return result
        except Exception as e:  # ApiError 포함: 거부도 로그에 남긴다
            steps.append({"step": name, "ok": False, "error": getattr(e, "code", type(e).__name__), "message": str(e)})
            return None

    decision = step("decide", sv.decide, s, {"incident_id": iid, "snapshot_id": sv.base_id})["decision"]
    primary = next((j for j in sv.seed["jobs"] if j["id"] == (sv.incident.get("job_ids") or [None])[0]), None)
    if primary and primary.get("deadline_min") is not None:
        short = round(primary["deadline_min"] * 0.6, 1)
        step(f"experiment(deadline_min={short})", sv.create_experiment, s,
             {"decision_id": did, "base_snapshot_id": sv.base_id, "changes": {"deadline_min": short}}, "operator")
    options = [c["id"] for c in sv._candidates(s) if not c["filtered_out"] and c["requires_approval_role"]]
    if options:
        step("futures(parallel)", sv.futures, s, {"decision_id": did, "snapshot_id": sv.base_id, "action_ids": options})
    forced = next((c for c in sv._candidates(s) if c["filtered_out"]), None)
    if forced:
        step(f"validate(operator_forced {forced['id']})", sv.validate, s, {"decision_id": did, "action_id": forced["id"], "origin": "operator_forced"})
    v = step("validate(model)", sv.validate, s, {"decision_id": did, "action_id": decision["selected_id"], "origin": "model"})
    if v and v.get("approval_id"):
        approval = sv.get_approval(s, v["approval_id"])
        wrong = next(r for r in ("cooling_A", "gpu_B") if r != approval["required_role"])
        step(f"approve as {wrong} (권한 없음, 거부 예상)", sv.decide_approval, s, v["approval_id"], {"action": "approve", "idempotency_key": "w"}, wrong)
        step(f"approve as {approval['required_role']}", sv.decide_approval, s, v["approval_id"], {"action": "approve", "idempotency_key": "a"}, approval["required_role"])
        step("execute", sv.execute, s, {"approval_id": v["approval_id"], "idempotency_key": "x"})
    elif v and v["verdict"] == "allowed":
        step("execute", sv.execute, s, {"decision_id": did, "action_id": decision["selected_id"], "idempotency_key": "x"})
    receipt = sv.get_receipt(s, did)
    log = sv.get_log(s, did)
    real = decision["provider"] == "zoro1"
    suffix = "ZORO1" if real else ("MOCK" if decision["provider"] == "mock" else f"RULE_{decision['fallback_reason']}")
    payload = {
        "scenario": iid, "title": sv.incident["title"], "generated_at": dt.datetime.now().astimezone().isoformat(timespec="seconds"),
        "command": command, "provider_backend": backend, "real_model_called": real,
        "decision_provider": decision["provider"], "decision_mode": decision["decision_mode"],
        "fallback_reason": decision["fallback_reason"],
        "note": "승인·실행은 평가 스크립트가 역할을 대행했다. 실행은 가상 환경에서의 시뮬레이션이다.",
        "script_steps": steps, "decision": decision, "receipt_status": receipt["status"],
        "runs": log["runs"], "events": log["events"], "execution": receipt["execution"],
    }
    path = out_dir / f"run_log_{iid}_{suffix}.json"
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    md = [f"# 실행 로그 · {iid} · {sv.incident['title']}", "",
          f"- 판단 출처: **{decision['provider']}** ({decision['decision_mode']})" + ("" if real else f" · 실제 Zoro-1 응답 아님 ({decision['fallback_reason']})"),
          f"- 선택 행동: `{decision['selected_id']}` · 영수증 상태: {receipt['status']}", f"- 명령: `{command}`", "",
          "| seq | 시각 | 주체 | 유형 | 내용 |", "|---|---|---|---|---|"]
    md += [f"| {e['seq']} | {e['at']} | {e['actor']} | {e['type']} | {e['summary']} |" for e in log["events"]]
    path.with_suffix(".md").write_text("\n".join(md) + "\n", encoding="utf-8")
    return path


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--scenarios", nargs="+", default=sorted(config.load_incidents()))
    ap.add_argument("--variants", nargs="+", default=["all"])
    ap.add_argument("--langs", nargs="+", default=["en", "ko"], choices=["en", "ko"])
    ap.add_argument("--strategies", nargs="+", default=["v1_raw", "v2_tradeoff_hints"])
    ap.add_argument("--providers", nargs="+", default=["rule", "zoro_direct", "zoro_escalate"], choices=list(PROVIDER_LABEL))
    ap.add_argument("--zoro-backend", default="zoro1", choices=["zoro1", "zoro1_local", "mock"])
    ap.add_argument("--escalation-threshold", type=float, default=None)
    ap.add_argument("--temperature", type=float, default=None, help="미지정이면 서버 기본 보정 온도")
    ap.add_argument("--override", nargs="*", default=[], help="physics.<키>=값 decision.<키>=값")
    ap.add_argument("--quick", action="store_true", help="기준 조건·기본 언어·기본 전략만")
    ap.add_argument("--out-dir", default=None)
    ap.add_argument("--no-flow-logs", action="store_true", help="시나리오별 제출용 실행 로그를 만들지 않음")
    args = ap.parse_args()

    overrides = parse_overrides(args.override)
    stamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    out_dir = Path(args.out_dir) if args.out_dir else BACKEND / "runs" / f"eval_{stamp}"
    out_dir.mkdir(parents=True, exist_ok=True)
    command = "python eval_runner.py " + " ".join(sys.argv[1:])

    rows = run_matrix(args, overrides)
    physics = config.load_physics(overrides.get("physics"))
    model_rows = [r for r in rows if r["provider_config"] != "rule"]
    header = {
        "generated_at": dt.datetime.now().astimezone().isoformat(timespec="seconds"), "command": command,
        "zoro_backend": args.zoro_backend, "model_rows": len(model_rows),
        "real_model_rows": sum(1 for r in model_rows if r["is_real_model"]),
        "physics_version": physics["version"], "physics_hash": config.canonical_hash(physics),
        "horizon_ticks": physics["rollout_ticks"], "overrides": overrides,
    }
    print_table(rows)
    (out_dir / "results.json").write_text(json.dumps({"header": header, "rows": rows}, ensure_ascii=False, indent=2), encoding="utf-8")
    (out_dir / "summary.md").write_text(to_markdown(rows, header), encoding="utf-8")
    print(f"\n결과: {out_dir / 'summary.md'}\n      {out_dir / 'results.json'}")
    if header["model_rows"] and not header["real_model_rows"]:
        print("주의: 실제 Zoro-1 응답이 한 건도 없습니다 (폴백 또는 MOCK).")

    if not args.no_flow_logs:
        log_dir = out_dir / "submission_logs"
        log_dir.mkdir(exist_ok=True)
        for iid in args.scenarios:
            path = run_flow_log(iid, args.zoro_backend, overrides, log_dir, command)
            print(f"실행 로그: {path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

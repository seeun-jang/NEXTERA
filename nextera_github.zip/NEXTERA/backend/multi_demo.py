#!/usr/bin/env python3
"""다중 작업 버전을 화면 없이 끝까지 돌려 보는 도구 (Brev 확인·제출 로그용).

  python multi_demo.py --provider zoro1_local            # 내장 시나리오 3종, 실제 Zoro-1
  python multi_demo.py --provider rule --scenario mixed10
  python multi_demo.py --provider zoro1_local --file my_scenario.json

회차마다: 문제 → 후보(계획) → 판단 → 안전 검사 → 역할별 승인 → 가상 실행 → 남은 문제. 결과는 runs/multi_<시각>/ 에 저장한다.
"""
from __future__ import annotations

import argparse
import json
import os
import time
from pathlib import Path

os.environ.setdefault("NEXTERA_PRELOAD", "0")
from app import api  # noqa: E402
from app.service import NexteraService  # noqa: E402

HERE = Path(__file__).resolve().parent


def run(sv: NexteraService, name: str, title: str, scenario: dict, out_dir: Path, quiet: bool = False) -> dict:
    def call(method, path, body=None, role="operator"):
        st, out = api.dispatch(sv, method, path, {}, body, {"X-Role": role, "X-Session": f"demo-{name}"})
        if st != 200:
            raise SystemExit(f"{method} {path} → {st} {out}")
        return out

    say = (lambda *a: None) if quiet else print
    say(f"\n{'=' * 78}\n{name} · {title}")
    ov = call("POST", "/api/v2/scenario", scenario)
    summary = {"scenario": name, "rounds": []}
    while True:
        t0 = time.perf_counter()
        res = call("POST", "/api/v2/decide")
        wall = (time.perf_counter() - t0) * 1000
        d = res["decision"]
        say(f"\n[회차 {d['round']}] 문제 {len(res['problems'])}개: " + ", ".join(f"{p['id']}({p['severity']})" for p in res["problems"]))
        for p in res["problems"]:
            say(f"    - {p['text']}")
        row = {"round": d["round"], "problems": [p["id"] for p in res["problems"]], "candidates": len(res["candidates"]),
               "status": d["status"], "provider": d["provider"], "selected": d["selected_id"], "fallback_reason": d["fallback_reason"],
               "model_ms": d["latency_ms"], "gen_ms": (d.get("stats") or {}).get("gen_ms"), "sims": (d.get("stats") or {}).get("sims"),
               "decide_wall_ms": round(wall, 1), "top": d["ranking"][:3], "agreement": d.get("agreement"),
               "votes": [(v["order"], v["choice"], v["prob"]) for v in (d.get("votes") or [])]}
        summary["rounds"].append(row)
        say(f"    후보 {len(res['candidates'])}개 · 후보 생성 {row['gen_ms']} ms (시뮬레이션 {row['sims']}회) · 모델 {d['latency_ms']} ms · 판단 전체 {wall:.0f} ms")
        for c in res["candidates"]:
            prob = (d["probs"] or {}).get(c["id"])
            mark = "▶" if c["id"] == d["selected_id"] else (" " if c.get("offered_to_model", True) else "·")
            say(f"   {mark} {c['id']} {'' if prob is None else f'{prob:.3f} '}[{c['label']}] 최고 {c['max_peak_c']:.1f}°C · {c['cooling_kwh']:.3f} kWh"
                + (f" · 남음 {','.join(c['remaining'])}" if c["remaining"] else ""))
            say("        " + " → ".join(s["label"] for s in c["steps"]))
        say(f"    판단: {d['status']} · {d['provider']} · {d['rationale']}")
        if d["status"] != "decided":
            break
        plan = next(c for c in res["candidates"] if c["id"] == d["selected_id"])
        v = call("POST", "/api/v2/validate", {"plan_id": plan["id"]})
        for role in plan["required_roles"]:
            call("POST", "/api/v2/approvals", {"plan_id": plan["id"]}, role=role)
        ex = call("POST", "/api/v2/execute", {"plan_id": plan["id"]})
        row.update(verdict=v["verdict"], roles=plan["required_roles"], executed=ex["status"], resolved=ex.get("resolved"),
                   remaining=[p["id"] for p in ex.get("remaining", [])], next=ex.get("next", {}).get("status"))
        say(f"    검사 {v['verdict']} · 승인 {', '.join(plan['required_roles'])} · 실행 {ex['status']} · 해결 {ex.get('resolved')} · 남음 {row['remaining']} → {row['next']}")
        if ex.get("next", {}).get("status") != "next_round":
            break
    log = call("GET", "/api/v2/log")
    summary["final_status"] = log["status"]
    out_dir.mkdir(parents=True, exist_ok=True)
    tag = "ZORO1" if any(r["provider"] == "zoro1" for r in summary["rounds"]) else "RULE"
    (out_dir / f"run_log_multi_{name}_{tag}.json").write_text(
        json.dumps({"title": title, "summary": summary, **log}, ensure_ascii=False, indent=1), encoding="utf-8")
    return summary


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--provider", default=os.environ.get("NEXTERA_PROVIDER", "rule"), choices=["zoro1", "zoro1_local", "rule", "mock"])
    ap.add_argument("--scenario", action="append", help="내장 시나리오 이름 (여러 번 가능). 생략하면 전부")
    ap.add_argument("--file", help="시나리오 JSON 파일 ({nodes, zones, jobs})")
    ap.add_argument("--max-candidates", type=int)
    ap.add_argument("--model-candidates", type=int, help="Zoro-1 에 주는 후보 수 (기본은 설정값)")
    ap.add_argument("--order-votes", type=int, help="후보 순서를 바꿔 묻는 횟수 (기본은 설정값)")
    ap.add_argument("--quiet", action="store_true")
    args = ap.parse_args()
    multi = {}
    if args.max_candidates:
        multi.setdefault("planner", {})["max_candidates"] = args.max_candidates
    if args.model_candidates:
        multi.setdefault("planner", {})["max_model_candidates"] = args.model_candidates
    if args.order_votes:
        multi["decision"] = {"order_votes": args.order_votes}
    overrides = {"multi": multi} if multi else None
    sv = NexteraService(db_path=":memory:", provider_mode=args.provider, overrides=overrides)
    out_dir = HERE / "runs" / f"multi_{time.strftime('%Y%m%d_%H%M%S')}"
    built = json.loads((HERE / "data" / "multi_scenarios.json").read_text(encoding="utf-8"))
    jobs = []
    if args.file:
        jobs.append((Path(args.file).stem, "사용자 시나리오", json.loads(Path(args.file).read_text(encoding="utf-8"))))
    else:
        for name in (args.scenario or list(built)):
            jobs.append((name, built[name]["title"], built[name]["scenario"]))
    rows = [run(sv, n, t, sc, out_dir, args.quiet) for n, t, sc in jobs]
    print(f"\n{'=' * 78}\n요약 (provider={args.provider})")
    for s in rows:
        for r in s["rounds"]:
            print(f"  {s['scenario']:16s} 회차 {r['round']} · 후보 {r['candidates']:2d} · {r['provider']:5s} · 선택 {r['selected']} · "
                  f"생성 {r['gen_ms']} ms · 모델 {r['model_ms']} ms · 상위 {r['top']} · {r.get('next') or r['status']}")
            if r["votes"]:
                print(f"  {'':16s}   순서별 선택 {r['votes']} · 최종과 일치 {r['agreement']}")
        print(f"  {s['scenario']:16s} 최종 상태: {s['final_status']}")
    print(f"\n실행 로그: {out_dir}")


if __name__ == "__main__":
    main()

# NEXTERA backend

계약 `shared/contracts/types.ts`(1.0.0)의 API를 구현한다. 응답에는 계약에 없는 선택 필드가 더 들어 있고, 프론트는 모르는 필드를 무시한다. 시드(스냅샷·정책·역할)는 프론트와 같은 `data/seed`를 읽는다.

## 실행

```bash
cd backend
pip install -r requirements.txt            # uv 환경이면: uv pip install -r requirements.txt
python -m uvicorn app.main:app --host 0.0.0.0 --port 8000
```

`../frontend/dist`가 있으면 같은 포트에서 화면까지 서빙한다(단일 서버 배포). 새로고침해도 화면이 열리도록 없는 경로는 `index.html`로 돌린다.

| 환경변수 | 기본값 | 설명 |
| --- | --- | --- |
| `NEXTERA_PROVIDER` | `zoro1` | `zoro1`(HTTP 서버) · `zoro1_local`(프로세스 안 Decider) · `rule` · `mock` |
| `ZORO1_URL` | `http://localhost:30001/v1/decide` | Zoro-1 서버 주소 |
| `ZORO1_SNAPSHOT_DIR` | 없음 | `zoro1_local`에서 `zoro_decide.py`가 있는 폴더(모델 스냅샷) |
| `ZORO1_MODEL` | `trillionlabs/Zoro-1` | `zoro1_local`에서 Decider에 넘길 모델 ID 또는 로컬 경로 |
| `NEXTERA_PRELOAD` | `1` | `zoro1_local`일 때 서버 시작과 함께 모델을 미리 올린다. `0`이면 첫 판단 때 올린다 |
| `NEXTERA_CHOICE_SET` | `executable` | 모델에 줄 선택지. `executable` = 실행 가능한 후보만(냉각·이동·연기), `all_passed` = 정책 통과 후보 전부(정보 요청·이관 포함) |
| `NEXTERA_DB` | `backend/nextera.db` | SQLite 파일 |
| `NEXTERA_DIST` | `../frontend/dist` | 프론트 빌드 폴더 |
| `NEXTERA_CORS` | `*` | 프론트를 다른 주소에서 띄울 때의 허용 출처 |

Zoro-1에 접속하지 못하면 서버는 죽지 않고 규칙 폴백으로 응답한다(`provider: "rule"`, `fallback_reason`). 실제 모델 응답과 폴백은 응답·영수증·로그에서 항상 구분된다.

## 구조

| 파일 | 역할 |
| --- | --- |
| `app/simulator.py` | 30초 단위 열·작업 시뮬레이터. 스냅샷 관측값에서 노드 상수를 보정한다 |
| `app/candidates.py` | 후보 7개 생성과 정책 필터(POL-01, POL-03) |
| `app/safety_gate.py` | **순수 Python** 필수 규칙 검증, 승인 권한 검사. 모델 출력을 보지 않고 직접 다시 시뮬레이션한다 |
| `app/context_builder.py` | Zoro-1 입력 조립. `strategy_version`(v1_raw · v2_tradeoff_hints), `lang`(en · ko) |
| `app/providers/` | `Zoro1HttpAdapter`, `Zoro1LocalAdapter`, `RuleBaselineProvider`, `MockDecisionProvider` |
| `app/engine.py` | 판단 파이프라인: 후보 → 시뮬레이션 → 사전 검사 → 판단 → 폴백 → 차단 후 수정 → 신뢰도 플래그 |
| `app/service.py` | 엔드포인트 동작, 세션별 상태, 실행 직전 재검증, 영수증 |
| `app/store.py` | SQLite 저장 |
| `app/api.py`, `app/main.py` | 경로 연결, ASGI 앱 |
| `data/*.json` | 물리 상수, 판단 설정, 사건 정의, 추가 시나리오, 평가 변형 |
| `eval_runner.py` | 일괄 비교 평가와 제출용 실행 로그 |

## 숫자는 전부 JSON에 있다

`data/physics_config.json`, `data/decision_config.json`을 고치거나 override로 덮어쓴다. 없는 키를 쓰면 오류가 난다(오타 방지).

```bash
python eval_runner.py --override physics.fan_issue_efficiency=0.5 decision.review_threshold=0.6
```

기본 rollout은 `rollout_ticks: 16`(480초)이고 일반 판단, 병렬 미래, A/B 분기, 평가가 모두 이 값 하나를 쓴다.

## 시연용 엔드포인트

```bash
# 모델 장애 주입: off | timeout | invalid | unreachable  (다음 판단부터 적용, 모델을 부르지 않고 해당 오류를 낸다)
curl -X POST localhost:8000/api/demo/fault -H 'content-type: application/json' -d '{"mode":"timeout"}'
# 승인 뒤 현장 상태 변화: 실행 직전 재검증이 막는지 확인
curl -X POST localhost:8000/api/demo/drift -H 'content-type: application/json' -d '{"node_id":"N2","gpus_free":0}'
# 초기화
curl -X POST localhost:8000/api/demo/reset
```

`X-Session` 헤더 값마다 상태가 따로 저장된다. 프론트는 브라우저마다 자동으로 세션 ID를 만든다.

## 테스트

```bash
python -m pytest -q
```

실제 Zoro-1을 부르지 않는다. 모델 경로는 `tests/fake_zoro.py`(테스트용 가짜 서버)로 요청 형식, 응답 검증, 폴백, 에스컬레이션을 확인한다.

## 평가와 제출용 로그

```bash
python eval_runner.py                 # 시나리오 3종 × 변형 6종 × 언어 2 × 전략 2, 규칙 vs Zoro-1(direct) vs Zoro-1(auto-escalate)
python eval_runner.py --quick         # 기준 조건만
python eval_runner.py --zoro-backend zoro1_local
```

결과는 `runs/eval_<시각>/`에 `summary.md`, `results.json`, `submission_logs/run_log_<사건>_<출처>.json|md`로 남는다. 로그 파일 이름과 머리말에 실제 모델 응답인지(`ZORO1`) 폴백인지(`RULE_<사유>`)가 적힌다.

## SGLang 서버에 문제가 있을 때

`NEXTERA_PROVIDER=zoro1_local`로 바꾸면 같은 요청 형식으로 `zoro_decide.py`의 `Decider("trillionlabs/Zoro-1")`를 프로세스 안에서 한 번만 로드해 쓴다. SGLang 서버와 동시에 띄우지 않는다(GPU 메모리).

## 실제 모델로 확인한 것 (2026-11-19, Brev L40S, `zoro_decide.py`)

- 직접 모드 응답: `answers`(choice는 후보 ID 키의 `probabilities`, noul, score는 `"0"`·`"1"`·`"2"` 키의 `probabilities`와 `legend`) + `timing_ms`. 판단 약 0.5초.
- 추론 모드 응답: 위에 더해 `reasoning`(모델이 쓴 원문 문자열)과 `reasoning_ms`. 약 26초.
- 이 서버(드라이버 565.57, CUDA 12.7)에서는 SGLang 서버가 CUDA 13에 묶여 있어 뜨지 않는다. `zoro1_local`을 쓴다.

## 아직 확인하지 못한 것

- `Decider.decide`가 받는 인자 전체(시그니처에 있는 인자만 전달하도록 되어 있다)
- `temperature` 덮어쓰기의 실제 동작
